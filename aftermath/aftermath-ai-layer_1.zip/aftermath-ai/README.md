# AFTERMATH — AI Intelligence Layer (Member 3 Subsystem)

This is the AI reasoning layer for AFTERMATH: it takes structured incident
investigation data (produced by Member 1's telemetry/anomaly detection and
Member 2's investigation engine) and turns it into an evidence-grounded root
cause explanation, a human-readable report, incident-specific recommendations,
similarity matching against past incidents, and a follow-up chat interface.

It does **not** detect anomalies, compute root causes from scratch, or render
any UI — it consumes structured data and reasons over it.

## Architecture

```
RawInvestigationData (from Members 1 & 2)
        |
        v
AIContextBuilder            — pure TS, no LLM. Normalizes/sorts/labels data.
        |
        v
InvestigationAgent
        |
        +-- InvestigationTools (deterministic: timeline, health, deps, traces)
        +-- InvestigationPlanner (5-step plan, emits progress events)
        |
        v
   [LLM call: buildInvestigationPrompt + AFTERMATH_SYSTEM_PROMPT]
        |
        v
EvidenceValidator            — strips hallucinated evidence IDs, clamps
        |                        overconfident claims, softens absolute language
        v
StructuredInvestigationResult (schema-validated with zod)
        |
   +----+----------------+------------------+
   |                      |                  |
   v                      v                  v
IncidentReportGenerator  RecommendationEngine  InvestigationChat
   |                      |                  |
   v                      v                  v
Markdown report      immediate/investigation/  Evidence-grounded Q&A
                      prevention actions        with conversation memory

IncidentMemory — separate, optional: weighted feature-overlap similarity
                  against a small JSON store of past incidents.
```

## Setup

```bash
npm install
cp .env.example .env
# then fill in OPENAI_API_KEY in .env, or leave it blank / set
# AI_PROVIDER_MODE=mock to run entirely offline (see below)
```

### Live LLM mode (OpenAI)
Set `OPENAI_API_KEY` in `.env`. Model defaults to `gpt-4o-mini`
(`OPENAI_MODEL` to override). The provider is abstracted behind
`src/llm/LLMProvider.ts` — swapping to Gemini means implementing that one
interface in a new file and pointing `src/llm/index.ts` at it.

### Offline demo mode
Set `AI_PROVIDER_MODE=mock`. This activates `MockProvider`, a deterministic,
non-LLM fallback that reads the same context object a real LLM would see and
applies conservative heuristics — it never invents a root cause or cites an
evidence ID that doesn't exist. **This exists specifically so a hackathon demo
never dies to a missing API key, rate limit, or flaky wifi.** It is not a
substitute for the real reasoning quality of an LLM; use it as a safety net,
not the default. If `OPENAI_API_KEY` is unset and mode isn't explicitly
`mock`, the system automatically falls back to `MockProvider` with a console
warning rather than crashing.

## Running the tests

```bash
export AI_PROVIDER_MODE=mock   # or configure OPENAI_API_KEY and omit this
npm run test:all
```

Individual tests: `npm run test:payment`, `test:database`,
`test:insufficient`, `test:multi-cause`, `test:chat`.

All 5 tests from the spec pass in mock mode as of this build:
1. Payment timeout incident → payment-related root cause with evidence citations
2. Database slowdown → database/connection-pool root cause identified
3. Insufficient evidence → confidence clamped, explicit "insufficient evidence" language
4. Multiple close-confidence candidates → uncertainty explicitly flagged, no false certainty
5. Chat question → answer cites real evidence IDs, follow-ups retain conversation context

## Integration contract

### What Members 1 & 2 must hand off
A `RawInvestigationData` object per incident (see `src/types/incident.ts`).
Shape matches the spec exactly: `incident`, `timeline`, `anomalies`,
`dependencies`, `traces`, `rootCauseCandidates`, `evidence`, optional
`recentChanges`. Three example payloads are in `/mock-data`.

### What this subsystem exposes
`src/api/routes.ts` has framework-agnostic handlers matching the spec's API
list:

| Endpoint | Handler | Input | Output |
|---|---|---|---|
| `POST /api/ai/investigate` | `handleInvestigate` | `{ rawData }` | context, plan, structured result |
| `POST /api/ai/plan` | `handlePlan` | `{ incidentId }` | `InvestigationPlan` |
| `POST /api/ai/chat` | `handleChat` | `{ incidentId, message }` | `ChatResponse` |
| `GET /api/ai/similar-incidents/:incidentId` | `handleSimilarIncidents` | — | `SimilarIncidentMatch[]` |
| `POST /api/ai/recommendations` | `handleRecommendations` | `{ incidentId }` | `RecommendedActions` |
| `GET /api/ai/report/:incidentId` | `handleReport` | — | `IncidentReport` (markdown + sections) |

`chat`, `similar-incidents`, `recommendations`, and `report` all read from an
in-process cache keyed by `incidentId`, populated by the most recent
`investigate` call for that incident — so only `/investigate` needs the full
raw payload; everything else just needs the ID. This is intentionally simple
(a `Map`) for the hackathon; swap for Redis/a DB if the demo needs multiple
server instances.

### Wiring into Next.js
Each handler returns `{ status, body }`. Example route file:

```ts
// app/api/ai/investigate/route.ts
import { handleInvestigate } from "@/aftermath-ai/src/api/routes";

export async function POST(req: Request) {
  const input = await req.json();
  const { status, body } = await handleInvestigate(input);
  return Response.json(body, { status });
}
```

### Events for Member 4's frontend
`src/events/EventBus.ts` exports a singleton `eventBus`. Subscribe with
`eventBus.on((event) => ...)`. Events fired during a run: `ai.investigation.started`,
`ai.context.prepared`, `ai.plan.created`, `ai.step.started`,
`ai.step.completed`, `ai.evidence.validated`, `ai.hypothesis.updated`,
`ai.rootcause.assessed`, `ai.report.generated`, plus the
`investigation.plan.created` / `investigation.step.*` variants for
plan-specific UI. For the demo this is in-process; relay it over a
WebSocket/SSE endpoint if Member 4 needs live browser updates.

## Design decisions worth knowing about

- **Evidence grounding is enforced twice**: once when `AIContextBuilder`
  builds hypotheses (it drops any `supportingEvidenceIds` that don't exist in
  the evidence array), and again by `EvidenceValidator` on the LLM's actual
  output (it strips hallucinated IDs, clamps confidence that exceeds what the
  cited evidence count justifies, and softens absolute-certainty language like
  "definitely caused" unless confidence ≥ 0.9 with evidence present).
- **The 5-step investigation plan is fixed, not LLM-generated.** An
  LLM-planned workflow is more "impressive" on paper but is meaningfully more
  likely to produce a malformed or nonsensical plan during a live demo. A
  fixed plan with LLM-assisted execution at the final step is far more
  reliable, per the spec's explicit "do NOT rely entirely on the LLM for
  calculations" instruction.
- **`IncidentReportGenerator` does not call the LLM again.** It templates the
  already-validated structured result. This avoids a second hallucination
  surface and keeps report generation instant.
- **`RecommendationEngine` combines LLM output with deterministic pattern
  rules** (timeout+config, retry storms, DB/connection-pool, bad deploys) so
  recommendations stay concrete even if the LLM's own suggestions get
  filtered out by the validator's generic-recommendation check.
- **`IncidentMemory` is deliberately just JSON + weighted Jaccard similarity**,
  per the explicit hackathon instruction not to build vector DB infrastructure.

## Known limitations (read before demoing)

- `MockProvider` is a heuristic stand-in, not a real reasoning engine — its
  "conclusions" are just restating whatever `rootCauseCandidates[0]` already
  says. It will not produce novel insight the way a real LLM call would. Use
  live mode for anything you want to actually showcase AI reasoning quality
  on.
- The in-process `Map` cache in `AftermathService` means investigation state
  is lost on server restart and isn't shared across multiple server
  instances. Fine for a single-process demo; not production-ready.
- `EvidenceValidator`'s confidence-vs-evidence-count ceiling (0.4 / 0.65 / 0.8
  / 0.97 for 0/1/2/3+ evidence items) is a reasonable heuristic, not a
  calibrated statistical model — don't present the numeric confidence values
  as rigorously calibrated probabilities to judges without that caveat.
- No retry/backoff on the OpenAI call beyond the single JSON-schema-correction
  retry described in the spec (Part 6). A transient network failure during a
  live demo falls back to the deterministic fallback result in
  `InvestigationAgent.buildFallbackResult`, which is honest about being
  degraded but is not a full analysis.
