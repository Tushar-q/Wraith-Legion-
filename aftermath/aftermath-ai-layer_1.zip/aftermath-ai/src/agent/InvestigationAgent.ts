import { AIContext, InvestigationPlan, StructuredInvestigationResult, ValidationResult } from "../types/ai";
import { RawInvestigationData } from "../types/incident";
import { AIContextBuilder } from "../context/AIContextBuilder";
import { InvestigationTools } from "../tools/investigationTools";
import { InvestigationPlanner } from "../planner/InvestigationPlanner";
import { EvidenceValidator } from "../validator/EvidenceValidator";
import { LLMProvider } from "../llm/LLMProvider";
import { getLLMProvider } from "../llm";
import { generateValidatedJSON } from "../llm/jsonOutput";
import { AFTERMATH_SYSTEM_PROMPT, buildInvestigationPrompt } from "../prompts/systemPrompt";
import { StructuredInvestigationResultSchema } from "../schema/investigationSchema";
import { eventBus } from "../events/EventBus";

export interface InvestigationRunResult {
  context: AIContext;
  plan: InvestigationPlan;
  result: StructuredInvestigationResult;
  validation: ValidationResult;
}

/**
 * InvestigationAgent
 *
 * Orchestrates the fixed investigation workflow described in the spec:
 * understand -> earliest abnormal event -> affected services -> dependencies
 * -> failed traces -> evidence -> hypotheses -> confidence -> conclusion.
 *
 * Each step uses InvestigationTools (deterministic, no LLM) to gather facts,
 * updates the InvestigationPlanner state, and emits progress events. Only the
 * final "generate conclusion" step calls the LLM — and only with the
 * already-vetted, structured facts gathered by the deterministic steps. The
 * LLM's output is then run through EvidenceValidator before being returned.
 */
export class InvestigationAgent {
  private contextBuilder = new AIContextBuilder();
  private planner = new InvestigationPlanner();
  private validator = new EvidenceValidator();

  constructor(private llm: LLMProvider = getLLMProvider()) {}

  async investigate(raw: RawInvestigationData): Promise<InvestigationRunResult> {
    const incidentId = raw.incident.id;
    eventBus.emit("ai.investigation.started", incidentId, { incidentId });

    // --- AI Context Builder ---
    const context = this.contextBuilder.build(raw);
    eventBus.emit("ai.context.prepared", incidentId, { evidenceCount: Object.keys(context.evidenceIndex).length });

    const tools = new InvestigationTools(context);
    const plan = this.planner.createPlan(incidentId);

    // Step 1: earliest abnormal event
    this.planner.startStep(plan, 1);
    const earliestEvent = tools.getEarliestAbnormalEvent();
    this.planner.completeStep(plan, 1, earliestEvent);

    // Step 2: initially affected service health
    this.planner.startStep(plan, 2);
    const primaryService = earliestEvent?.service ?? context.incidentSummaryContext.affectedServices[0];
    const serviceHealth = primaryService ? tools.getServiceHealth(primaryService) : null;
    this.planner.completeStep(plan, 2, serviceHealth);

    // Step 3: dependencies
    this.planner.startStep(plan, 3);
    const dependencies = primaryService ? tools.getServiceDependencies(primaryService) : null;
    this.planner.completeStep(plan, 3, dependencies);

    // Step 4: failed traces
    this.planner.startStep(plan, 4);
    const traces = tools.getFailedTraces();
    this.planner.completeStep(plan, 4, traces);

    // Step 5: evaluate hypotheses / generate conclusion (LLM-assisted)
    this.planner.startStep(plan, 5);
    const hypotheses = tools.getRootCauseCandidates();

    let result: StructuredInvestigationResult;
    try {
      result = await this.generateConclusion(context);
    } catch (err) {
      this.planner.failStep(plan, 5, err instanceof Error ? err.message : String(err));
      result = this.buildFallbackResult(context);
    }

    // --- Evidence Validator ---
    const validation = this.validator.validate(result, context);
    eventBus.emit("ai.evidence.validated", incidentId, { valid: validation.valid, issueCount: validation.issues.length });

    const finalResult = validation.correctedResult ?? result;
    eventBus.emit("ai.hypothesis.updated", incidentId, { hypotheses });
    eventBus.emit("ai.rootcause.assessed", incidentId, finalResult.rootCauseAssessment);

    if (validation.valid || (validation.correctedResult && validation.issues.every((i) => i.severity !== "error"))) {
      this.planner.completeStep(plan, 5, finalResult.rootCauseAssessment);
    } else {
      this.planner.completeStep(plan, 5, { ...finalResult.rootCauseAssessment, note: "completed with validator corrections" });
    }

    return { context, plan, result: finalResult, validation };
  }

  private async generateConclusion(context: AIContext): Promise<StructuredInvestigationResult> {
    const contextJson = JSON.stringify(context, null, 2);
    const prompt = buildInvestigationPrompt(contextJson);

    const parsed = await generateValidatedJSON(this.llm, prompt, StructuredInvestigationResultSchema, {
      systemPrompt: AFTERMATH_SYSTEM_PROMPT,
      temperature: 0.2,
    });

    return parsed as StructuredInvestigationResult;
  }

  /**
   * Deterministic, evidence-free-of-LLM fallback used only if the LLM call
   * fails twice (network error, no API key path failing, etc). Keeps the
   * pipeline demo-able even if the LLM is unreachable, and is explicit about
   * its own degraded nature rather than pretending to be a full analysis.
   */
  private buildFallbackResult(context: AIContext): StructuredInvestigationResult {
    const top = context.hypotheses[0];
    return {
      incidentSummary: {
        title: context.incidentSummaryContext.title,
        severity: context.incidentSummaryContext.severity,
        impact: `Affected services: ${context.incidentSummaryContext.affectedServices.join(", ") || "unknown"}.`,
      },
      rootCauseAssessment: {
        mostLikelyCause: top?.cause ?? "Unable to determine — LLM reasoning unavailable and no root cause candidates provided.",
        confidence: top ? Math.min(top.confidence, 0.5) : 0,
        confidenceExplanation:
          "This is a deterministic fallback generated without LLM reasoning because the AI provider was unavailable. Confidence is capped conservatively.",
      },
      whatHappened: "AI narrative generation was unavailable; showing structured facts only. See timeline and evidence context.",
      causalChain: [],
      keyEvidence: (top?.supportingEvidenceIds ?? []).map((id) => ({
        evidenceId: id,
        explanation: "Cited by the root cause candidate supplied by the investigation engine.",
      })),
      uncertainty: [
        "AI reasoning layer was unavailable; this is a deterministic fallback, not a full LLM-generated investigation.",
        ...context.uncertainties,
      ],
      recommendedActions: {
        immediate: primaryServiceRecommendation(context),
        investigation: ["Retry AI investigation once the LLM provider is reachable."],
        prevention: [],
      },
    };
  }
}

function primaryServiceRecommendation(context: AIContext): string[] {
  const service = context.incidentSummaryContext.affectedServices[0];
  return service ? [`Manually review recent changes to ${service}.`] : [];
}
