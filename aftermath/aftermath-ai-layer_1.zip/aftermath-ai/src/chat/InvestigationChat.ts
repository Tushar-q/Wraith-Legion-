import { AIContext, ChatMessage, ChatResponse } from "../types/ai";
import { LLMProvider } from "../llm/LLMProvider";
import { getLLMProvider } from "../llm";
import { generateValidatedJSON } from "../llm/jsonOutput";
import { AFTERMATH_SYSTEM_PROMPT, buildChatPrompt } from "../prompts/systemPrompt";
import { ChatResponseSchema } from "../schema/investigationSchema";

/**
 * InvestigationChat
 *
 * Incident-aware Q&A. Maintains a per-incident conversation history in
 * memory (process-local map — fine for a hackathon single-instance demo) so
 * follow-up questions retain context. Every answer is required (via schema +
 * post-hoc filtering) to only cite evidence IDs that actually exist in the
 * incident's evidence index, closing the same hallucination risk as the main
 * investigation pipeline.
 */
export class InvestigationChat {
  private histories: Map<string, ChatMessage[]> = new Map();

  constructor(private llm: LLMProvider = getLLMProvider()) {}

  getHistory(incidentId: string): ChatMessage[] {
    return this.histories.get(incidentId) ?? [];
  }

  clearHistory(incidentId: string): void {
    this.histories.delete(incidentId);
  }

  async ask(incidentId: string, context: AIContext, question: string): Promise<ChatResponse> {
    const history = this.getHistory(incidentId);
    const historyText = history.map((m) => `${m.role === "user" ? "User" : "AFTERMATH"}: ${m.content}`).join("\n");

    const contextJson = JSON.stringify(context, null, 2);
    const prompt = buildChatPrompt(contextJson, historyText, question);

    let response: ChatResponse;
    try {
      response = await generateValidatedJSON<ChatResponse>(this.llm, prompt, ChatResponseSchema, {
        systemPrompt: AFTERMATH_SYSTEM_PROMPT,
        temperature: 0.2,
      });
    } catch (err) {
      response = {
        answer:
          "I wasn't able to generate a grounded answer to that question right now (AI provider error). Please retry, or ask a more specific question about the timeline, evidence, or affected services.",
        evidenceIds: [],
        confidence: 0,
        uncertainty: [err instanceof Error ? err.message : String(err)],
      };
    }

    // Post-hoc grounding enforcement: strip any evidence ID the model cited that
    // doesn't actually exist, same discipline as EvidenceValidator applies to the
    // main investigation result.
    const validIds = new Set(Object.keys(context.evidenceIndex));
    const strippedInvalid = response.evidenceIds.filter((id) => !validIds.has(id));
    response.evidenceIds = response.evidenceIds.filter((id) => validIds.has(id));
    if (strippedInvalid.length > 0) {
      response.uncertainty = [
        ...response.uncertainty,
        `Removed ${strippedInvalid.length} evidence citation(s) not present in the incident's evidence index.`,
      ];
      response.confidence = Math.min(response.confidence, 0.5);
    }
    if (response.evidenceIds.length === 0 && response.confidence > 0.5) {
      response.confidence = 0.5;
    }

    const now = new Date().toISOString();
    const updatedHistory: ChatMessage[] = [
      ...history,
      { role: "user", content: question, timestamp: now },
      { role: "assistant", content: response.answer, timestamp: now },
    ];
    this.histories.set(incidentId, updatedHistory);

    return response;
  }
}
