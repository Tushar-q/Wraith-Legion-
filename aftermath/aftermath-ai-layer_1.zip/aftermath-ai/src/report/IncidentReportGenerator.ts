import { StructuredInvestigationResult } from "../types/ai";
import { eventBus } from "../events/EventBus";

export interface IncidentReport {
  incidentId: string;
  markdown: string;
  sections: {
    executiveSummary: string;
    whatHappened: string;
    mostLikelyRootCause: string;
    failurePropagation: string;
    keyEvidence: string;
    uncertainty: string;
    recommendedImmediateActions: string;
    recommendedPreventiveActions: string;
  };
}

/**
 * IncidentReportGenerator
 *
 * Turns a validated StructuredInvestigationResult into a clear, human-readable
 * report. Pure string templating — no additional LLM calls needed, since all
 * the language was already generated (and validated) upstream by the agent.
 * This keeps report generation fast, cheap, and immune to a second round of
 * possible LLM hallucination.
 */
export class IncidentReportGenerator {
  generate(incidentId: string, result: StructuredInvestigationResult): IncidentReport {
    const confidencePct = Math.round(result.rootCauseAssessment.confidence * 100);

    const executiveSummary = `${result.incidentSummary.title} (severity: ${result.incidentSummary.severity}). ${result.incidentSummary.impact}`;

    const mostLikelyRootCause = `${result.rootCauseAssessment.mostLikelyCause} (confidence: ${confidencePct}%). ${result.rootCauseAssessment.confidenceExplanation}`;

    const failurePropagation =
      result.causalChain.length > 0
        ? result.causalChain
            .sort((a, b) => a.step - b.step)
            .map((s) => `${s.step}. ${s.event} (${s.service})${s.evidenceIds.length ? ` — evidence: ${s.evidenceIds.join(", ")}` : ""}`)
            .join("\n")
        : "No detailed causal chain was established for this incident.";

    const keyEvidence =
      result.keyEvidence.length > 0
        ? result.keyEvidence.map((e) => `- [${e.evidenceId}] ${e.explanation}`).join("\n")
        : "No key evidence items were cited.";

    const uncertainty =
      result.uncertainty.length > 0 ? result.uncertainty.map((u) => `- ${u}`).join("\n") : "No significant uncertainty flagged.";

    const recommendedImmediateActions = formatActionList(result.recommendedActions.immediate);
    const recommendedPreventiveActions = formatActionList(result.recommendedActions.prevention);
    const investigationActions = formatActionList(result.recommendedActions.investigation);

    const markdown = `# Incident Report — ${incidentId}

## Executive Summary
${executiveSummary}

## What Happened
${result.whatHappened}

## Most Likely Root Cause
${mostLikelyRootCause}

## Failure Propagation
${failurePropagation}

## Key Evidence
${keyEvidence}

## Uncertainty
${uncertainty}

## Recommended Immediate Actions
${recommendedImmediateActions}

## Recommended Investigation Actions
${investigationActions}

## Recommended Preventive Actions
${recommendedPreventiveActions}
`;

    const report: IncidentReport = {
      incidentId,
      markdown,
      sections: {
        executiveSummary,
        whatHappened: result.whatHappened,
        mostLikelyRootCause,
        failurePropagation,
        keyEvidence,
        uncertainty,
        recommendedImmediateActions,
        recommendedPreventiveActions,
      },
    };

    eventBus.emit("ai.report.generated", incidentId, { incidentId });
    return report;
  }
}

function formatActionList(actions: string[]): string {
  return actions.length > 0 ? actions.map((a) => `- ${a}`).join("\n") : "- None identified.";
}
