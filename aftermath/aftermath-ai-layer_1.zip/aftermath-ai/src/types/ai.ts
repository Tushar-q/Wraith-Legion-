import { EvidenceRecord, Severity, TimelineEvent } from "./incident";

/* ============================== AI CONTEXT ============================== */

export interface IncidentSummaryContext {
  id: string;
  title: string;
  severity: Severity;
  detectedAt: string;
  affectedServices: string[];
}

export interface TimelineContextEntry extends TimelineEvent {
  order: number; // chronological index, 0 = earliest
  isEarliestAbnormalEvent: boolean;
}

export interface AnomalyContextEntry {
  service: string;
  metric: string;
  baseline: number;
  current: number;
  deltaPct: number; // % change from baseline
  anomalyScore: number;
  severityLabel: "minor" | "moderate" | "severe";
  timestamp?: string;
}

export interface DependencyContextEntry {
  source: string;
  target: string;
  relationship: "upstream_of" | "downstream_of"; // source depends on target -> source is downstream of target
}

export interface TraceContext {
  failedTraceCount: number;
  totalTraceCount?: number;
  commonFailurePoint: string;
  affectedPercentage: number;
  significance: "low" | "moderate" | "high" | "critical";
}

export interface Hypothesis {
  cause: string;
  confidence: number;
  relatedService?: string;
  supportingEvidenceIds: string[];
  category: "fact" | "hypothesis"; // confidence >= 0.9 with evidence => treated as near-fact, else hypothesis
}

export interface EvidenceIndexEntry extends EvidenceRecord {}

/**
 * The clean, LLM-ready context object. This is the single source of truth
 * passed to the agent, the report generator, the chat system, and the
 * recommendation engine — built once per incident and reused everywhere.
 */
export interface AIContext {
  incidentSummaryContext: IncidentSummaryContext;
  timelineContext: TimelineContextEntry[];
  anomalyContext: AnomalyContextEntry[];
  dependencyContext: DependencyContextEntry[];
  traceContext: TraceContext;
  hypotheses: Hypothesis[];
  evidenceIndex: Record<string, EvidenceIndexEntry>;
  uncertainties: string[]; // gaps identified while building context (e.g. missing evidence, low trace coverage)
}

/* ============================== PLANNER ============================== */

export type StepStatus = "pending" | "in_progress" | "completed" | "failed";

export interface PlanStep {
  step: number;
  objective: string;
  status: StepStatus;
  toolsUsed?: string[];
  result?: unknown;
  startedAt?: string;
  completedAt?: string;
}

export interface InvestigationPlan {
  incidentId: string;
  createdAt: string;
  steps: PlanStep[];
}

/* ============================== STRUCTURED AI OUTPUT ============================== */

export interface CausalChainStep {
  step: number;
  event: string;
  service: string;
  evidenceIds: string[];
}

export interface KeyEvidenceItem {
  evidenceId: string;
  explanation: string;
}

export interface RecommendedActions {
  immediate: string[];
  investigation: string[];
  prevention: string[];
}

export interface RootCauseAssessment {
  mostLikelyCause: string;
  confidence: number; // 0..1, post-validation (may be clamped down from LLM's raw claim)
  confidenceExplanation: string;
}

export interface IncidentSummaryBlock {
  title: string;
  severity: Severity;
  impact: string;
}

/**
 * The strict schema every AI investigation result must conform to.
 * Validated with zod (see src/schema/investigationSchema.ts) before use.
 */
export interface StructuredInvestigationResult {
  incidentSummary: IncidentSummaryBlock;
  rootCauseAssessment: RootCauseAssessment;
  whatHappened: string;
  causalChain: CausalChainStep[];
  keyEvidence: KeyEvidenceItem[];
  uncertainty: string[];
  recommendedActions: RecommendedActions;
}

/* ============================== VALIDATION ============================== */

export interface ValidationIssue {
  field: string;
  message: string;
  severity: "warning" | "error";
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
  /** The result after any automatic corrections (e.g. confidence clamped, unverifiable evidence stripped). */
  correctedResult?: StructuredInvestigationResult;
}

/* ============================== CHAT ============================== */

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface ChatResponse {
  answer: string;
  evidenceIds: string[];
  confidence: number;
  uncertainty: string[];
}

/* ============================== SIMILAR INCIDENTS ============================== */

export interface SimilarIncidentMatch {
  incidentId: string;
  similarity: number; // 0..1
  reason: string;
  previousResolution: string;
}
