import "dotenv/config";
import { AftermathService } from "../src/api/aftermathService";
import { RawInvestigationData } from "../src/types/incident";
import { assert, section } from "./testUtils";

// Deliberately sparse incident: a root cause candidate is suggested but there is
// almost no evidence to back it, and the evidence array is empty. This is the
// "insufficient evidence" adversarial case from the spec (Part 15, Test 3).
const sparseIncident: RawInvestigationData = {
  incident: {
    id: "INC-999",
    title: "Unexplained brief error spike on notification-service",
    severity: "medium",
    detectedAt: "2026-08-29T03:00:00Z",
    affectedServices: ["notification-service"],
  },
  timeline: [
    {
      timestamp: "2026-08-29T02:59:00Z",
      event: "error_rate_spike",
      service: "notification-service",
      significance: "medium",
    },
  ],
  anomalies: [
    {
      service: "notification-service",
      metric: "error_rate",
      baseline: 0.5,
      current: 3.2,
      anomalyScore: 0.55,
    },
  ],
  dependencies: [],
  traces: {
    failedTraceCount: 4,
    totalTraceCount: 8000,
    commonFailurePoint: "notification-service",
    affectedPercentage: 0.05,
  },
  rootCauseCandidates: [
    {
      cause: "possible transient upstream provider issue",
      confidence: 0.9, // deliberately overconfident given near-zero evidence — should get clamped
      relatedService: "notification-service",
      supportingEvidenceIds: [], // no evidence at all
    },
  ],
  evidence: [], // empty on purpose
  recentChanges: [],
};

async function main() {
  section("TEST 3: Insufficient evidence -> AI must not overstate confidence");

  const service = new AftermathService();
  const { result, validationIssues } = await service.investigate(sparseIncident);

  assert(validationIssues > 0, `validator flagged issues for the unsupported high-confidence claim (got ${validationIssues})`);
  assert(
    result.rootCauseAssessment.confidence <= 0.4,
    `confidence was clamped down for zero-evidence claim (got ${result.rootCauseAssessment.confidence})`
  );
  assert(
    result.uncertainty.length > 0,
    "uncertainty array is non-empty, acknowledging insufficient evidence"
  );
  const uncertaintyText = result.uncertainty.join(" ").toLowerCase();
  assert(
    /insufficient|not fully|not conclusiv|limited|low confidence|no verifiable/i.test(uncertaintyText),
    "uncertainty language reflects insufficient evidence"
  );

  console.log("\nConfidence after validation:", result.rootCauseAssessment.confidence);
  console.log("Uncertainty notes:", result.uncertainty);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
