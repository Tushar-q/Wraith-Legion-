# AFTERMATH — AI Intelligence Layer (Member 3 Subsystem)

This is the AI reasoning layer for AFTERMATH: it takes structured incident
investigation data (produced by Member 1's telemetry/anomaly detection and
Member 2's investigation engine) and turns it into an evidence-grounded root
cause explanation, a human-readable report, incident-specific recommendations,
similarity matching against past incidents, and a follow-up chat interface.

It does **not** detect anomalies, compute root causes from scratch, or render
any UI — it consumes structured data and reasons over it.

## Architecture

```
RawInvestigationData (from Members 1 & 2)
        |
        v
AIContextBuilder            — pure TS, no LLM. Normalizes/sorts/labels data,
        |                      AND internally runs HypothesisEngine +
        |                      EvidenceSufficiencyAssessor (see below).
        v
InvestigationAgent
        |
        +-- InvestigationTools (deterministic: timeline, health, deps, traces)
        +-- InvestigationPlanner (5-step plan, emits progress events)
        +-- InvestigationStatusStore (10-stage progress, pollable/recoverable)
        |
        v
   [LLM call: buildInvestigationPrompt + AFTERMATH_SYSTEM_PROMPT
    — told the independently-computed leading hypothesis and a hard
    confidence ceiling; it narrates, it does not choose the cause]
        |
        v
EvidenceValidator            — strips hallucinated evidence IDs, clamps
        |                        overconfident claims, softens absolute language
        v
StructuredInvestigationResult (schema-validated with zod, then confidence
        |                       clamped again to min(validator, evidence
        |                       sufficiency ceiling, hypothesis engine's own
        |                       confidence) — three independent limits)
        |
   +----+----------------+------------------+
   |                      |                  |
   v                      v                  v
IncidentReportGenerator  RecommendationEngine  InvestigationChat
   |                      |                  |
   v                      v                  v
Markdown report      immediate/investigation/  Evidence-grounded Q&A with
                      prevention actions        conversation memory + resolved
                                                 evidence descriptions

IncidentMemory — separate, optional: weighted feature-overlap similarity
                  against a small JSON store of past incidents.
```

### Hypothesis comparison, not root-cause repetition

The single most important structural change in this build: `AIContextBuilder`
no longer just passes `rootCauseCandidates` through. It runs them (plus any
hypotheses reasonably derivable from the data) through `HypothesisEngine`
(`src/hypothesis/HypothesisEngine.ts`), which independently scores each
candidate against:

- **temporal consistency** — does its earliest evidence come before other
  candidates' evidence?
- **trace consistency** — does its service match the trace analyzer's
  `commonFailurePoint`?
- **dependency consistency** — is its service upstream (a plausible origin)
  or downstream (more likely a symptom) in the dependency graph?
- **metric consistency** — how strong is its anomaly signal?

Each hypothesis ends up with a *recomputed* confidence (kept alongside the
original upstream-reported confidence for comparison), supporting evidence,
contradicting evidence, per-dimension consistency scores, and — for anything
that isn't the leader — concrete `rejectionReasons` grounded in that
evidence. The LLM is then explicitly told the leading hypothesis and a hard
confidence ceiling in its prompt (`InvestigationPromptGuidance`) and
instructed to narrate why it holds and why the alternatives don't; it cannot
pick a different root cause than what `HypothesisEngine` already determined.

### Evidence sufficiency caps confidence, always

`EvidenceSufficiencyAssessor` (`src/sufficiency/EvidenceSufficiencyAssessor.ts`)
scores how much the investigation actually has to work with — timeline,
metrics, traces, dependencies, and configuration-change coverage, plus raw
evidence record density — independent of any root-cause conclusion. Its
resulting `confidenceCeiling` is one of three values `InvestigationAgent`
takes the `min()` of before the number ever reaches a user: the evidence
validator's ceiling, the evidence-sufficiency ceiling, and the hypothesis
engine's own independently computed confidence for the leading hypothesis. A
confident-sounding LLM narrative cannot override any of the three.

## Setup

```bash
npm install
cp .env.example .env
# then fill in OPENAI_API_KEY in .env, or leave it blank / set
# AI_PROVIDER_MODE=mock to run entirely offline (see below)
```

### Live LLM mode (OpenAI)
Set `OPENAI_API_KEY` in `.env`. Model defaults to `gpt-4o-mini`
(`OPENAI_MODEL` to override). The provider is abstracted behind
`src/llm/LLMProvider.ts` — swapping to Gemini means implementing that one
interface in a new file and pointing `src/llm/index.ts` at it.

### Offline demo mode
Set `AI_PROVIDER_MODE=mock`. This activates `MockProvider`, a deterministic,
non-LLM fallback that reads the same context object a real LLM would see and
applies conservative heuristics — it never invents a root cause or cites an
evidence ID that doesn't exist, and it honors the same leading-hypothesis /
confidence-ceiling guidance a real LLM call would receive. **This exists
specifically so a hackathon demo never dies to a missing API key, rate limit,
or flaky wifi.** It is not a substitute for the real reasoning quality of an
LLM; use it as a safety net, not the default. If `OPENAI_API_KEY` is unset and
mode isn't explicitly `mock`, the system automatically falls back to
`MockProvider` with a console warning rather than crashing.

## Running the tests

```bash
export AI_PROVIDER_MODE=mock   # or configure OPENAI_API_KEY and omit this
npm run test:all
```

Individual tests: `npm run test:payment`, `test:database`,
`test:insufficient`, `test:multi-cause`, `test:chat`,
`test:hypothesis-comparison`, `test:status`.

All 7 tests pass in mock mode as of this build:
1. Payment timeout incident → payment-related root cause with evidence citations
2. Database slowdown → database/connection-pool root cause identified
3. Insufficient evidence → confidence clamped, `evidenceSufficiency.level` is
   `"limited"`/`"insufficient"`, final confidence respects the sufficiency ceiling
4. Multiple close-confidence candidates → uncertainty explicitly flagged, no false certainty
5. Chat question → answer cites real evidence IDs, follow-ups retain conversation context
6. **Hypothesis comparison** → both upstream candidates in the payment-timeout
   incident are independently evaluated; the retry-storm hypothesis is
   explicitly rejected with evidence-grounded reasons rather than silently dropped
7. **Investigation status/recovery** → progress advances through the 10-stage
   pipeline and settles at `"completed"`/100%, recoverable after the fact

## Integration contract

### What Members 1 & 2 must hand off
A `RawInvestigationData` object per incident (see `src/types/incident.ts`).
Shape matches the spec exactly: `incident`, `timeline`, `anomalies`,
`dependencies`, `traces`, `rootCauseCandidates`, `evidence`, optional
`recentChanges`. Three example payloads are in `/mock-data`.

### What this subsystem exposes
`src/api/routes.ts` has framework-agnostic handlers matching the spec's API
list:

| Endpoint | Handler | Input | Output |
|---|---|---|---|
| `POST /api/ai/investigate` | `handleInvestigate` | `{ rawData }` | context, plan, structured result (now includes `hypotheses`, `alternativeHypotheses`, `evidenceSufficiency`) |
| `POST /api/ai/plan` | `handlePlan` | `{ incidentId }` | `InvestigationPlan` |
| `POST /api/ai/chat` | `handleChat` | `{ incidentId, message }` | `ChatResponse` (now includes resolved `evidence: {evidenceId, description}[]`) |
| `GET /api/ai/similar-incidents/:incidentId` | `handleSimilarIncidents` | — | `SimilarIncidentMatch[]` |
| `POST /api/ai/recommendations` | `handleRecommendations` | `{ incidentId }` | `RecommendedActions` |
| `GET /api/ai/report/:incidentId` | `handleReport` | — | `IncidentReport` (markdown + sections) |
| `GET /api/ai/investigation/:incidentId` | `handleInvestigationStatus` | — | `InvestigationStatus` (status/progress/stage, pollable + recoverable) |

`chat`, `similar-incidents`, `recommendations`, and `report` all read from an
in-process cache keyed by `incidentId`, populated by the most recent
`investigate` call for that incident — so only `/investigate` needs the full
raw payload; everything else just needs the ID. `investigation` status reads
from a separate in-process `InvestigationStatusStore` that updates live
*during* an in-flight `investigate()` call (so it's pollable by a concurrent
request) and falls back to reconstructing a `"completed"` status from the
result cache if queried after the fact. Both are intentionally simple (`Map`s)
for the hackathon; swap for Redis/a DB if the demo needs multiple server
instances.

### Backwards compatibility
Every new field is additive. `StructuredInvestigationResult.hypotheses`,
`.alternativeHypotheses`, and `.evidenceSufficiency` are optional fields
appended to the existing shape — old consumers reading only
`rootCauseAssessment`/`whatHappened`/`causalChain`/etc. are unaffected.
Likewise `ChatResponse.evidence` is additive alongside the original
`evidenceIds`. No existing endpoint, field, or event name was removed or
renamed. New event names (`ai.evidence.collected`, `ai.hypothesis.evaluated`,
`ai.hypothesis.rejected`, etc.) were added to the `AftermathEventName` union
alongside the original ones — nothing was removed there either.

### Wiring into Next.js
Each handler returns `{ status, body }`. Example route file:

```ts
// app/api/ai/investigate/route.ts
import { handleInvestigate } from "@/aftermath-ai/src/api/routes";

export async function POST(req: Request) {
  const input = await req.json();
  const { status, body } = await handleInvestigate(input);
  return Response.json(body, { status });
}
```

### Events for Member 4's frontend
`src/events/EventBus.ts` exports a singleton `eventBus`. Subscribe with
`eventBus.on((event) => ...)`. The event set now covers the full progressive
pipeline the spec asked for:

`ai.investigation.started`, `ai.evidence.collected`, `ai.context.prepared`,
`ai.timeline.analyzed`, `ai.health.analyzed`, `ai.dependencies.analyzed`,
`ai.traces.correlated`, `ai.hypotheses.generated`, `ai.hypothesis.evaluated`
(one per candidate), `ai.hypothesis.rejected` (fired for each rejected
candidate, carrying its `rejectionReasons`), `ai.evidence.validated`,
`ai.hypothesis.updated`, `ai.rootcause.assessed`, `ai.report.generated`,
`ai.investigation.completed` — plus the original `ai.plan.created`/
`ai.step.*` and `investigation.plan.created`/`investigation.step.*` variants
for plan-specific UI, all still present. For the demo this is in-process;
relay it over a WebSocket/SSE endpoint if Member 4 needs live browser
updates. For polling instead of push, `GET /api/ai/investigation/:incidentId`
covers the same progression without needing a live socket connection.

## Design decisions worth knowing about

- **Evidence grounding is enforced in layers, not once.** `AIContextBuilder`
  drops any `supportingEvidenceIds` that don't exist in the evidence array;
  `HypothesisEngine` independently recomputes support/contradiction from raw
  timeline/trace/dependency/metric data rather than trusting a candidate's
  stated confidence; `EvidenceValidator` then checks the LLM's actual output
  the same way (strips hallucinated IDs, clamps confidence exceeding what
  cited evidence justifies, softens absolute language like "definitely
  caused" unless confidence ≥ 0.9 with evidence present).
- **The 5-step investigation plan is fixed, not LLM-generated**, and now
  overlaid with a 10-stage `InvestigationStatusStore` progression for
  frontend polling. An LLM-planned workflow is more "impressive" on paper but
  meaningfully more likely to produce a malformed or nonsensical plan during
  a live demo. A fixed plan/stage list with LLM-assisted narration only at
  the end is far more reliable, per the spec's explicit "do NOT rely entirely
  on the LLM for calculations" instruction.
- **The LLM never picks the root cause — it narrates one already picked.**
  `HypothesisEngine` determines the leading hypothesis deterministically;
  the prompt tells the LLM what that is and a hard confidence ceiling, and
  asks it to explain why it holds and why alternatives don't. This is what
  keeps the system from being "another module found the root cause and AI
  explained it" in the weakest sense — the *comparison* is genuinely
  independent, even though the final narrative text is still LLM-authored.
- **`IncidentReportGenerator` does not call the LLM again.** It templates the
  already-validated structured result. This avoids a second hallucination
  surface and keeps report generation instant.
- **`RecommendationEngine` combines LLM output with deterministic pattern
  rules** (timeout+config, retry storms, DB/connection-pool, bad deploys) so
  recommendations stay concrete even if the LLM's own suggestions get
  filtered out by the validator's generic-recommendation check.
- **`IncidentMemory` is deliberately just JSON + weighted Jaccard similarity**,
  per the explicit hackathon instruction not to build vector DB infrastructure.
- **Status tracking is deliberately a plain `Map`, not Redis/a queue**, per
  the explicit hackathon instruction. It's sufficient for a single-process
  demo server; a page refresh recovers via the same in-process store, or via
  the result cache if the store itself was cleared.

## Known limitations (read before demoing)

- `MockProvider` is a heuristic stand-in, not a real reasoning engine. Its
  *hypothesis comparison* is genuinely computed (that logic is entirely
  deterministic TypeScript in `HypothesisEngine`, independent of which LLM
  provider is active) — but its *narrative text* is templated, not reasoned.
  Use live mode for anything you want to actually showcase LLM reasoning
  quality on; the mock provider's job is demo reliability, not intelligence.
- The in-process `Map`-based cache and status store in `AftermathService`
  mean investigation state is lost on server restart and isn't shared across
  multiple server instances. Fine for a single-process demo; not
  production-ready.
- Confidence ceilings (`confidenceCeilingForEvidenceCount`: 0.4 / 0.65 / 0.8
  / 0.97 for 0/1/2/3+ evidence items; `EvidenceSufficiencyAssessor`'s
  `0.4 + 0.57 * score`) are reasonable heuristics, not calibrated statistical
  models — don't present the numeric confidence values as rigorously
  calibrated probabilities to judges without that caveat.
- `HypothesisEngine`'s contradiction detection currently only checks direct
  dependency-graph adjacency between two candidates' related services (see
  `isDependencyConnected`) — it won't catch a contradiction between two
  services that are two hops apart in the dependency graph. Good enough for
  the mock data's shape; worth strengthening if real QuickBite dependency
  graphs turn out deeper.
- No retry/backoff on the OpenAI call beyond the single JSON-schema-correction
  retry described in the spec (Part 6). A transient network failure during a
  live demo falls back to the deterministic fallback result in
  `InvestigationAgent.buildFallbackResult`, which is now grounded in the
  independently-computed leading hypothesis (not just `rootCauseCandidates[0]`)
  but is still honest about being a degraded, non-LLM-narrated result.
