import {
  AIContext,
  AlternativeHypothesisSummary,
  InvestigationPlan,
  StructuredInvestigationResult,
  ValidationResult,
} from "../types/ai";
import { RawInvestigationData } from "../types/incident";
import { AIContextBuilder } from "../context/AIContextBuilder";
import { InvestigationTools } from "../tools/investigationTools";
import { InvestigationPlanner } from "../planner/InvestigationPlanner";
import { EvidenceValidator } from "../validator/EvidenceValidator";
import { LLMProvider } from "../llm/LLMProvider";
import { getLLMProvider } from "../llm";
import { generateValidatedJSON } from "../llm/jsonOutput";
import { AFTERMATH_SYSTEM_PROMPT, buildInvestigationPrompt, InvestigationPromptGuidance } from "../prompts/systemPrompt";
import { StructuredInvestigationResultSchema } from "../schema/investigationSchema";
import { eventBus } from "../events/EventBus";
import { investigationStatusStore } from "../status/InvestigationStatusStore";

export interface InvestigationRunResult {
  context: AIContext;
  plan: InvestigationPlan;
  result: StructuredInvestigationResult;
  validation: ValidationResult;
}

/**
 * InvestigationAgent
 *
 * Orchestrates the fixed investigation workflow described in the spec:
 * understand -> earliest abnormal event -> affected services -> dependencies
 * -> failed traces -> evidence -> hypotheses -> confidence -> conclusion.
 *
 * Each step uses InvestigationTools (deterministic, no LLM) to gather facts,
 * updates the InvestigationPlanner state, and emits progress events. The LLM
 * is only ever asked to NARRATE a conclusion that HypothesisEngine already
 * independently determined — it never gets to pick a different root cause,
 * and its reported confidence is always clamped down to what the evidence
 * (via EvidenceValidator + EvidenceSufficiencyAssessor) actually supports.
 * This is what keeps the system from just repeating rootCauseCandidates[0].
 */
export class InvestigationAgent {
  private contextBuilder = new AIContextBuilder();
  private planner = new InvestigationPlanner();
  private validator = new EvidenceValidator();

  constructor(private llm: LLMProvider = getLLMProvider()) {}

  async investigate(raw: RawInvestigationData): Promise<InvestigationRunResult> {
    const incidentId = raw.incident.id;
    investigationStatusStore.init(incidentId);
    eventBus.emit("ai.investigation.started", incidentId, { incidentId });

    // --- AI Context Builder (also runs HypothesisEngine + EvidenceSufficiencyAssessor internally) ---
    investigationStatusStore.advance(incidentId, "collecting_evidence", `Collecting evidence for ${incidentId}.`);
    eventBus.emit("ai.evidence.collected", incidentId, { evidenceCount: raw.evidence.length });

    const context = this.contextBuilder.build(raw);
    eventBus.emit("ai.context.prepared", incidentId, { evidenceCount: Object.keys(context.evidenceIndex).length });

    investigationStatusStore.advance(
      incidentId,
      "timeline_analysis",
      context.timelineContext.length > 0
        ? `Earliest abnormal event: ${context.timelineContext.find((e) => e.isEarliestAbnormalEvent)?.event ?? "unknown"}.`
        : "No timeline events available."
    );
    eventBus.emit("ai.timeline.analyzed", incidentId, { eventCount: context.timelineContext.length });

    const tools = new InvestigationTools(context);
    const plan = this.planner.createPlan(incidentId);

    // Step 1: earliest abnormal event
    this.planner.startStep(plan, 1);
    const earliestEvent = tools.getEarliestAbnormalEvent();
    this.planner.completeStep(plan, 1, earliestEvent);

    // Step 2: initially affected service health
    this.planner.startStep(plan, 2);
    const primaryService = earliestEvent?.service ?? context.incidentSummaryContext.affectedServices[0];
    const serviceHealth = primaryService ? tools.getServiceHealth(primaryService) : null;
    this.planner.completeStep(plan, 2, serviceHealth);
    investigationStatusStore.advance(
      incidentId,
      "health_analysis",
      primaryService ? `${primaryService} identified as the initially affected service.` : "No primary service identified."
    );
    eventBus.emit("ai.health.analyzed", incidentId, { service: primaryService, health: serviceHealth });

    // Step 3: dependencies
    this.planner.startStep(plan, 3);
    const dependencies = primaryService ? tools.getServiceDependencies(primaryService) : null;
    this.planner.completeStep(plan, 3, dependencies);
    investigationStatusStore.advance(incidentId, "dependency_analysis", "Dependency graph analyzed for propagation paths.");
    eventBus.emit("ai.dependencies.analyzed", incidentId, { dependencies });

    // Step 4: failed traces
    this.planner.startStep(plan, 4);
    const traces = tools.getFailedTraces();
    this.planner.completeStep(plan, 4, traces);
    investigationStatusStore.advance(
      incidentId,
      "trace_analysis",
      `${traces.affectedPercentage}% of failed traces point to ${traces.commonFailurePoint}.`
    );
    eventBus.emit("ai.traces.correlated", incidentId, { traces });

    // --- Independent hypothesis comparison (Improvement 1/2) ---
    investigationStatusStore.advance(
      incidentId,
      "generating_hypotheses",
      `Generated ${context.hypothesisEvaluations.length} hypothesis candidate(s).`
    );
    eventBus.emit("ai.hypotheses.generated", incidentId, {
      count: context.hypothesisEvaluations.length,
      candidates: context.hypothesisEvaluations.map((h) => ({ title: h.title, confidence: h.confidence })),
    });

    // Step 5: evaluate hypotheses / generate conclusion (LLM-assisted)
    this.planner.startStep(plan, 5);
    investigationStatusStore.advance(incidentId, "evaluating_hypotheses", "Comparing hypotheses against evidence.");

    for (const h of context.hypothesisEvaluations) {
      eventBus.emit("ai.hypothesis.evaluated", incidentId, {
        hypothesis: h.title,
        confidence: h.confidence,
        supportingEvidenceCount: h.supportingEvidence.length,
        contradictingEvidenceCount: h.contradictingEvidence.length,
        status: h.status,
      });
      if (h.status === "rejected") {
        eventBus.emit("ai.hypothesis.rejected", incidentId, {
          hypothesis: h.title,
          confidence: h.confidence,
          rejectionReasons: h.rejectionReasons,
        });
      }
    }

    const leading = context.hypothesisEvaluations[0];

    let result: StructuredInvestigationResult;
    try {
      result = await this.generateConclusion(context, leading);
    } catch (err) {
      this.planner.failStep(plan, 5, err instanceof Error ? err.message : String(err));
      result = this.buildFallbackResult(context, leading);
    }

    // --- Evidence Validator ---
    investigationStatusStore.advance(incidentId, "validating_evidence", "Validating cited evidence and confidence claims.");
    const validation = this.validator.validate(result, context);
    eventBus.emit("ai.evidence.validated", incidentId, { valid: validation.valid, issueCount: validation.issues.length });

    const finalResult = validation.correctedResult ?? result;

    // --- Confidence calibration (Improvement 7): clamp to the MINIMUM of what the
    // evidence validator allowed, what the independently-computed leading hypothesis
    // itself justified, and the overall evidence sufficiency ceiling. The LLM's
    // stated confidence can never win against any of these three. ---
    investigationStatusStore.advance(incidentId, "assessing_root_cause", "Assessing final root cause confidence.");
    const sufficiencyCeiling = context.evidenceSufficiency.confidenceCeiling;
    const hypothesisCeiling = leading?.confidence ?? finalResult.rootCauseAssessment.confidence;
    finalResult.rootCauseAssessment.confidence = round2(
      Math.min(finalResult.rootCauseAssessment.confidence, sufficiencyCeiling, Math.max(hypothesisCeiling, 0.05))
    );

    // Attach the deterministic hypothesis comparison + sufficiency data to the
    // final result (additive fields — see types/ai.ts). This is what lets the
    // frontend show "Candidate A: 42%, Candidate B: 81%... rejected because...".
    finalResult.hypotheses = context.hypothesisEvaluations;
    finalResult.alternativeHypotheses = buildAlternativeHypothesesSummary(context.hypothesisEvaluations);
    finalResult.evidenceSufficiency = context.evidenceSufficiency;

    eventBus.emit("ai.hypothesis.updated", incidentId, { hypotheses: context.hypothesisEvaluations });
    eventBus.emit("ai.rootcause.assessed", incidentId, finalResult.rootCauseAssessment);

    if (validation.valid || (validation.correctedResult && validation.issues.every((i) => i.severity !== "error"))) {
      this.planner.completeStep(plan, 5, finalResult.rootCauseAssessment);
    } else {
      this.planner.completeStep(plan, 5, { ...finalResult.rootCauseAssessment, note: "completed with validator corrections" });
    }

    investigationStatusStore.complete(incidentId, finalResult);
    eventBus.emit("ai.investigation.completed", incidentId, {
      rootCause: finalResult.rootCauseAssessment.mostLikelyCause,
      confidence: finalResult.rootCauseAssessment.confidence,
      evidenceSufficiency: context.evidenceSufficiency.level,
    });

    return { context, plan, result: finalResult, validation };
  }

  private async generateConclusion(
    context: AIContext,
    leading: AIContext["hypothesisEvaluations"][number] | undefined
  ): Promise<StructuredInvestigationResult> {
    const contextJson = JSON.stringify(context, null, 2);

    const guidance: InvestigationPromptGuidance | undefined = leading
      ? {
          leadingHypothesisTitle: leading.title,
          leadingHypothesisConfidence: leading.confidence,
          confidenceCeiling: Math.min(leading.confidence, context.evidenceSufficiency.confidenceCeiling),
          alternatives: context.hypothesisEvaluations
            .filter((h) => h.id !== leading.id)
            .map((h) => ({ title: h.title, confidence: h.confidence, status: h.status, reasons: h.rejectionReasons })),
          evidenceSufficiencyLevel: context.evidenceSufficiency.level,
        }
      : undefined;

    const prompt = buildInvestigationPrompt(contextJson, guidance);

    const parsed = await generateValidatedJSON(this.llm, prompt, StructuredInvestigationResultSchema, {
      systemPrompt: AFTERMATH_SYSTEM_PROMPT,
      temperature: 0.2,
    });

    return parsed as StructuredInvestigationResult;
  }

  /**
   * Deterministic, LLM-free fallback used only if the LLM call fails twice
   * (network error, provider unreachable, etc). Keeps the pipeline demo-able
   * even if the LLM is unreachable. Now grounded in the independently
   * computed leading hypothesis rather than the raw upstream candidate.
   */
  private buildFallbackResult(
    context: AIContext,
    leading: AIContext["hypothesisEvaluations"][number] | undefined
  ): StructuredInvestigationResult {
    return {
      incidentSummary: {
        title: context.incidentSummaryContext.title,
        severity: context.incidentSummaryContext.severity,
        impact: `Affected services: ${context.incidentSummaryContext.affectedServices.join(", ") || "unknown"}.`,
      },
      rootCauseAssessment: {
        mostLikelyCause: leading?.title ?? "Unable to determine — LLM reasoning unavailable and no root cause candidates provided.",
        confidence: leading ? Math.min(leading.confidence, 0.5) : 0,
        confidenceExplanation:
          "This is a deterministic fallback generated without LLM reasoning because the AI provider was unavailable. Confidence reflects the independently computed hypothesis score, capped conservatively.",
      },
      whatHappened: "AI narrative generation was unavailable; showing structured facts only. See timeline and evidence context.",
      causalChain: [],
      keyEvidence: (leading?.supportingEvidence ?? []).map((id) => ({
        evidenceId: id,
        explanation: "Cited by the independently evaluated leading hypothesis.",
      })),
      uncertainty: [
        "AI reasoning layer was unavailable; this is a deterministic fallback, not a full LLM-generated investigation.",
        ...context.uncertainties,
      ],
      recommendedActions: {
        immediate: primaryServiceRecommendation(context),
        investigation: ["Retry AI investigation once the LLM provider is reachable."],
        prevention: [],
      },
    };
  }
}

function buildAlternativeHypothesesSummary(evaluations: AIContext["hypothesisEvaluations"]): AlternativeHypothesisSummary[] {
  return evaluations
    .filter((h) => h.status !== "leading")
    .map((h) => ({
      hypothesis: h.title,
      confidence: h.confidence,
      rejectedBecause:
        h.status === "rejected" ? h.rejectionReasons : ["Considered but not ruled out — remains a secondary possibility."],
    }));
}

function primaryServiceRecommendation(context: AIContext): string[] {
  const service = context.incidentSummaryContext.affectedServices[0];
  return service ? [`Manually review recent changes to ${service}.`] : [];
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
