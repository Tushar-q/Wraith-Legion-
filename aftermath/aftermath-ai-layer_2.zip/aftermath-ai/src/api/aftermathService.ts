import { AIContext, ChatResponse, InvestigationPlan, RecommendedActions, SimilarIncidentMatch, StructuredInvestigationResult } from "../types/ai";
import { RawInvestigationData } from "../types/incident";
import { AIContextBuilder } from "../context/AIContextBuilder";
import { InvestigationAgent } from "../agent/InvestigationAgent";
import { InvestigationPlanner } from "../planner/InvestigationPlanner";
import { IncidentReportGenerator, IncidentReport } from "../report/IncidentReportGenerator";
import { RecommendationEngine } from "../recommendations/RecommendationEngine";
import { IncidentMemory, CurrentIncidentFeatures } from "../memory/IncidentMemory";
import { InvestigationChat } from "../chat/InvestigationChat";
import { investigationStatusStore, InvestigationStatus } from "../status/InvestigationStatusStore";

/**
 * AftermathService
 *
 * Single facade over the whole AI intelligence layer, wiring context
 * building, the agent, report generation, recommendations, memory, and chat
 * together. This is what the API route handlers (and eventually Member 4's
 * frontend calls, and Member 2's data handoff) call into. It also caches the
 * built AIContext per incident so /api/ai/chat and /api/ai/recommendations
 * don't need the full raw payload resent on every request — only /api/ai/investigate
 * needs the raw data; everything else can reference the incidentId once investigated.
 */
export class AftermathService {
  private contextBuilder = new AIContextBuilder();
  private agent = new InvestigationAgent();
  private planner = new InvestigationPlanner();
  private reportGenerator = new IncidentReportGenerator();
  private recommendationEngine = new RecommendationEngine();
  private memory = new IncidentMemory();
  private chat = new InvestigationChat();

  // incidentId -> last built context + result, so chat/recommendations/report
  // can be called without resending the full raw payload every time.
  private cache: Map<string, { context: AIContext; result: StructuredInvestigationResult }> = new Map();

  async investigate(raw: RawInvestigationData): Promise<{
    context: AIContext;
    plan: InvestigationPlan;
    result: StructuredInvestigationResult;
    validationIssues: number;
  }> {
    const { context, plan, result, validation } = await this.agent.investigate(raw);
    this.cache.set(raw.incident.id, { context, result });
    return { context, plan, result, validationIssues: validation.issues.length };
  }

  /** Build just the plan without running full investigation — mirrors POST /api/ai/plan. */
  createPlan(incidentId: string): InvestigationPlan {
    return this.planner.createPlan(incidentId);
  }

  getReport(incidentId: string): IncidentReport {
    const cached = this.requireCached(incidentId);
    return this.reportGenerator.generate(incidentId, cached.result);
  }

  getRecommendations(incidentId: string): RecommendedActions {
    const cached = this.requireCached(incidentId);
    return this.recommendationEngine.generate(cached.result, cached.context);
  }

  async askChat(incidentId: string, message: string): Promise<ChatResponse> {
    const cached = this.requireCached(incidentId);
    return this.chat.ask(incidentId, cached.context, message);
  }

  getSimilarIncidents(incidentId: string): SimilarIncidentMatch[] {
    const cached = this.requireCached(incidentId);
    const top = cached.context.hypotheses[0];
    const features: CurrentIncidentFeatures = {
      id: incidentId,
      rootCauseCategory: cached.result.rootCauseAssessment.mostLikelyCause,
      affectedServices: cached.context.incidentSummaryContext.affectedServices,
      errorPatterns: cached.context.anomalyContext.map((a) => a.metric),
      metricAnomalies: cached.context.anomalyContext.map((a) => a.metric),
      failurePropagationPattern: cached.context.traceContext.commonFailurePoint,
    };
    return this.memory.findSimilarIncidents(features);
  }

  /** Persist the current incident into memory so future incidents can match against it. */
  archiveToMemory(incidentId: string, resolution: string): void {
    const cached = this.requireCached(incidentId);
    this.memory.save({
      id: incidentId,
      summary: cached.result.incidentSummary.title,
      rootCause: cached.result.rootCauseAssessment.mostLikelyCause,
      affectedServices: cached.context.incidentSummaryContext.affectedServices,
      incidentFeatures: cached.context.anomalyContext.map((a) => a.metric),
      resolution,
    });
  }

  /**
   * GET /api/ai/investigation/:incidentId support. Reads the live progress
   * store first (works while an investigation is still running); if the
   * store has no record — e.g. after a process restart — but the result
   * cache does, reconstructs a "completed" status from the cache so the
   * frontend can still recover the result after a page refresh.
   */
  getInvestigationStatus(incidentId: string): InvestigationStatus {
    const live = investigationStatusStore.get(incidentId);
    if (live) return live;

    const cached = this.cache.get(incidentId);
    if (cached) {
      return {
        incidentId,
        status: "completed",
        progress: 100,
        currentStage: "generating_report",
        completedStages: [],
        partialResult: cached.result,
        updatedAt: new Date().toISOString(),
      };
    }

    throw new Error(`No investigation found for incident "${incidentId}".`);
  }

  private requireCached(incidentId: string): { context: AIContext; result: StructuredInvestigationResult } {
    const cached = this.cache.get(incidentId);
    if (!cached) {
      throw new Error(
        `No investigation found in memory for incident "${incidentId}". Call POST /api/ai/investigate first.`
      );
    }
    return cached;
  }
}

// Shared singleton — fine for a single-process hackathon demo/API server.
export const aftermathService = new AftermathService();
