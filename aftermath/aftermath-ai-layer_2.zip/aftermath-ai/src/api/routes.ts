import { aftermathService } from "./aftermathService";
import { RawInvestigationData } from "../types/incident";

/**
 * Framework-agnostic handlers implementing the API contracts from the spec
 * (Part 12). Each function takes a plain JS body and returns { status, body }
 * so it can be dropped into Next.js route handlers, Express, or anything
 * else with a couple lines of glue. See README.md "Wiring into Next.js" for
 * the exact adapter code.
 */

export interface HandlerResult<T = unknown> {
  status: number;
  body: T;
}

/** POST /api/ai/investigate  { incidentId }  — expects raw data resolvable by incidentId, OR pass rawData directly for the hackathon demo. */
export async function handleInvestigate(input: { incidentId?: string; rawData?: RawInvestigationData }): Promise<HandlerResult> {
  if (!input.rawData) {
    return {
      status: 400,
      body: {
        error:
          "This demo API expects the raw investigation data inline as `rawData` (Member 2's investigation engine output). Wire in a lookup-by-incidentId once that module is integrated.",
      },
    };
  }
  try {
    const result = await aftermathService.investigate(input.rawData);
    return { status: 200, body: result };
  } catch (err) {
    return { status: 500, body: { error: err instanceof Error ? err.message : String(err) } };
  }
}

/** POST /api/ai/plan  { incidentId } */
export function handlePlan(input: { incidentId: string }): HandlerResult {
  const plan = aftermathService.createPlan(input.incidentId);
  return { status: 200, body: plan };
}

/** POST /api/ai/chat  { incidentId, message } */
export async function handleChat(input: { incidentId: string; message: string }): Promise<HandlerResult> {
  if (!input.message || !input.message.trim()) {
    return { status: 400, body: { error: "message is required" } };
  }
  try {
    const response = await aftermathService.askChat(input.incidentId, input.message);
    return { status: 200, body: response };
  } catch (err) {
    return { status: 404, body: { error: err instanceof Error ? err.message : String(err) } };
  }
}

/** GET /api/ai/similar-incidents/:incidentId */
export function handleSimilarIncidents(incidentId: string): HandlerResult {
  try {
    const matches = aftermathService.getSimilarIncidents(incidentId);
    return { status: 200, body: matches };
  } catch (err) {
    return { status: 404, body: { error: err instanceof Error ? err.message : String(err) } };
  }
}

/** POST /api/ai/recommendations  { incidentId } */
export function handleRecommendations(input: { incidentId: string }): HandlerResult {
  try {
    const recommendations = aftermathService.getRecommendations(input.incidentId);
    return { status: 200, body: recommendations };
  } catch (err) {
    return { status: 404, body: { error: err instanceof Error ? err.message : String(err) } };
  }
}

/** GET /api/ai/report/:incidentId — not in the original list but needed to expose IncidentReportGenerator's output. */
export function handleReport(incidentId: string): HandlerResult {
  try {
    const report = aftermathService.getReport(incidentId);
    return { status: 200, body: report };
  } catch (err) {
    return { status: 404, body: { error: err instanceof Error ? err.message : String(err) } };
  }
}

/**
 * GET /api/ai/investigation/:incidentId — investigation progress/recovery endpoint.
 * Lets the frontend poll progress while an investigation is running (concurrent
 * requests are served fine since the main investigate() call is awaiting I/O),
 * and recover the last known state after a page refresh.
 */
export function handleInvestigationStatus(incidentId: string): HandlerResult {
  try {
    const status = aftermathService.getInvestigationStatus(incidentId);
    return { status: 200, body: status };
  } catch (err) {
    return { status: 404, body: { error: err instanceof Error ? err.message : String(err) } };
  }
}
