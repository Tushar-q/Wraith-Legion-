import {
  AnomalyRecord,
  DependencyEdge,
  RawInvestigationData,
} from "../types/incident";
import {
  AIContext,
  AnomalyContextEntry,
  DependencyContextEntry,
  Hypothesis,
  TimelineContextEntry,
  TraceContext,
} from "../types/ai";
import { HypothesisEngine } from "../hypothesis/HypothesisEngine";
import { EvidenceSufficiencyAssessor } from "../sufficiency/EvidenceSufficiencyAssessor";

/**
 * AIContextBuilder
 *
 * Converts raw structured investigation data (from Members 1 & 2) into a
 * compact, organized, LLM-ready context object. This is pure, deterministic
 * TypeScript — no LLM calls happen here. It is reused by the investigation
 * agent, the report generator, the chat system, and the recommendation engine
 * so all four consumers reason over an identical, single source of truth.
 */
export class AIContextBuilder {
  private hypothesisEngine = new HypothesisEngine();
  private sufficiencyAssessor = new EvidenceSufficiencyAssessor();

  build(raw: RawInvestigationData): AIContext {
    const timelineContext = this.buildTimelineContext(raw);
    const anomalyContext = this.buildAnomalyContext(raw.anomalies);
    const dependencyContext = this.buildDependencyContext(raw.dependencies);
    const traceContext = this.buildTraceContext(raw);
    const evidenceIndex = this.buildEvidenceIndex(raw);
    const hypotheses = this.buildHypotheses(raw, evidenceIndex);
    const uncertainties = this.identifyUncertainties(raw, hypotheses);

    // Independent hypothesis comparison (Improvement 1/2): does NOT trust
    // `hypotheses` above at face value — recomputes support/contradiction/
    // consistency from the actual timeline/trace/dependency/metric data.
    const hypothesisEvaluations = this.hypothesisEngine.evaluate(raw, {
      timelineContext,
      anomalyContext,
      dependencyContext,
      traceContext,
      evidenceIndex,
    });

    // Evidence sufficiency (Improvement 4): caps how confident any downstream
    // conclusion is allowed to be, independent of what the LLM claims.
    const evidenceSufficiency = this.sufficiencyAssessor.assess(raw);

    return {
      incidentSummaryContext: {
        id: raw.incident.id,
        title: raw.incident.title ?? `Incident ${raw.incident.id}`,
        severity: raw.incident.severity,
        detectedAt: raw.incident.detectedAt,
        affectedServices: [...raw.incident.affectedServices],
      },
      timelineContext,
      anomalyContext,
      dependencyContext,
      traceContext,
      hypotheses,
      evidenceIndex,
      uncertainties,
      hypothesisEvaluations,
      evidenceSufficiency,
    };
  }

  private buildTimelineContext(raw: RawInvestigationData): TimelineContextEntry[] {
    const sorted = [...raw.timeline].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    // The earliest event with high significance is treated as the earliest abnormal event.
    // If none are marked "high", fall back to the chronologically first event.
    const earliestHighIdx = sorted.findIndex((e) => e.significance === "high");
    const earliestAbnormalIdx = earliestHighIdx !== -1 ? earliestHighIdx : 0;

    return sorted.map((event, i) => ({
      ...event,
      order: i,
      isEarliestAbnormalEvent: i === earliestAbnormalIdx && sorted.length > 0,
    }));
  }

  private buildAnomalyContext(anomalies: AnomalyRecord[]): AnomalyContextEntry[] {
    return anomalies
      .map((a) => {
        const deltaPct = a.baseline !== 0 ? ((a.current - a.baseline) / a.baseline) * 100 : 0;
        let severityLabel: AnomalyContextEntry["severityLabel"] = "minor";
        if (a.anomalyScore >= 0.85) severityLabel = "severe";
        else if (a.anomalyScore >= 0.6) severityLabel = "moderate";

        return {
          service: a.service,
          metric: a.metric,
          baseline: a.baseline,
          current: a.current,
          deltaPct: Math.round(deltaPct * 10) / 10,
          anomalyScore: a.anomalyScore,
          severityLabel,
          timestamp: a.timestamp,
        };
      })
      // Highlight important anomalies first.
      .sort((a, b) => b.anomalyScore - a.anomalyScore);
  }

  private buildDependencyContext(dependencies: DependencyEdge[]): DependencyContextEntry[] {
    // source depends on target => source is downstream of target, target is upstream of source
    return dependencies.map((d) => ({
      source: d.source,
      target: d.target,
      relationship: "downstream_of",
    }));
  }

  private buildTraceContext(raw: RawInvestigationData): TraceContext {
    const pct = raw.traces.affectedPercentage;
    let significance: TraceContext["significance"] = "low";
    if (pct >= 75) significance = "critical";
    else if (pct >= 40) significance = "high";
    else if (pct >= 15) significance = "moderate";

    return {
      failedTraceCount: raw.traces.failedTraceCount,
      totalTraceCount: raw.traces.totalTraceCount,
      commonFailurePoint: raw.traces.commonFailurePoint,
      affectedPercentage: raw.traces.affectedPercentage,
      significance,
    };
  }

  private buildEvidenceIndex(raw: RawInvestigationData): AIContext["evidenceIndex"] {
    const index: AIContext["evidenceIndex"] = {};
    for (const e of raw.evidence) {
      index[e.id] = e;
    }
    return index;
  }

  private buildHypotheses(
    raw: RawInvestigationData,
    evidenceIndex: AIContext["evidenceIndex"]
  ): Hypothesis[] {
    return raw.rootCauseCandidates
      .map((c) => {
        // Only count evidence IDs that actually exist in the evidence index —
        // this is the first line of defense against hallucinated citations,
        // enforced again later by EvidenceValidator on the LLM's own output.
        const verifiedEvidenceIds = (c.supportingEvidenceIds ?? []).filter((id) => id in evidenceIndex);
        return {
          cause: c.cause,
          confidence: c.confidence,
          relatedService: c.relatedService,
          supportingEvidenceIds: verifiedEvidenceIds,
          category: (c.confidence >= 0.9 && verifiedEvidenceIds.length > 0 ? "fact" : "hypothesis") as
            | "fact"
            | "hypothesis",
        };
      })
      .sort((a, b) => b.confidence - a.confidence);
  }

  private identifyUncertainties(raw: RawInvestigationData, hypotheses: Hypothesis[]): string[] {
    const uncertainties: string[] = [];

    if (raw.evidence.length === 0) {
      uncertainties.push("No evidence records were provided for this incident.");
    }
    if (hypotheses.length === 0) {
      uncertainties.push("No root cause candidates were provided.");
    }
    if (hypotheses.length > 1 && hypotheses[0].confidence - hypotheses[1].confidence < 0.15) {
      uncertainties.push(
        `Top root cause candidates are close in confidence (${hypotheses[0].cause} vs ${hypotheses[1].cause}) — root cause is not conclusively isolated.`
      );
    }
    if (raw.traces.affectedPercentage < 15) {
      uncertainties.push("Failed trace coverage is low; the common failure point may not represent the full picture.");
    }
    if (hypotheses.some((h) => h.confidence >= 0.7 && h.supportingEvidenceIds.length === 0)) {
      uncertainties.push("At least one high-confidence root cause candidate has no verifiable supporting evidence on record.");
    }

    return uncertainties;
  }
}
