export type AftermathEventName =
  | "investigation.plan.created"
  | "investigation.step.started"
  | "investigation.step.completed"
  | "investigation.step.failed"
  | "ai.investigation.started"
  | "ai.context.prepared"
  | "ai.plan.created"
  | "ai.step.started"
  | "ai.step.completed"
  | "ai.evidence.validated"
  | "ai.hypothesis.updated"
  | "ai.rootcause.assessed"
  | "ai.report.generated"
  // Progressive investigation events (additive — the original set above is untouched).
  | "ai.evidence.collected"
  | "ai.timeline.analyzed"
  | "ai.health.analyzed"
  | "ai.traces.correlated"
  | "ai.dependencies.analyzed"
  | "ai.hypotheses.generated"
  | "ai.hypothesis.evaluated"
  | "ai.hypothesis.rejected"
  | "ai.investigation.completed";

export interface AftermathEvent<T = unknown> {
  name: AftermathEventName;
  incidentId: string;
  timestamp: string;
  payload: T;
}

type Listener = (event: AftermathEvent) => void;

/**
 * Minimal in-process pub/sub. In production this would publish onto a real
 * message bus / websocket channel for Member 4's frontend to consume; for the
 * hackathon it's a synchronous EventEmitter-style bus that's trivial to wire
 * into a websocket relay later without changing any call sites.
 */
export class EventBus {
  private listeners: Listener[] = [];
  private log: AftermathEvent[] = [];

  on(listener: Listener): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  emit<T>(name: AftermathEventName, incidentId: string, payload: T): void {
    const event: AftermathEvent<T> = {
      name,
      incidentId,
      timestamp: new Date().toISOString(),
      payload,
    };
    this.log.push(event);
    for (const listener of this.listeners) {
      listener(event);
    }
  }

  /** Full event history for this process — handy for the demo to show a live feed. */
  getLog(): AftermathEvent[] {
    return [...this.log];
  }
}

// Shared singleton bus for the whole subsystem. Simple and sufficient for a
// single-process hackathon demo; swap for a real pub/sub if this becomes multi-process.
export const eventBus = new EventBus();
