import { RawInvestigationData } from "../types/incident";
import {
  AnomalyContextEntry,
  DependencyContextEntry,
  EvidenceIndexEntry,
  HypothesisConsistencyScores,
  HypothesisEvaluation,
  HypothesisStatus,
  TimelineContextEntry,
  TraceContext,
} from "../types/ai";
import { confidenceCeilingForEvidenceCount } from "../shared/confidenceCeiling";

export interface HypothesisEngineInput {
  timelineContext: TimelineContextEntry[];
  anomalyContext: AnomalyContextEntry[];
  dependencyContext: DependencyContextEntry[];
  traceContext: TraceContext;
  evidenceIndex: Record<string, EvidenceIndexEntry>;
}

interface CandidateWorking {
  id: string;
  title: string;
  relatedService?: string;
  originalConfidence: number;
  supportingEvidence: string[];
  earliestSupportingTimestamp: number; // ms epoch, Infinity if none
}

/**
 * HypothesisEngine
 *
 * The system previously took `rootCauseCandidates` from the upstream
 * investigation engine and effectively just repeated the top one. This
 * engine instead treats those candidates as HINTS and independently scores
 * each one against the actual timeline, trace, dependency, and metric data
 * this subsystem has on hand — producing supporting evidence, contradicting
 * evidence, per-dimension consistency scores, and (for anything that isn't
 * the leading hypothesis) concrete, evidence-grounded rejection reasons.
 *
 * Entirely deterministic — no LLM calls. The LLM later only narrates
 * *why* the engine's own conclusion holds, it never gets to overrule it.
 */
export class HypothesisEngine {
  evaluate(raw: RawInvestigationData, input: HypothesisEngineInput): HypothesisEvaluation[] {
    if (raw.rootCauseCandidates.length === 0) return [];

    const validEvidenceIds = new Set(Object.keys(input.evidenceIndex));

    const candidates: CandidateWorking[] = raw.rootCauseCandidates.map((c, i) => {
      const claimedIds = (c.supportingEvidenceIds ?? []).filter((id) => validEvidenceIds.has(id));
      const discoveredIds = c.relatedService
        ? Object.values(input.evidenceIndex)
            .filter((e) => e.service === c.relatedService)
            .map((e) => e.id)
        : [];
      const supportingEvidence = Array.from(new Set([...claimedIds, ...discoveredIds]));

      const timestamps = supportingEvidence
        .map((id) => new Date(input.evidenceIndex[id].timestamp).getTime())
        .filter((t) => !Number.isNaN(t));

      return {
        id: `hyp_${slug(c.cause)}_${i}`,
        title: c.cause,
        relatedService: c.relatedService,
        originalConfidence: c.confidence,
        supportingEvidence,
        earliestSupportingTimestamp: timestamps.length > 0 ? Math.min(...timestamps) : Infinity,
      };
    });

    const contradictions: Record<string, string[]> = {};
    for (const candidate of candidates) {
      const contradicting: string[] = [];
      for (const other of candidates) {
        if (other.id === candidate.id) continue;
        if (other.earliestSupportingTimestamp >= candidate.earliestSupportingTimestamp) continue;
        if (!other.relatedService || !candidate.relatedService) continue;
        const connected = isDependencyConnected(input.dependencyContext, candidate.relatedService, other.relatedService);
        if (connected) {
          const earlyEvidenceForOther = other.supportingEvidence.filter(
            (id) => new Date(input.evidenceIndex[id].timestamp).getTime() === other.earliestSupportingTimestamp
          );
          contradicting.push(...earlyEvidenceForOther);
        }
      }
      contradictions[candidate.id] = Array.from(new Set(contradicting));
    }

    const withEvidence = candidates
      .filter((c) => c.earliestSupportingTimestamp !== Infinity)
      .sort((a, b) => a.earliestSupportingTimestamp - b.earliestSupportingTimestamp);
    const temporalRank = new Map<string, number>();
    withEvidence.forEach((c, i) => {
      const scores = [1, 0.6, 0.3];
      temporalRank.set(c.id, scores[i] ?? 0.1);
    });

    const evaluations: HypothesisEvaluation[] = candidates.map((candidate) => {
      const temporal = temporalRank.get(candidate.id) ?? 0.2;
      const trace =
        candidate.relatedService && candidate.relatedService === input.traceContext.commonFailurePoint ? 1.0 : 0.3;
      const dependency = candidate.relatedService
        ? dependencyPositionScore(input.dependencyContext, candidate.relatedService)
        : 0.4;
      const metric = candidate.relatedService
        ? averageAnomalyScore(input.anomalyContext, candidate.relatedService)
        : 0.2;

      const consistency: HypothesisConsistencyScores = {
        temporal: round2(temporal),
        trace: round2(trace),
        dependency: round2(dependency),
        metric: round2(metric),
      };

      const computedConfidence = 0.3 * temporal + 0.2 * trace + 0.2 * dependency + 0.3 * metric;
      const contradictingEvidence = contradictions[candidate.id] ?? [];
      const contradictionPenalty = contradictingEvidence.length > candidate.supportingEvidence.length ? 0.5 : 1.0;

      const evidenceCeiling = confidenceCeilingForEvidenceCount(candidate.supportingEvidence.length);
      const blended = 0.55 * computedConfidence + 0.45 * candidate.originalConfidence;
      const finalConfidence = round2(Math.min(blended * contradictionPenalty, evidenceCeiling));

      const reasoning = buildReasoning(candidate, consistency, input, contradictingEvidence.length > 0);

      return {
        id: candidate.id,
        title: candidate.title,
        relatedService: candidate.relatedService,
        originalConfidence: candidate.originalConfidence,
        confidence: finalConfidence,
        supportingEvidence: candidate.supportingEvidence,
        contradictingEvidence,
        consistency,
        reasoning,
        rejectionReasons: [] as string[],
        status: "considered" as HypothesisStatus,
      };
    });

    evaluations.sort((a, b) => b.confidence - a.confidence);
    evaluations.forEach((evaluation, i) => {
      if (i === 0) {
        evaluation.status = "leading";
        return;
      }
      const leader = evaluations[0];
      const trailsSignificantly = leader.confidence - evaluation.confidence >= 0.25;
      const hasContradiction = evaluation.contradictingEvidence.length > 0;
      const status: HypothesisStatus = trailsSignificantly || hasContradiction ? "rejected" : "considered";
      evaluation.status = status;

      if (status === "rejected") {
        evaluation.rejectionReasons = buildRejectionReasons(evaluation, leader, hasContradiction);
      }
    });

    return evaluations;
  }
}

function slug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40);
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function isDependencyConnected(deps: DependencyContextEntry[], serviceA: string, serviceB: string): boolean {
  return deps.some(
    (d) => (d.source === serviceA && d.target === serviceB) || (d.source === serviceB && d.target === serviceA)
  );
}

function dependencyPositionScore(deps: DependencyContextEntry[], service: string): number {
  const isDependedUpon = deps.some((d) => d.target === service);
  const dependsOnOthers = deps.some((d) => d.source === service);
  if (isDependedUpon) return 1.0;
  if (dependsOnOthers) return 0.5;
  return 0.4;
}

function averageAnomalyScore(anomalies: AnomalyContextEntry[], service: string): number {
  const relevant = anomalies.filter((a) => a.service === service);
  if (relevant.length === 0) return 0.2;
  return relevant.reduce((sum, a) => sum + a.anomalyScore, 0) / relevant.length;
}

function buildReasoning(
  candidate: CandidateWorking,
  consistency: HypothesisConsistencyScores,
  input: HypothesisEngineInput,
  hasContradiction: boolean
): string[] {
  const reasoning: string[] = [];
  const service = candidate.relatedService ?? "the related service";

  if (candidate.earliestSupportingTimestamp !== Infinity) {
    reasoning.push(
      `Earliest supporting evidence for this hypothesis is timestamped ${new Date(
        candidate.earliestSupportingTimestamp
      ).toISOString()}.`
    );
  } else {
    reasoning.push("No timestamped supporting evidence was found for this hypothesis.");
  }

  if (consistency.trace >= 1.0) {
    reasoning.push(
      `${service} is the common failure point identified by trace analysis (${input.traceContext.affectedPercentage}% of failed traces).`
    );
  } else {
    reasoning.push(
      `Trace analysis's common failure point is "${input.traceContext.commonFailurePoint}", not ${service} — weaker trace consistency.`
    );
  }

  if (consistency.dependency >= 1.0) {
    reasoning.push(`${service} is depended upon by other affected services, consistent with being an upstream origin.`);
  } else if (consistency.dependency <= 0.5 && candidate.relatedService) {
    reasoning.push(`${service} itself depends on other services, making it more likely a downstream symptom than the origin.`);
  }

  if (consistency.metric > 0.6) {
    reasoning.push(`${service} shows a strong anomaly signal (avg score ${consistency.metric.toFixed(2)}).`);
  } else if (consistency.metric > 0) {
    reasoning.push(`${service} shows only a moderate-to-weak anomaly signal (avg score ${consistency.metric.toFixed(2)}).`);
  }

  if (hasContradiction) {
    reasoning.push(
      "Evidence tied to a dependency-connected service occurs earlier in the timeline, which weighs against this hypothesis being the origin."
    );
  }

  return reasoning;
}

function buildRejectionReasons(
  evaluation: HypothesisEvaluation,
  leader: HypothesisEvaluation,
  hasContradiction: boolean
): string[] {
  const reasons: string[] = [];

  if (hasContradiction) {
    reasons.push(
      `Evidence (${evaluation.contradictingEvidence.join(
        ", "
      )}) associated with a dependency-connected service occurred before this hypothesis's own earliest evidence, indicating the failure likely originated elsewhere.`
    );
  }

  if (evaluation.consistency.trace < leader.consistency.trace) {
    reasons.push("Trace analysis does not point to this hypothesis's service as the common failure point, unlike the leading hypothesis.");
  }

  if (evaluation.consistency.temporal < leader.consistency.temporal) {
    reasons.push("This hypothesis's evidence is not the earliest in the timeline, making it less likely to be the originating cause.");
  }

  if (reasons.length === 0) {
    reasons.push(
      "Insufficient evidence to conclusively reject this hypothesis; its computed confidence is simply lower than the leading explanation."
    );
  }

  return reasons;
}
