/**
 * Provider-abstracted LLM interface. Only one concrete provider is implemented
 * (OpenAI — see OpenAIProvider.ts) per the hackathon constraint of "one LLM
 * provider only", but nothing in the rest of the codebase depends on OpenAI
 * directly. Swapping to Gemini means writing one new file that implements
 * this interface.
 */
export interface LLMGenerateOptions {
  /** Force JSON-only output where the provider supports it natively. */
  jsonMode?: boolean;
  temperature?: number;
  maxTokens?: number;
  systemPrompt?: string;
}

export interface LLMProvider {
  generate(prompt: string, options?: LLMGenerateOptions): Promise<string>;
}
