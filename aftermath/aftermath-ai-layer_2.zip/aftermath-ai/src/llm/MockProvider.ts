import { LLMGenerateOptions, LLMProvider } from "./LLMProvider";
import { AIContext } from "../types/ai";

/**
 * Deterministic offline provider. Not a "real" LLM — it produces reasonable,
 * schema-shaped output by reading the actual AIContext JSON embedded in the
 * prompt (the same object the real LLM sees) and applying simple heuristics
 * on top of it. This exists so the demo never dies to a missing API key, rate
 * limit, or network outage during a live hackathon judging round.
 *
 * It is intentionally conservative: it never invents a root cause beyond
 * whatever is already present in context.hypotheses, and it never cites an
 * evidence ID that isn't in context.evidenceIndex.
 */
export class MockProvider implements LLMProvider {
  async generate(prompt: string, options: LLMGenerateOptions = {}): Promise<string> {
    const context = this.extractContext(prompt);

    if (!context) {
      return options.jsonMode
        ? JSON.stringify({ answer: "Insufficient context to answer.", evidenceIds: [], confidence: 0, uncertainty: ["No context provided to mock provider."] })
        : "Insufficient context to answer.";
    }

    if (options.jsonMode) {
      if (/USER QUESTION:/.test(prompt)) {
        return this.mockChatResponse(prompt, context);
      }
      return this.mockInvestigationResult(prompt, context);
    }
    return this.mockFreeText(context);
  }

  /** Pulls the AIContext JSON blob out of a prompt built by buildInvestigationPrompt/buildChatPrompt. */
  private extractContext(prompt: string): AIContext | null {
    const marker = "INVESTIGATION CONTEXT:";
    const idx = prompt.indexOf(marker);
    if (idx === -1) return null;
    const afterMarker = prompt.slice(idx + marker.length).trim();

    const start = afterMarker.indexOf("{");
    if (start === -1) return null;

    let depth = 0;
    let end = -1;
    for (let i = start; i < afterMarker.length; i++) {
      if (afterMarker[i] === "{") depth++;
      else if (afterMarker[i] === "}") {
        depth--;
        if (depth === 0) {
          end = i;
          break;
        }
      }
    }
    if (end === -1) return null;

    try {
      return JSON.parse(afterMarker.slice(start, end + 1)) as AIContext;
    } catch {
      return null;
    }
  }

  private mockInvestigationResult(prompt: string, context: AIContext): string {
    // Honor the deterministic guidance block (leading hypothesis + confidence ceiling)
    // when present, so the offline mock path stays consistent with the real LLM path.
    const leadingMatch = prompt.match(/Leading hypothesis:\s*"([^"]*)"\s*\(independently computed confidence:\s*([\d.]+)\)/);
    const ceilingMatch = prompt.match(/MUST NOT exceed\s*([\d.]+)/);

    const top = context.hypotheses[0];
    const service =
      top?.relatedService ?? context.incidentSummaryContext.affectedServices[0] ?? "the affected service";
    const evidenceIds = top?.supportingEvidenceIds ?? [];

    const cause = leadingMatch?.[1] ?? top?.cause ?? "an undetermined issue — no root cause candidates were supplied";
    let confidence = leadingMatch ? parseFloat(leadingMatch[2]) : top?.confidence ?? 0.3;
    if (ceilingMatch) confidence = Math.min(confidence, parseFloat(ceilingMatch[1]));

    const causalChain = context.timelineContext
      .filter((e) => e.significance === "high")
      .slice(0, 4)
      .map((e, i) => ({
        step: i + 1,
        event: e.event,
        service: e.service,
        evidenceIds: evidenceIds.slice(i, i + 1),
      }));

    const result = {
      incidentSummary: {
        title: context.incidentSummaryContext.title,
        severity: context.incidentSummaryContext.severity,
        impact: `${context.incidentSummaryContext.affectedServices.join(", ")} experienced degraded behavior.`,
      },
      rootCauseAssessment: {
        mostLikelyCause: cause,
        confidence,
        confidenceExplanation:
          confidence >= 0.85
            ? "Strong, directly supporting evidence with consistent timing across the timeline and traces."
            : evidenceIds.length > 0
            ? "Evidence points this direction but is not fully conclusive."
            : "No verifiable evidence supports this candidate strongly; treat as a hypothesis only.",
      },
      whatHappened: `Based on available telemetry, ${service} began deviating from baseline behavior around the detection window. The pattern is consistent with: ${cause}.`,
      causalChain,
      keyEvidence: evidenceIds.map((id) => ({ evidenceId: id, explanation: "Cited by the root cause candidate supplied by the investigation engine." })),
      uncertainty: context.uncertainties.length > 0 ? [...context.uncertainties] : [],
      recommendedActions: {
        immediate: [`Review the most recent change to ${service}.`],
        investigation: [`Inspect ${service} logs and traces around the detection window.`],
        prevention: [`Add stronger pre-deploy validation and alerting for ${service}.`],
      },
    };
    return JSON.stringify(result);
  }

  private mockChatResponse(prompt: string, context: AIContext): string {
    const questionMatch = prompt.match(/USER QUESTION:\s*([\s\S]*?)(?:\n\nRespond|$)/i);
    const question = (questionMatch?.[1] ?? "").trim();
    const top = context.hypotheses[0];
    const evidenceIds = top?.supportingEvidenceIds ?? [];

    const answer = top
      ? `${top.relatedService ?? context.incidentSummaryContext.affectedServices[0] ?? "The affected service"} is considered the most likely origin because it shows the strongest anomaly signal and ${
          context.traceContext.affectedPercentage
        }% of failed traces point to ${context.traceContext.commonFailurePoint}. This is supported by ${
          evidenceIds.length > 0 ? evidenceIds.join(", ") : "the available telemetry, though no specific evidence records were cited"
        }.`
      : `There isn't a clear root cause candidate in the current investigation data to answer "${question}" conclusively.`;

    const response = {
      answer,
      evidenceIds,
      confidence: top?.confidence ?? 0.3,
      uncertainty: context.uncertainties,
    };
    return JSON.stringify(response);
  }

  private mockFreeText(context: AIContext): string {
    const cause = context.hypotheses[0]?.cause ?? "an undetermined change";
    return `Based on the available investigation data, the most consistent explanation is: ${cause}. (Generated by offline mock provider — set OPENAI_API_KEY and AI_PROVIDER_MODE=live for full LLM reasoning.)`;
  }
}
