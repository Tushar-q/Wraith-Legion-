import OpenAI from "openai";
import { LLMGenerateOptions, LLMProvider } from "./LLMProvider";

export class OpenAIProvider implements LLMProvider {
  private client: OpenAI;
  private model: string;

  constructor(apiKey: string = process.env.OPENAI_API_KEY ?? "", model: string = process.env.OPENAI_MODEL ?? "gpt-4o-mini") {
    if (!apiKey) {
      throw new Error(
        "OPENAI_API_KEY is not set. Set it in your environment or .env file, or use AI_PROVIDER_MODE=mock for offline demos."
      );
    }
    this.client = new OpenAI({ apiKey });
    this.model = model;
  }

  async generate(prompt: string, options: LLMGenerateOptions = {}): Promise<string> {
    const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [];
    if (options.systemPrompt) {
      messages.push({ role: "system", content: options.systemPrompt });
    }
    messages.push({ role: "user", content: prompt });

    const response = await this.client.chat.completions.create({
      model: this.model,
      messages,
      temperature: options.temperature ?? 0.2,
      max_tokens: options.maxTokens ?? 1500,
      ...(options.jsonMode ? { response_format: { type: "json_object" as const } } : {}),
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("OpenAI returned an empty response.");
    }
    return content;
  }
}
