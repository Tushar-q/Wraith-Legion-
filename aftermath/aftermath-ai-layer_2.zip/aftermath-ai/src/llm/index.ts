import { LLMProvider } from "./LLMProvider";
import { OpenAIProvider } from "./OpenAIProvider";
import { MockProvider } from "./MockProvider";

export { LLMProvider, LLMGenerateOptions } from "./LLMProvider";
export { OpenAIProvider } from "./OpenAIProvider";
export { MockProvider } from "./MockProvider";

let cachedProvider: LLMProvider | null = null;

/**
 * Returns the configured LLMProvider singleton.
 * AI_PROVIDER_MODE=mock forces the offline MockProvider regardless of keys present.
 * Otherwise defaults to OpenAI; falls back to MockProvider if no API key is set,
 * so the rest of the system never has to special-case "no key configured".
 */
export function getLLMProvider(): LLMProvider {
  if (cachedProvider) return cachedProvider;

  const mode = process.env.AI_PROVIDER_MODE ?? "live";
  if (mode === "mock") {
    cachedProvider = new MockProvider();
    return cachedProvider;
  }

  if (!process.env.OPENAI_API_KEY) {
    // eslint-disable-next-line no-console
    console.warn("[aftermath-ai] OPENAI_API_KEY not set — falling back to MockProvider for this session.");
    cachedProvider = new MockProvider();
    return cachedProvider;
  }

  cachedProvider = new OpenAIProvider();
  return cachedProvider;
}
