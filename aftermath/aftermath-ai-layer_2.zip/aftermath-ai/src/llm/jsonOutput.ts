import { z } from "zod";
import { LLMProvider } from "./LLMProvider";

/**
 * Strips markdown code fences some models add despite instructions not to.
 */
function stripFences(text: string): string {
  const trimmed = text.trim();
  const fenceMatch = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return fenceMatch ? fenceMatch[1] : trimmed;
}

/**
 * Calls the LLM expecting a JSON object matching `schema`. On parse or schema
 * failure, retries ONCE with an explicit correction instruction appended
 * (per spec Part 6: "If malformed: Retry once, Request schema correction,
 * Fall back gracefully"). Throws only if both attempts fail — callers should
 * catch and fall back to a degraded-but-honest response.
 */
export async function generateValidatedJSON<T>(
  provider: LLMProvider,
  prompt: string,
  schema: z.ZodType<T, z.ZodTypeDef, any>,
  options: { systemPrompt?: string; temperature?: number } = {}
): Promise<T> {
  const attempt = async (p: string): Promise<T> => {
    const raw = await provider.generate(p, {
      jsonMode: true,
      systemPrompt: options.systemPrompt,
      temperature: options.temperature,
    });
    const cleaned = stripFences(raw);
    const parsed = JSON.parse(cleaned);
    return schema.parse(parsed);
  };

  try {
    return await attempt(prompt);
  } catch (firstError) {
    const correctionPrompt = `${prompt}\n\nYour previous response was not valid JSON matching the required schema (error: ${
      firstError instanceof Error ? firstError.message : String(firstError)
    }). Respond again with ONLY a single valid JSON object matching the exact schema requested — no markdown, no commentary, no trailing text.`;
    try {
      return await attempt(correctionPrompt);
    } catch (secondError) {
      throw new Error(
        `LLM failed to produce schema-valid JSON after retry. First error: ${
          firstError instanceof Error ? firstError.message : String(firstError)
        }. Second error: ${secondError instanceof Error ? secondError.message : String(secondError)}`
      );
    }
  }
}
