import fs from "fs";
import path from "path";
import { SimilarIncidentMatch } from "../types/ai";

export interface StoredIncident {
  id: string;
  summary: string;
  rootCause: string;
  affectedServices: string[];
  incidentFeatures: string[]; // free-text tags e.g. "timeout", "retry-storm", "database", "config-change"
  resolution: string;
}

export interface CurrentIncidentFeatures {
  id: string;
  rootCauseCategory: string; // short category string, e.g. "timeout configuration"
  affectedServices: string[];
  errorPatterns: string[]; // e.g. ["retry-storm", "latency-spike"]
  metricAnomalies: string[]; // e.g. ["latency", "error_rate"]
  failurePropagationPattern: string; // e.g. "payment-service -> order-service"
}

const DEFAULT_STORE_PATH = path.join(__dirname, "..", "..", "data", "incident-memory.json");

/**
 * IncidentMemory
 *
 * Intentionally simple, per the hackathon constraint against building vector
 * DB infrastructure: incidents are stored as flat JSON, and similarity is
 * weighted feature-overlap matching (Jaccard-style over tag sets, plus an
 * exact-category bonus). This is easy to reason about, has zero external
 * dependencies, and is good enough to produce believable "similar incidents"
 * results for a demo.
 */
export class IncidentMemory {
  private storePath: string;

  constructor(storePath: string = DEFAULT_STORE_PATH) {
    this.storePath = storePath;
    this.ensureStoreExists();
  }

  private ensureStoreExists() {
    const dir = path.dirname(this.storePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(this.storePath)) {
      fs.writeFileSync(this.storePath, JSON.stringify([], null, 2));
    }
  }

  private readAll(): StoredIncident[] {
    const raw = fs.readFileSync(this.storePath, "utf-8");
    return JSON.parse(raw);
  }

  private writeAll(incidents: StoredIncident[]) {
    fs.writeFileSync(this.storePath, JSON.stringify(incidents, null, 2));
  }

  save(incident: StoredIncident): void {
    const all = this.readAll();
    const idx = all.findIndex((i) => i.id === incident.id);
    if (idx >= 0) {
      all[idx] = incident;
    } else {
      all.push(incident);
    }
    this.writeAll(all);
  }

  getAll(): StoredIncident[] {
    return this.readAll();
  }

  /**
   * findSimilarIncidents
   *
   * Weighted feature matching:
   *  - affected services overlap: weight 0.35 (Jaccard)
   *  - error patterns / features overlap: weight 0.35 (Jaccard)
   *  - root cause category exact/substring match: weight 0.30 (binary-ish)
   */
  findSimilarIncidents(current: CurrentIncidentFeatures, topN: number = 3): SimilarIncidentMatch[] {
    const all = this.readAll().filter((i) => i.id !== current.id);
    const currentFeatureSet = new Set([...current.errorPatterns, ...current.metricAnomalies]);
    const currentServiceSet = new Set(current.affectedServices);

    const scored = all.map((incident) => {
      const serviceOverlap = jaccard(currentServiceSet, new Set(incident.affectedServices));
      const featureOverlap = jaccard(currentFeatureSet, new Set(incident.incidentFeatures));
      const causeMatch = textSimilarityBonus(current.rootCauseCategory, incident.rootCause);

      const similarity = serviceOverlap * 0.35 + featureOverlap * 0.35 + causeMatch * 0.3;

      const reasonParts: string[] = [];
      if (causeMatch > 0.5) reasonParts.push(`similar root cause (${incident.rootCause})`);
      if (serviceOverlap > 0) reasonParts.push(`overlapping affected services`);
      if (featureOverlap > 0) reasonParts.push(`similar failure pattern`);
      const reason = reasonParts.length > 0 ? reasonParts.join("; ") : "low overall similarity";

      return {
        incidentId: incident.id,
        similarity: Math.round(similarity * 100) / 100,
        reason,
        previousResolution: incident.resolution,
      };
    });

    return scored
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, topN)
      .filter((m) => m.similarity > 0);
  }
}

function jaccard(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 && b.size === 0) return 0;
  const intersection = [...a].filter((x) => b.has(x)).length;
  const union = new Set([...a, ...b]).size;
  return union === 0 ? 0 : intersection / union;
}

function textSimilarityBonus(a: string, b: string): number {
  const normA = a.toLowerCase();
  const normB = b.toLowerCase();
  if (normA === normB) return 1;
  const wordsA = new Set(normA.split(/\W+/).filter(Boolean));
  const wordsB = new Set(normB.split(/\W+/).filter(Boolean));
  return jaccard(wordsA, wordsB);
}
