import { InvestigationPlan, PlanStep, StepStatus } from "../types/ai";
import { eventBus } from "../events/EventBus";

const DEFAULT_OBJECTIVES = [
  "Identify the earliest abnormal event",
  "Analyze the initially affected service",
  "Inspect service dependencies",
  "Analyze failed request traces",
  "Evaluate root cause hypotheses",
];

/**
 * InvestigationPlanner
 *
 * Produces a fixed investigation workflow (mirrors the spec's fixed 5-step
 * flow) and tracks step state transitions, emitting events at each transition
 * so Member 4 can visualize progress live. This is deliberately NOT dynamic
 * LLM-generated planning — a fixed, well-tested plan is far more reliable to
 * demo than an LLM occasionally producing a malformed or nonsensical plan.
 */
export class InvestigationPlanner {
  createPlan(incidentId: string, objectives: string[] = DEFAULT_OBJECTIVES): InvestigationPlan {
    const plan: InvestigationPlan = {
      incidentId,
      createdAt: new Date().toISOString(),
      steps: objectives.map((objective, i) => ({
        step: i + 1,
        objective,
        status: "pending" as StepStatus,
      })),
    };

    eventBus.emit("investigation.plan.created", incidentId, plan);
    eventBus.emit("ai.plan.created", incidentId, plan);
    return plan;
  }

  startStep(plan: InvestigationPlan, stepNumber: number): PlanStep {
    const step = this.getStep(plan, stepNumber);
    step.status = "in_progress";
    step.startedAt = new Date().toISOString();

    eventBus.emit("investigation.step.started", plan.incidentId, step);
    eventBus.emit("ai.step.started", plan.incidentId, step);
    return step;
  }

  completeStep(plan: InvestigationPlan, stepNumber: number, result?: unknown): PlanStep {
    const step = this.getStep(plan, stepNumber);
    step.status = "completed";
    step.completedAt = new Date().toISOString();
    step.result = result;

    eventBus.emit("investigation.step.completed", plan.incidentId, step);
    eventBus.emit("ai.step.completed", plan.incidentId, step);
    return step;
  }

  failStep(plan: InvestigationPlan, stepNumber: number, reason: string): PlanStep {
    const step = this.getStep(plan, stepNumber);
    step.status = "failed";
    step.completedAt = new Date().toISOString();
    step.result = { error: reason };

    eventBus.emit("investigation.step.failed", plan.incidentId, step);
    return step;
  }

  private getStep(plan: InvestigationPlan, stepNumber: number): PlanStep {
    const step = plan.steps.find((s) => s.step === stepNumber);
    if (!step) {
      throw new Error(`Plan for incident ${plan.incidentId} has no step ${stepNumber}`);
    }
    return step;
  }
}
