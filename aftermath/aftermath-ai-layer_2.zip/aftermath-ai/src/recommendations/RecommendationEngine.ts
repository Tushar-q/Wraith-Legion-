import { AIContext, RecommendedActions, StructuredInvestigationResult } from "../types/ai";

interface PatternRule {
  /** Matches against the root cause text and/or evidence descriptions (case-insensitive substring). */
  matches: (causeText: string, context: AIContext) => boolean;
  immediate?: (service: string) => string;
  investigation?: (service: string) => string;
  prevention?: (service: string) => string;
}

/**
 * Deterministic pattern -> recommendation rules. These fire in ADDITION to
 * whatever the LLM proposed (see RecommendationEngine.generate), giving a
 * guaranteed floor of concrete, incident-specific recommendations even if the
 * LLM's own suggestions get stripped for being too generic by EvidenceValidator's
 * checkRecommendationsAreSpecific check.
 */
const PATTERN_RULES: PatternRule[] = [
  {
    matches: (t) => /timeout/i.test(t) && /config/i.test(t),
    immediate: (s) => `Review and roll back the recent timeout configuration change on ${s}.`,
    investigation: (s) => `Diff the current ${s} configuration against the last known-good version to confirm the exact timeout parameter changed.`,
    prevention: (s) => `Require config-change review/approval and add automated rollback on error-rate spikes for ${s}.`,
  },
  {
    matches: (t, ctx) => /retry/i.test(t) || ctx.anomalyContext.some((a) => /retry/i.test(a.metric)),
    immediate: (s) => `Reduce or temporarily disable aggressive retry behavior calling into ${s}.`,
    prevention: () => `Implement exponential retry backoff and jitter for downstream calls to prevent retry storms.`,
  },
  {
    matches: (t) => /timeout|latency/i.test(t),
    prevention: (s) => `Add circuit breaker protection around calls to ${s} to contain latency spikes from cascading downstream.`,
  },
  {
    matches: (t) => /database|db|query|connection pool/i.test(t),
    immediate: (s) => `Check ${s} database connection pool saturation and slow query log for the incident window.`,
    investigation: (s) => `Review recent schema migrations or index changes affecting ${s}.`,
    prevention: (s) => `Add query performance regression testing to the ${s} deployment pipeline.`,
  },
  {
    matches: (t) => /deploy/i.test(t),
    immediate: (s) => `Roll back the most recent deployment to ${s}.`,
    investigation: (s) => `Review the diff of the most recent ${s} deployment for the change that correlates with the incident start time.`,
  },
];

/**
 * RecommendationEngine
 *
 * Produces recommendations classified as immediate / investigation /
 * preventive, grounded in the actual root cause and evidence of this
 * specific incident. Combines:
 *   1. The LLM's own recommendations (already produced as part of the
 *      structured investigation result, and already evidence-checked).
 *   2. Deterministic pattern-matched recommendations that fire on
 *      recognizable incident signatures (timeout configs, retries,
 *      database slowdowns, bad deploys), guaranteeing specificity even
 *      when the LLM output is generic or unavailable.
 * Results are de-duplicated.
 */
export class RecommendationEngine {
  generate(result: StructuredInvestigationResult, context: AIContext): RecommendedActions {
    const causeText = result.rootCauseAssessment.mostLikelyCause;
    const primaryService =
      context.hypotheses[0]?.relatedService ?? context.incidentSummaryContext.affectedServices[0] ?? "the affected service";

    const patternActions: RecommendedActions = { immediate: [], investigation: [], prevention: [] };

    for (const rule of PATTERN_RULES) {
      if (rule.matches(causeText, context)) {
        if (rule.immediate) patternActions.immediate.push(rule.immediate(primaryService));
        if (rule.investigation) patternActions.investigation.push(rule.investigation(primaryService));
        if (rule.prevention) patternActions.prevention.push(rule.prevention(primaryService));
      }
    }

    return {
      immediate: dedupe([...result.recommendedActions.immediate, ...patternActions.immediate]),
      investigation: dedupe([...result.recommendedActions.investigation, ...patternActions.investigation]),
      prevention: dedupe([...result.recommendedActions.prevention, ...patternActions.prevention]),
    };
  }
}

function dedupe(items: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of items) {
    const key = item.trim().toLowerCase();
    if (!seen.has(key) && key.length > 0) {
      seen.add(key);
      out.push(item.trim());
    }
  }
  return out;
}
