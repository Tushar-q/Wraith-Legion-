import { z } from "zod";

export const CausalChainStepSchema = z.object({
  step: z.number(),
  event: z.string(),
  service: z.string(),
  evidenceIds: z.array(z.string()).default([]),
});

export const KeyEvidenceItemSchema = z.object({
  evidenceId: z.string(),
  explanation: z.string(),
});

export const RecommendedActionsSchema = z.object({
  immediate: z.array(z.string()).default([]),
  investigation: z.array(z.string()).default([]),
  prevention: z.array(z.string()).default([]),
});

export const RootCauseAssessmentSchema = z.object({
  mostLikelyCause: z.string(),
  confidence: z.number().min(0).max(1),
  confidenceExplanation: z.string(),
});

export const IncidentSummaryBlockSchema = z.object({
  title: z.string(),
  severity: z.string(),
  impact: z.string(),
});

export const StructuredInvestigationResultSchema = z.object({
  incidentSummary: IncidentSummaryBlockSchema,
  rootCauseAssessment: RootCauseAssessmentSchema,
  whatHappened: z.string(),
  causalChain: z.array(CausalChainStepSchema).default([]),
  keyEvidence: z.array(KeyEvidenceItemSchema).default([]),
  uncertainty: z.array(z.string()).default([]),
  recommendedActions: RecommendedActionsSchema,
});

export type StructuredInvestigationResultParsed = z.infer<typeof StructuredInvestigationResultSchema>;

export const ChatResponseSchema = z.object({
  answer: z.string(),
  evidenceIds: z.array(z.string()).default([]),
  confidence: z.number().min(0).max(1),
  uncertainty: z.array(z.string()).default([]),
});

export type ChatResponseParsed = z.infer<typeof ChatResponseSchema>;
