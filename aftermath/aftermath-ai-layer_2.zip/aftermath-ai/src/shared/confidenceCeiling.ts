/**
 * How much cited evidence justifies how much confidence. Shared between
 * EvidenceValidator (validates LLM output) and HypothesisEngine (computes its
 * own confidence independently) so the two never disagree on what "enough
 * evidence" means.
 *
 * 0 evidence -> 0.4 ceiling, 1 -> 0.65, 2 -> 0.8, 3+ -> 0.97 (never a full 1.0 —
 * some residual uncertainty is always appropriate in an incident investigation).
 */
export function confidenceCeilingForEvidenceCount(evidenceCount: number): number {
  if (evidenceCount >= 3) return 0.97;
  const ceilings: Record<number, number> = { 0: 0.4, 1: 0.65, 2: 0.8 };
  return ceilings[evidenceCount] ?? 0.4;
}
