export type InvestigationStatusName = "queued" | "investigating" | "completed" | "failed";

export interface InvestigationLatestFinding {
  message: string;
}

export interface InvestigationStatus {
  incidentId: string;
  status: InvestigationStatusName;
  progress: number; // 0-100
  currentStage: string;
  completedStages: string[];
  latestFinding?: InvestigationLatestFinding;
  partialResult?: unknown;
  error?: string;
  updatedAt: string;
}

/**
 * Fixed 10-stage progression (matches the spec's stage list) with a progress
 * checkpoint assigned to each. Stage keys are what `currentStage` will contain.
 */
export const INVESTIGATION_STAGES = [
  { key: "collecting_evidence", label: "Collecting evidence", progress: 10 },
  { key: "timeline_analysis", label: "Building incident timeline", progress: 20 },
  { key: "health_analysis", label: "Analyzing service health", progress: 30 },
  { key: "trace_analysis", label: "Correlating distributed traces", progress: 40 },
  { key: "dependency_analysis", label: "Analyzing dependency propagation", progress: 50 },
  { key: "generating_hypotheses", label: "Generating hypotheses", progress: 60 },
  { key: "evaluating_hypotheses", label: "Evaluating hypotheses", progress: 75 },
  { key: "validating_evidence", label: "Validating evidence", progress: 85 },
  { key: "assessing_root_cause", label: "Assessing root cause", progress: 95 },
  { key: "generating_report", label: "Generating final report", progress: 100 },
] as const;

export type InvestigationStageKey = (typeof INVESTIGATION_STAGES)[number]["key"];

/**
 * In-memory only, per the explicit hackathon instruction against adding
 * Redis/external queues. A Map is sufficient for a single-process demo and
 * makes progress pollable by a concurrent request while the main
 * `POST /api/ai/investigate` call is still awaiting the LLM.
 */
export class InvestigationStatusStore {
  private statuses: Map<string, InvestigationStatus> = new Map();

  init(incidentId: string): InvestigationStatus {
    const status: InvestigationStatus = {
      incidentId,
      status: "queued",
      progress: 0,
      currentStage: "queued",
      completedStages: [],
      updatedAt: new Date().toISOString(),
    };
    this.statuses.set(incidentId, status);
    return status;
  }

  advance(incidentId: string, stageKey: InvestigationStageKey, findingMessage?: string, partialResult?: unknown): InvestigationStatus {
    const existing = this.statuses.get(incidentId) ?? this.init(incidentId);
    const stage = INVESTIGATION_STAGES.find((s) => s.key === stageKey);
    if (!stage) {
      throw new Error(`Unknown investigation stage "${stageKey}"`);
    }

    const completedStages = existing.currentStage !== "queued" && !existing.completedStages.includes(existing.currentStage)
      ? [...existing.completedStages, existing.currentStage]
      : existing.completedStages;

    const updated: InvestigationStatus = {
      ...existing,
      status: "investigating",
      progress: stage.progress,
      currentStage: stageKey,
      completedStages,
      latestFinding: findingMessage ? { message: findingMessage } : existing.latestFinding,
      partialResult: partialResult ?? existing.partialResult,
      updatedAt: new Date().toISOString(),
    };
    this.statuses.set(incidentId, updated);
    return updated;
  }

  complete(incidentId: string, result: unknown): InvestigationStatus {
    const existing = this.statuses.get(incidentId) ?? this.init(incidentId);
    const completedStages = existing.currentStage !== "queued" && !existing.completedStages.includes(existing.currentStage)
      ? [...existing.completedStages, existing.currentStage]
      : existing.completedStages;

    const updated: InvestigationStatus = {
      ...existing,
      status: "completed",
      progress: 100,
      currentStage: "generating_report",
      completedStages,
      partialResult: result,
      updatedAt: new Date().toISOString(),
    };
    this.statuses.set(incidentId, updated);
    return updated;
  }

  fail(incidentId: string, error: string): InvestigationStatus {
    const existing = this.statuses.get(incidentId) ?? this.init(incidentId);
    const updated: InvestigationStatus = {
      ...existing,
      status: "failed",
      error,
      updatedAt: new Date().toISOString(),
    };
    this.statuses.set(incidentId, updated);
    return updated;
  }

  get(incidentId: string): InvestigationStatus | undefined {
    return this.statuses.get(incidentId);
  }
}

// Shared singleton, same pattern as eventBus — fine for a single-process hackathon demo.
export const investigationStatusStore = new InvestigationStatusStore();
