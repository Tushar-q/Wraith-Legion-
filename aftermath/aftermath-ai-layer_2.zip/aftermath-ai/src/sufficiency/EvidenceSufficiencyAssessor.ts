import { RawInvestigationData } from "../types/incident";
import { EvidenceSufficiency, EvidenceSufficiencyLevel } from "../types/ai";

/**
 * EvidenceSufficiencyAssessor
 *
 * Answers "how much do we actually know here?" independently of any root
 * cause conclusion. Coverage checks five categories of investigation data;
 * the resulting score directly caps the final root-cause confidence in
 * InvestigationAgent, so a confident-sounding LLM narrative can never
 * override the reality that the underlying evidence was thin.
 */
export class EvidenceSufficiencyAssessor {
  assess(raw: RawInvestigationData): EvidenceSufficiency {
    const coverage = {
      timeline: raw.timeline.length > 0,
      metrics: raw.anomalies.length > 0,
      traces: raw.traces.failedTraceCount > 0 || (raw.traces.totalTraceCount ?? 0) > 0,
      dependencies: raw.dependencies.length > 0,
      configurationChanges:
        (raw.recentChanges?.length ?? 0) > 0 || raw.timeline.some((e) => /config|deploy/i.test(e.event)),
    };

    const coverageValues = Object.values(coverage);
    const coverageRatio = coverageValues.filter(Boolean).length / coverageValues.length;

    // Evidence record density: having a handful of actual evidence records matters
    // beyond just "categories present" — reward up to 5 records, cap contribution at 0.3.
    const evidenceDensity = Math.min(raw.evidence.length / 5, 1);

    const score = round2(coverageRatio * 0.7 + evidenceDensity * 0.3);

    let level: EvidenceSufficiencyLevel = "insufficient";
    if (score >= 0.75) level = "high";
    else if (score >= 0.5) level = "moderate";
    else if (score >= 0.25) level = "limited";

    const missingEvidence: string[] = [];
    if (!coverage.timeline) missingEvidence.push("No timeline events were recorded for this incident.");
    if (!coverage.metrics) missingEvidence.push("Insufficient metric/anomaly samples were provided.");
    if (!coverage.traces) missingEvidence.push("Distributed trace data is unavailable.");
    if (!coverage.dependencies) missingEvidence.push("Service dependency graph is unavailable.");
    if (!coverage.configurationChanges) missingEvidence.push("Configuration/deployment change history is missing.");
    if (raw.evidence.length < 3) missingEvidence.push("Evidence record count is low, limiting how well conclusions can be corroborated.");

    // Confidence ceiling scales with sufficiency: even a "high" sufficiency score
    // leaves room below 1.0, since some residual uncertainty is always appropriate.
    const confidenceCeiling = round2(0.4 + 0.57 * score);

    return { score, level, coverage, missingEvidence, confidenceCeiling };
  }
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
