import { AIContext } from "../types/ai";
import { EvidenceRecord, SystemChange } from "../types/incident";

export interface TimelineFilter {
  startTime?: string;
  endTime?: string;
  service?: string;
  significance?: "low" | "medium" | "high";
}

export interface ServiceHealth {
  service: string;
  currentLatency?: number;
  baselineLatency?: number;
  errorRate?: number;
  anomalies: AIContext["anomalyContext"];
}

export interface ServiceDependencies {
  service: string;
  upstream: string[]; // services this one depends on
  downstream: string[]; // services that depend on this one
}

export interface FailedTracesResult {
  failedTraceCount: number;
  totalTraceCount?: number;
  commonFailurePoint: string;
  affectedPercentage: number;
  significance: AIContext["traceContext"]["significance"];
}

/**
 * InvestigationTools
 *
 * A set of deterministic, pure functions the AI agent (and the LLM itself, via
 * tool-calling if wired up) uses to inspect an incident. These never call an
 * LLM — they operate directly on the AIContext built by AIContextBuilder, so
 * their output is always exact and reproducible. This is the "structured code
 * handles sorting/filtering/counting" half of the agent, as required by the
 * hackathon spec (Part 3 + "do NOT rely entirely on the LLM for calculations").
 */
export class InvestigationTools {
  constructor(private context: AIContext) {}

  getIncidentOverview() {
    const c = this.context.incidentSummaryContext;
    return {
      id: c.id,
      severity: c.severity,
      detectedAt: c.detectedAt,
      affectedServices: c.affectedServices,
    };
  }

  getTimeline(filter: TimelineFilter = {}) {
    let events = this.context.timelineContext;

    if (filter.startTime) {
      const start = new Date(filter.startTime).getTime();
      events = events.filter((e) => new Date(e.timestamp).getTime() >= start);
    }
    if (filter.endTime) {
      const end = new Date(filter.endTime).getTime();
      events = events.filter((e) => new Date(e.timestamp).getTime() <= end);
    }
    if (filter.service) {
      events = events.filter((e) => e.service === filter.service);
    }
    if (filter.significance) {
      events = events.filter((e) => e.significance === filter.significance);
    }
    return events;
  }

  getServiceHealth(serviceId: string): ServiceHealth {
    const anomalies = this.context.anomalyContext.filter((a) => a.service === serviceId);
    const latencyAnomaly = anomalies.find((a) => a.metric.toLowerCase().includes("latency"));
    const errorAnomaly = anomalies.find((a) => a.metric.toLowerCase().includes("error"));

    return {
      service: serviceId,
      currentLatency: latencyAnomaly?.current,
      baselineLatency: latencyAnomaly?.baseline,
      errorRate: errorAnomaly?.current,
      anomalies,
    };
  }

  getServiceDependencies(serviceId: string): ServiceDependencies {
    const upstream = this.context.dependencyContext
      .filter((d) => d.source === serviceId)
      .map((d) => d.target);
    const downstream = this.context.dependencyContext
      .filter((d) => d.target === serviceId)
      .map((d) => d.source);

    return { service: serviceId, upstream, downstream };
  }

  getFailedTraces(): FailedTracesResult {
    const t = this.context.traceContext;
    return {
      failedTraceCount: t.failedTraceCount,
      totalTraceCount: t.totalTraceCount,
      commonFailurePoint: t.commonFailurePoint,
      affectedPercentage: t.affectedPercentage,
      significance: t.significance,
    };
  }

  getEvidence(evidenceIds?: string[]): EvidenceRecord[] {
    const index = this.context.evidenceIndex;
    if (!evidenceIds || evidenceIds.length === 0) {
      return Object.values(index);
    }
    return evidenceIds.filter((id) => id in index).map((id) => index[id]);
  }

  getRootCauseCandidates() {
    return this.context.hypotheses;
  }

  getRecentChanges(recentChanges: SystemChange[] = []): SystemChange[] {
    // Recent changes come from raw data (Member 1/2 supply them); if absent we
    // fall back to reading configuration_change / deployment events out of the timeline.
    if (recentChanges.length > 0) {
      return [...recentChanges].sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    }
    return this.context.timelineContext
      .filter((e) => /config|deploy|scal/i.test(e.event))
      .map((e) => ({
        type: /config/i.test(e.event)
          ? ("configuration_change" as const)
          : /deploy/i.test(e.event)
          ? ("deployment" as const)
          : ("other" as const),
        service: e.service,
        timestamp: e.timestamp,
        description: e.event,
      }))
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  /** Which service degraded first, based on chronological timeline + anomaly correlation. */
  getEarliestAbnormalEvent() {
    return this.context.timelineContext.find((e) => e.isEarliestAbnormalEvent) ?? this.context.timelineContext[0];
  }
}
