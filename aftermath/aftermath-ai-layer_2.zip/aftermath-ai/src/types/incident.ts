/**
 * Types for the RAW structured investigation data that Member 1 (telemetry/detection)
 * and Member 2 (investigation engine) hand off to this subsystem.
 *
 * This subsystem NEVER re-derives anomalies, root causes, or traces itself — it consumes
 * what those modules produce and reasons over it.
 */

export type Severity = "low" | "medium" | "high" | "critical";
export type Significance = "low" | "medium" | "high";

export interface IncidentMeta {
  id: string;
  severity: Severity;
  detectedAt: string; // ISO timestamp
  affectedServices: string[];
  title?: string;
}

export interface TimelineEvent {
  timestamp: string; // ISO timestamp
  event: string;
  service: string;
  significance: Significance;
  details?: Record<string, unknown>;
}

export interface AnomalyRecord {
  service: string;
  metric: string;
  baseline: number;
  current: number;
  anomalyScore: number; // 0..1
  timestamp?: string;
}

export interface DependencyEdge {
  source: string; // depends on target
  target: string;
}

export interface TraceSummary {
  failedTraceCount: number;
  commonFailurePoint: string;
  affectedPercentage: number; // 0..100
  totalTraceCount?: number;
}

export interface RootCauseCandidate {
  cause: string;
  confidence: number; // 0..1
  relatedService?: string;
  supportingEvidenceIds?: string[];
}

export type EvidenceType = "event" | "metric" | "trace" | "log" | "config_change" | "deployment";

export interface EvidenceRecord {
  id: string;
  type: EvidenceType;
  timestamp: string;
  description: string;
  service?: string;
  source?: string;
  relatedTo?: string[]; // ids of related evidence
}

export interface SystemChange {
  type: "configuration_change" | "deployment" | "scaling_event" | "other";
  service: string;
  timestamp: string;
  description: string;
}

/**
 * The complete raw payload as described in the hackathon spec. This is what
 * Members 1 and 2 are expected to hand off per incident.
 */
export interface RawInvestigationData {
  incident: IncidentMeta;
  timeline: TimelineEvent[];
  anomalies: AnomalyRecord[];
  dependencies: DependencyEdge[];
  traces: TraceSummary;
  rootCauseCandidates: RootCauseCandidate[];
  evidence: EvidenceRecord[];
  recentChanges?: SystemChange[];
}
