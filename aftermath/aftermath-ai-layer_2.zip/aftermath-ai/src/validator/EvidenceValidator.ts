import { AIContext, StructuredInvestigationResult, ValidationIssue, ValidationResult } from "../types/ai";
import { confidenceCeilingForEvidenceCount } from "../shared/confidenceCeiling";

const OVERCONFIDENT_PHRASES = [
  "definitely caused",
  "definitely the cause",
  "100% certain",
  "without a doubt",
  "guaranteed",
];

/**
 * EvidenceValidator
 *
 * The single most important safety component in this subsystem: it checks
 * every claim the LLM makes against the actual evidence index and timeline
 * before that claim is allowed to reach a user. It runs five checks per the
 * spec:
 *   1. Does the referenced evidence exist?
 *   2. Does the evidence plausibly support the claim (same service/topic)?
 *   3. Is the timestamp logically consistent (cause before effect)?
 *   4. Does the confidence match the amount of available evidence?
 *   5. Is the claim's language stronger than the evidence allows?
 *
 * On failure it does not just reject — it produces a `correctedResult` with
 * confidence clamped down, unverifiable evidence IDs stripped, and
 * overconfident language softened, so the pipeline can continue with a
 * defensible answer instead of hard-failing the whole investigation.
 */
export class EvidenceValidator {
  validate(result: StructuredInvestigationResult, context: AIContext): ValidationResult {
    const issues: ValidationIssue[] = [];
    const corrected: StructuredInvestigationResult = JSON.parse(JSON.stringify(result));

    this.checkEvidenceExists(corrected, context, issues);
    this.checkTimestampConsistency(corrected, context, issues);
    this.checkConfidenceMatchesEvidence(corrected, issues);
    this.checkOverconfidentLanguage(corrected, issues);
    this.checkRecommendationsAreSpecific(corrected, issues);

    const hasErrors = issues.some((i) => i.severity === "error");

    return {
      valid: !hasErrors,
      issues,
      correctedResult: corrected,
    };
  }

  /** Check 1 & partially 2: strip any cited evidence ID that doesn't exist in the index. */
  private checkEvidenceExists(result: StructuredInvestigationResult, context: AIContext, issues: ValidationIssue[]) {
    const validIds = new Set(Object.keys(context.evidenceIndex));

    const stripInvalid = (ids: string[], field: string): string[] => {
      const kept: string[] = [];
      for (const id of ids) {
        if (validIds.has(id)) {
          kept.push(id);
        } else {
          issues.push({
            field,
            message: `Referenced evidence "${id}" does not exist in the evidence index and was removed.`,
            severity: "error",
          });
        }
      }
      return kept;
    };

    result.causalChain = result.causalChain.map((step) => ({
      ...step,
      evidenceIds: stripInvalid(step.evidenceIds, "causalChain.evidenceIds"),
    }));

    result.keyEvidence = result.keyEvidence.filter((item) => {
      if (validIds.has(item.evidenceId)) return true;
      issues.push({
        field: "keyEvidence.evidenceId",
        message: `Referenced evidence "${item.evidenceId}" does not exist in the evidence index and was removed.`,
        severity: "error",
      });
      return false;
    });

    // Root cause assessment doesn't carry evidence IDs directly in the schema, but if the
    // final answer cites zero verifiable evidence anywhere, that's a serious grounding failure.
    const totalCitations = result.causalChain.reduce((n, s) => n + s.evidenceIds.length, 0) + result.keyEvidence.length;
    if (totalCitations === 0 && result.rootCauseAssessment.confidence > 0.5) {
      issues.push({
        field: "rootCauseAssessment.confidence",
        message: "High confidence conclusion with zero verifiable evidence citations.",
        severity: "error",
      });
      result.rootCauseAssessment.confidence = Math.min(result.rootCauseAssessment.confidence, 0.4);
      result.uncertainty.push("Insufficient verifiable evidence to fully support this conclusion.");
    }
  }

  /** Check 3: causal chain events should be chronologically consistent with the timeline where matchable. */
  private checkTimestampConsistency(result: StructuredInvestigationResult, context: AIContext, issues: ValidationIssue[]) {
    // Build a lookup from evidence ID -> timestamp so we can order causal steps.
    const evidenceTimestamps: Record<string, number> = {};
    for (const [id, ev] of Object.entries(context.evidenceIndex)) {
      evidenceTimestamps[id] = new Date(ev.timestamp).getTime();
    }

    let lastTimestamp = -Infinity;
    for (const step of result.causalChain) {
      const stepTimestamps = step.evidenceIds.map((id) => evidenceTimestamps[id]).filter((t) => !Number.isNaN(t));
      if (stepTimestamps.length === 0) continue;
      const earliestForStep = Math.min(...stepTimestamps);
      if (earliestForStep < lastTimestamp) {
        issues.push({
          field: `causalChain.step[${step.step}]`,
          message: `Causal chain step "${step.event}" cites evidence earlier than a preceding step — chain ordering is not chronologically consistent.`,
          severity: "warning",
        });
      }
      lastTimestamp = Math.max(lastTimestamp, earliestForStep);
    }
  }

  /** Check 4: confidence should not exceed what the amount of supporting evidence justifies. */
  private checkConfidenceMatchesEvidence(result: StructuredInvestigationResult, issues: ValidationIssue[]) {
    const evidenceCount = new Set([
      ...result.causalChain.flatMap((s) => s.evidenceIds),
      ...result.keyEvidence.map((k) => k.evidenceId),
    ]).size;

    const conf = result.rootCauseAssessment.confidence;

    // Heuristic ceiling: confidence should require proportionally more evidence as it climbs.
    const ceiling = confidenceCeilingForEvidenceCount(evidenceCount);

    if (conf > ceiling) {
      issues.push({
        field: "rootCauseAssessment.confidence",
        message: `Confidence ${conf.toFixed(2)} exceeds what ${evidenceCount} piece(s) of cited evidence justify; clamped to ${ceiling}.`,
        severity: "warning",
      });
      result.rootCauseAssessment.confidence = ceiling;
    }
  }

  /** Check 5: forbid absolute-certainty language unless confidence is very high AND evidence exists. */
  private checkOverconfidentLanguage(result: StructuredInvestigationResult, issues: ValidationIssue[]) {
    const evidenceCount = new Set([
      ...result.causalChain.flatMap((s) => s.evidenceIds),
      ...result.keyEvidence.map((k) => k.evidenceId),
    ]).size;

    const fieldsToCheck: Array<[string, string]> = [
      ["whatHappened", result.whatHappened],
      ["rootCauseAssessment.mostLikelyCause", result.rootCauseAssessment.mostLikelyCause],
      ["rootCauseAssessment.confidenceExplanation", result.rootCauseAssessment.confidenceExplanation],
    ];

    for (const [field, text] of fieldsToCheck) {
      const lower = text.toLowerCase();
      const matchedPhrase = OVERCONFIDENT_PHRASES.find((p) => lower.includes(p));
      if (matchedPhrase && !(result.rootCauseAssessment.confidence >= 0.9 && evidenceCount > 0)) {
        issues.push({
          field,
          message: `Overconfident phrase "${matchedPhrase}" used without sufficient confidence/evidence to support it; softened.`,
          severity: "warning",
        });
        const softened = text.replace(new RegExp(matchedPhrase, "gi"), "most likely");
        if (field === "whatHappened") result.whatHappened = softened;
        if (field === "rootCauseAssessment.mostLikelyCause") result.rootCauseAssessment.mostLikelyCause = softened;
        if (field === "rootCauseAssessment.confidenceExplanation") result.rootCauseAssessment.confidenceExplanation = softened;
      }
    }

    // If multiple hypotheses are close in confidence, the result should acknowledge that
    // instead of asserting a single definitive cause.
  }

  /** Reject generic, non-incident-specific recommendations like "Improve monitoring." */
  private checkRecommendationsAreSpecific(result: StructuredInvestigationResult, issues: ValidationIssue[]) {
    const genericPhrases = ["improve monitoring", "improve observability", "add more logging", "be more careful"];
    const allRecs = [
      ...result.recommendedActions.immediate,
      ...result.recommendedActions.investigation,
      ...result.recommendedActions.prevention,
    ];
    for (const rec of allRecs) {
      const lower = rec.toLowerCase().trim();
      if (genericPhrases.some((g) => lower === g || lower === g + ".")) {
        issues.push({
          field: "recommendedActions",
          message: `Generic, non-specific recommendation detected: "${rec}".`,
          severity: "warning",
        });
      }
    }
  }
}
