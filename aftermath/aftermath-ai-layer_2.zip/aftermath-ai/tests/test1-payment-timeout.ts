import "dotenv/config";
import { AftermathService } from "../src/api/aftermathService";
import { RawInvestigationData } from "../src/types/incident";
import paymentIncident from "../mock-data/payment-timeout-incident.json";
import { assert, section } from "./testUtils";

async function main() {
  section("TEST 1: Payment timeout incident -> payment-related root cause with evidence");

  const service = new AftermathService();
  const { result, validationIssues } = await service.investigate(paymentIncident as RawInvestigationData);

  assert(/payment/i.test(result.rootCauseAssessment.mostLikelyCause), "root cause mentions payment-service");
  assert(result.rootCauseAssessment.confidence > 0.5, `confidence is meaningfully high (got ${result.rootCauseAssessment.confidence})`);
  assert(
    result.keyEvidence.length > 0 || result.causalChain.some((c) => c.evidenceIds.length > 0),
    "conclusion cites at least one piece of evidence"
  );
  assert(validationIssues === 0 || validationIssues >= 0, "evidence validator ran without throwing");

  const report = service.getReport("INC-001");
  assert(report.markdown.includes("Most Likely Root Cause"), "report contains root cause section");

  const recs = service.getRecommendations("INC-001");
  assert(recs.immediate.length > 0, "at least one immediate recommendation was produced");
  assert(
    !recs.immediate.some((r) => r.toLowerCase().trim() === "improve monitoring."),
    "recommendations are not the banned generic 'improve monitoring'"
  );

  console.log("\nRoot cause:", result.rootCauseAssessment.mostLikelyCause);
  console.log("Confidence:", result.rootCauseAssessment.confidence);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
