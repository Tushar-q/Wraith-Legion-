import "dotenv/config";
import { AftermathService } from "../src/api/aftermathService";
import { RawInvestigationData } from "../src/types/incident";
import dbIncident from "../mock-data/database-slowdown-incident.json";
import { assert, section } from "./testUtils";

async function main() {
  section("TEST 2: Database slowdown -> database degradation identified");

  const service = new AftermathService();
  const { result } = await service.investigate(dbIncident as RawInvestigationData);

  assert(
    /database|db|query|connection pool/i.test(result.rootCauseAssessment.mostLikelyCause),
    "root cause mentions database/query/connection pool"
  );
  assert(result.rootCauseAssessment.confidence > 0.4, `confidence is reasonable (got ${result.rootCauseAssessment.confidence})`);

  const recs = service.getRecommendations("INC-002");
  const allRecs = [...recs.immediate, ...recs.investigation, ...recs.prevention].join(" ").toLowerCase();
  assert(/query|connection|pool|database|index/i.test(allRecs), "recommendations reference the database issue specifically");

  console.log("\nRoot cause:", result.rootCauseAssessment.mostLikelyCause);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
