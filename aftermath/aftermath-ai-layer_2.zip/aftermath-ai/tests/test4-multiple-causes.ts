import "dotenv/config";
import { AIContextBuilder } from "../src/context/AIContextBuilder";
import { RawInvestigationData } from "../src/types/incident";
import { assert, section } from "./testUtils";

// Two root cause candidates with very close confidence and each has supporting
// evidence — the context builder should flag this as an uncertainty, and any
// downstream reasoning should present both rather than asserting a single cause.
const ambiguousIncident: RawInvestigationData = {
  incident: {
    id: "INC-777",
    title: "Ambiguous multi-service degradation",
    severity: "high",
    detectedAt: "2026-08-29T05:00:00Z",
    affectedServices: ["search-service", "recommendation-service"],
  },
  timeline: [
    { timestamp: "2026-08-29T04:58:00Z", event: "cache_eviction_spike", service: "search-service", significance: "high" },
    { timestamp: "2026-08-29T04:58:30Z", event: "cpu_throttling", service: "recommendation-service", significance: "high" },
  ],
  anomalies: [
    { service: "search-service", metric: "cache_hit_rate", baseline: 92, current: 40, anomalyScore: 0.8 },
    { service: "recommendation-service", metric: "cpu_usage", baseline: 55, current: 97, anomalyScore: 0.82 },
  ],
  dependencies: [{ source: "recommendation-service", target: "search-service" }],
  traces: {
    failedTraceCount: 210,
    totalTraceCount: 900,
    commonFailurePoint: "search-service",
    affectedPercentage: 23,
  },
  rootCauseCandidates: [
    {
      cause: "search-service cache eviction storm",
      confidence: 0.62,
      relatedService: "search-service",
      supportingEvidenceIds: ["EV-301"],
    },
    {
      cause: "recommendation-service CPU throttling under load",
      confidence: 0.58,
      relatedService: "recommendation-service",
      supportingEvidenceIds: ["EV-302"],
    },
  ],
  evidence: [
    {
      id: "EV-301",
      type: "metric",
      timestamp: "2026-08-29T04:58:00Z",
      description: "search-service cache hit rate dropped from 92% to 40%",
      service: "search-service",
    },
    {
      id: "EV-302",
      type: "metric",
      timestamp: "2026-08-29T04:58:30Z",
      description: "recommendation-service CPU usage reached 97%",
      service: "recommendation-service",
    },
  ],
  recentChanges: [],
};

async function main() {
  section("TEST 4: Multiple close-confidence causes -> AI presents uncertainty");

  const builder = new AIContextBuilder();
  const context = builder.build(ambiguousIncident);

  assert(context.hypotheses.length === 2, "both root cause candidates are present as hypotheses");
  assert(
    context.uncertainties.some((u) => /close in confidence/i.test(u)),
    "context builder flags the close-confidence ambiguity as an uncertainty"
  );
  assert(
    context.hypotheses.every((h) => h.category === "hypothesis"),
    "neither candidate is auto-classified as a settled fact (both below 0.9 confidence)"
  );

  console.log("\nHypotheses:", context.hypotheses.map((h) => `${h.cause} (${h.confidence})`));
  console.log("Uncertainties:", context.uncertainties);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
