import "dotenv/config";
import { AftermathService } from "../src/api/aftermathService";
import { RawInvestigationData } from "../src/types/incident";
import paymentIncident from "../mock-data/payment-timeout-incident.json";
import { assert, section } from "./testUtils";

async function main() {
  section("TEST 5: Chat question -> answer references evidence IDs");

  const service = new AftermathService();
  await service.investigate(paymentIncident as RawInvestigationData);

  const response = await service.askChat("INC-001", "Why do you believe payment-service caused the incident?");

  assert(response.answer.length > 0, "chat produced a non-empty answer");
  assert(response.evidenceIds.length > 0, `answer cites at least one evidence ID (got ${response.evidenceIds.length})`);
  assert(
    response.evidenceIds.every((id) => /^EV-\d+$/.test(id)),
    "all cited evidence IDs are well-formed and (per InvestigationChat) verified to exist"
  );
  assert(typeof response.confidence === "number" && response.confidence >= 0 && response.confidence <= 1, "confidence is in [0,1]");

  console.log("\nAnswer:", response.answer);
  console.log("Evidence IDs:", response.evidenceIds);

  // Follow-up question should retain conversation context (no crash, still grounded).
  const followUp = await service.askChat("INC-001", "What should the engineer investigate next?");
  assert(followUp.answer.length > 0, "follow-up question answered using retained conversation context");
  console.log("\nFollow-up answer:", followUp.answer);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
