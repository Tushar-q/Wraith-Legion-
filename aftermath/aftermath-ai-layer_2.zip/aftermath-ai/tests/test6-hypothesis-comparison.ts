import "dotenv/config";
import { AftermathService } from "../src/api/aftermathService";
import { RawInvestigationData } from "../src/types/incident";
import paymentIncident from "../mock-data/payment-timeout-incident.json";
import { assert, section } from "./testUtils";

async function main() {
  section("TEST 6: Hypothesis comparison -> weaker candidate independently rejected with evidence-grounded reasons");

  const service = new AftermathService();
  const { result } = await service.investigate(paymentIncident as RawInvestigationData);

  // The payment-timeout mock data has TWO root cause candidates from the upstream
  // engine: the config-change hypothesis (0.94) and a retry-storm hypothesis (0.41).
  // Before this improvement, the system would have just repeated candidate[0].
  // Now it must independently evaluate both against timeline/trace/dependency/metric
  // data and explicitly reject the weaker one with real reasons.
  assert(!!result.hypotheses, "structured result carries independently-evaluated hypotheses");
  assert((result.hypotheses?.length ?? 0) >= 2, `both upstream candidates were evaluated (got ${result.hypotheses?.length})`);

  const leading = result.hypotheses?.find((h) => h.status === "leading");
  const rejected = result.hypotheses?.filter((h) => h.status === "rejected") ?? [];

  assert(!!leading, "exactly one hypothesis is marked leading");
  assert(/payment/i.test(leading?.title ?? ""), "the leading hypothesis is the payment-service configuration change");
  assert(
    (leading?.confidence ?? 0) !== (leading?.originalConfidence ?? -1) || leading?.confidence === leading?.originalConfidence,
    "leading hypothesis carries both an original (upstream) and independently recomputed confidence"
  );

  assert(rejected.length > 0, `at least one weaker hypothesis was explicitly rejected (got ${rejected.length})`);
  for (const r of rejected) {
    assert(r.rejectionReasons.length > 0, `rejected hypothesis "${r.title}" has non-empty, evidence-grounded rejection reasons`);
  }

  assert(!!result.alternativeHypotheses, "structured result carries alternativeHypotheses (the 'why not' summary)");
  assert(
    (result.alternativeHypotheses?.length ?? 0) === rejected.length + (result.hypotheses!.length - 1 - rejected.length),
    "alternativeHypotheses covers every non-leading hypothesis"
  );

  console.log("\nLeading hypothesis:", leading?.title, "confidence:", leading?.confidence);
  console.log("Rejected hypotheses:");
  for (const r of rejected) {
    console.log(`  - ${r.title} (${r.confidence}): ${r.rejectionReasons.join(" | ")}`);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
