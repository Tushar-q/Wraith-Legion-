import "dotenv/config";
import { AftermathService } from "../src/api/aftermathService";
import { RawInvestigationData } from "../src/types/incident";
import paymentIncident from "../mock-data/payment-timeout-incident.json";
import { assert, section } from "./testUtils";

async function main() {
  section("TEST 7: Investigation status/recovery endpoint");

  const service = new AftermathService();

  // Before investigate() runs, there should be no status yet.
  let threw = false;
  try {
    service.getInvestigationStatus("INC-001");
  } catch {
    threw = true;
  }
  assert(threw, "querying status before investigation starts fails clearly rather than returning fake data");

  await service.investigate(paymentIncident as RawInvestigationData);

  const status = service.getInvestigationStatus("INC-001");
  assert(status.status === "completed", `status is "completed" after investigate() resolves (got "${status.status}")`);
  assert(status.progress === 100, `progress is 100 (got ${status.progress})`);
  assert(status.completedStages.length > 0, "completedStages is populated, showing progressive stages");
  assert(
    status.completedStages.includes("collecting_evidence") && status.completedStages.includes("trace_analysis"),
    "specific expected stages (collecting_evidence, trace_analysis) were recorded"
  );
  assert(!!status.partialResult, "final status carries the completed result for page-refresh recovery");

  console.log("\nFinal status:", status.status, "progress:", status.progress);
  console.log("Completed stages:", status.completedStages);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
