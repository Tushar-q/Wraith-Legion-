/* eslint-disable no-console */
export function assert(condition: boolean, message: string): void {
  if (!condition) {
    console.error(`  ✗ FAIL: ${message}`);
    process.exitCode = 1;
  } else {
    console.log(`  ✓ ${message}`);
  }
}

export function section(title: string): void {
  console.log(`\n=== ${title} ===`);
}
