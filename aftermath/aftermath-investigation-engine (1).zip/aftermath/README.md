# AFTERMATH — Incident Investigation Engine (Member 2)

An AI-powered-feeling, but fully deterministic, incident investigation engine. Given a detected
incident, it reconstructs **what happened, when it started, how it spread, and the most likely
root cause candidates** — with every conclusion traceable back to specific evidence.

This is the standalone Member 2 module for the AFTERMATH hackathon project. It does **not**
detect incidents, generate telemetry, run any ML/LLM, build a chatbot, or build a frontend —
it takes structured incident data (real or seeded) and performs deterministic, explainable
investigation.

---

## 1. Architecture

```
src/
  types/
    telemetry.ts        Data contracts Member 1 is expected to eventually satisfy
    investigation.ts     Investigation-domain types (timeline, causal graph, root cause, evidence...)

  providers/
    interfaces.ts         IncidentDataProvider / TelemetryProvider / DependencyProvider
    mock/
      mockData.ts          Deterministic seeded INC-042 scenario data
      MockProviders.ts      Reference implementations of the 3 provider interfaces

  config/
    investigationConfig.ts  Evidence window, temporal-correlation, propagation window settings
    scoringWeights.ts        ALL scoring weights (propagation confidence, root-cause scoring)

  investigation/           <-- the engine itself, one class per responsibility
    IncidentContextCollector.ts   Gathers everything relevant to one incident
    TimelineBuilder.ts            Scattered evidence -> one sorted timeline
    FirstFailureAnalyzer.ts       Which service broke first, and why
    ChangeCorrelationAnalyzer.ts  Suspicious changes shortly before the first failure
    DependencyAnalyzer.ts         Service dependency graph traversal
    FailurePropagationAnalyzer.ts Does failure spread through the dependency graph over time?
    PropagationScorer.ts          Explainable 0-100 confidence for a propagation edge
    EvidenceCollector.ts          Normalizes all telemetry into EvidenceItem[] with relevance scores
    EvidenceClusterer.ts          Groups related evidence into EvidenceCluster[]
    CauseSymptomClassifier.ts     Deterministically labels events: cause / intermediate / symptom / impact
    RootCauseCandidateGenerator.ts Proposes MULTIPLE plausible root cause hypotheses
    RootCauseScorer.ts            Scores each hypothesis on 7 explainable weighted factors
    CausalGraphBuilder.ts         Frontend-friendly graph of nodes + evidence-backed edges
    InvestigationEngine.ts        Orchestrates the full pipeline end-to-end

  services/
    InvestigationService.ts  In-memory store + lookups the REST API needs

  api/
    server.ts               Express app wiring (the ONE place providers get injected)
    routes/investigations.ts REST endpoints

  scripts/
    runDemo.ts               CLI script: runs INC-042 and prints a full readable report

  index.ts                   Entrypoint — wires MOCK providers in and starts the HTTP server

tests/                       Vitest test suite (17 tests across 6 files)
```

### Design principle: the engine never touches raw data sources directly

Every investigation module works **only** off an `InvestigationContext` object, built once by
`IncidentContextCollector` from three provider interfaces:

```ts
IncidentDataProvider   // incidents + affected services
TelemetryProvider      // anomalies, logs, metrics, events, traces, health history
DependencyProvider     // the static service dependency graph
```

Today these are implemented by `providers/mock/*`, seeded with the deterministic **INC-042**
scenario. See [§6 Integrating Member 1](#6-integrating-member-1s-real-telemetry-system) for how
to swap in the real thing.

### Dependency-edge direction convention (read this once)

A `ServiceDependency` edge `{ serviceId: "order-service", dependsOnServiceId: "payment-service" }`
means **"order-service calls payment-service"**. Consequently:

- `payment-service` is **upstream** of `order-service` (closer to the root cause).
- `order-service` is **downstream** of `payment-service` (affected when payment-service fails).
- Failure **propagates** from a service to its **downstream** (its callers) — the *opposite*
  direction of the `dependsOn` arrow.
- `DependencyAnalyzer.findPath(source, target)` walks the downstream direction, because that's
  the direction a real failure travels.

This is documented once in `types/telemetry.ts` and `DependencyAnalyzer.ts`, and used
consistently everywhere.

### No ML, nothing hidden

Every score in this engine comes from a small number of **explainable, weighted factors**
defined centrally in `config/scoringWeights.ts` — temporal proximity, service/dependency
correlation, trace correlation, evidence diversity, etc. Nothing is hardcoded per-incident;
the INC-042 outcome falls out of the seeded evidence, not a special case in the code.

---

## 2. Install

Requires Node.js 18+.

```bash
cd aftermath
npm install
```

## 3. Run

**Start the API server** (uses the seeded mock providers):

```bash
npm run build && npm start     # compiled
# or, for development:
npm run dev                    # ts-node, no build step
```

Server listens on `http://localhost:4000` (override with `PORT=xxxx`).

**Run the INC-042 demo scenario from the command line** (no server needed) — prints a full
human-readable investigation report (timeline, first failure, propagation, root causes, causal
graph, evidence clusters):

```bash
npm run demo
```

**Run the test suite:**

```bash
npm test          # vitest run — 17 tests across timeline / first-failure / propagation /
                   # root-cause / causal-graph / full end-to-end
npm run typecheck # tsc --noEmit
```

## 4. Trigger the INC-042 investigation via the API

```bash
curl -X POST http://localhost:4000/api/investigations/INC-042/run
```

This returns a complete `InvestigationResult` (see shape below). The response includes an
`investigationId` you use for all the other endpoints.

---

## 5. API Endpoints

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/investigations/:incidentId/run` | Runs a full investigation for an incident. Body may include `{ lookbackSeconds, lookforwardSeconds }` to override the evidence window. Returns `InvestigationResult`. |
| `GET`  | `/api/investigations` | Lists all investigations run so far (most recent first). |
| `GET`  | `/api/investigations/:investigationId` | Returns the complete `InvestigationResult`. |
| `GET`  | `/api/investigations/:investigationId/timeline` | Returns just `TimelineEvent[]`, already sorted. |
| `GET`  | `/api/investigations/:investigationId/causal-graph` | Returns `{ nodes, edges }`, ready to hand to a graph library. |
| `GET`  | `/api/investigations/:investigationId/root-causes` | Returns `{ primaryHypothesis, candidates }`, already ranked. |
| `GET`  | `/api/investigations/:investigationId/evidence` | Returns `EvidenceItem[]`. Supports `?serviceId=&sourceType=&minRelevance=` filters. |
| `GET`  | `/api/investigations/:investigationId/ai-context` | Returns Member 3's clean `AIInvestigationContext` (see §7). |
| `GET`  | `/api/incidents/:incidentId/investigation` | Returns the latest `InvestigationResult` for an incident. |
| `GET`  | `/health` | Basic liveness check. |

All responses are JSON. 404 is returned for unknown investigation/incident IDs.

---

## 6. Integrating Member 1's real telemetry system

The **only** integration point is `src/api/server.ts::createServer(...)`, which takes the three
provider instances as parameters, and `src/index.ts`, which is the only file that currently
constructs the mock ones:

```ts
// src/index.ts — replace these three lines:
const incidentProvider = new MockIncidentDataProvider();
const telemetryProvider = new MockTelemetryProvider();
const dependencyProvider = new MockDependencyProvider();

// ...with real implementations of the same interfaces:
const incidentProvider = new RealIncidentDataProvider(/* Member 1's client/db */);
const telemetryProvider = new RealTelemetryProvider(/* ... */);
const dependencyProvider = new RealDependencyProvider(/* ... */);
```

Implement `IncidentDataProvider`, `TelemetryProvider`, and `DependencyProvider`
(`src/providers/interfaces.ts`) against Member 1's real data source. If Member 1's data shapes
differ from `src/types/telemetry.ts`, translate inside the new provider implementation — **no
code in `src/investigation/*` needs to change.** That's the whole point of the seam.

---

## 7. Data contract for Member 3 (AI reasoning layer)

`GET /api/investigations/:investigationId/ai-context` returns:

```ts
interface AIInvestigationContext {
  incident: Incident;
  summary: InvestigationSummary;
  primaryHypothesis: RootCauseCandidate | null;
  alternativeHypotheses: RootCauseCandidate[];
  timeline: TimelineEvent[];
  causalChain: CausalGraph;
  evidence: EvidenceItem[];
  confidenceAnalysis: { confidence: number; confidenceLevel: string; reasons: string[] } | null;
}
```

Member 3 should not need to reconstruct any relationships — everything is already resolved,
ranked, and evidence-linked.

---

## 8. Example investigation output (INC-042)

Running `npm run demo` (or `POST /api/investigations/INC-042/run`) against the seeded scenario
produces, among other things:

**Timeline** (excerpt, fully chronological):
```
09:00:05  payment-service: Configuration changed — timeout 5000ms -> 500ms
09:00:10  payment-service: Anomaly: latency spike — 120ms -> 1500ms
09:00:15  payment-service: Anomaly: timeout spike — timeout rate 62%
09:00:20  order-service:   Anomaly: error rate spike — retry rate spiked
09:00:25  order-service:   Anomaly: health degradation — 98 -> 41
09:00:30  api-gateway:     Anomaly: error rate spike — 5xx rate 48%
09:00:35  api-gateway:     User impact detected
```

**First failure:** `payment-service` @ `09:00:10` (confidence 100%)

**Suspicious change:** configuration change on `payment-service`, 5s before first failure,
suspicion score 100/100.

**Propagation:**
```
payment-service -> order-service   confidence=94%  Δt=10s
order-service   -> api-gateway     confidence=94%  Δt=10s
Propagation path: payment-service -> order-service -> api-gateway
```

**Root cause candidates (ranked):**
```
95%  [very_high]  payment-service configuration change   (configuration_change)
88%  [high]       payment-service service failure        (service_failure)
38%  [low]        Unknown external factor                (unknown)
```

**Primary hypothesis:** *Payment Service timeout configuration change* — **95% confidence**
(`very_high`), phrased probabilistically per the project's requirement to never claim certainty.

Confidence is **derived**, not hardcoded — it comes from `RootCauseScorer` combining temporal
proximity (occurred 5s before first failure), service correlation (same service), first-failure
correlation, propagation consistency (the resulting chain matches the dependency graph),
evidence support (config event + latency + timeout + health + log + trace evidence all
corroborate it), severity correlation, and an "explanatory depth" bonus for identifying a
concrete causal mechanism rather than just restating the failure.

**Causal graph:** 22 nodes, 22 evidence-backed edges, connecting the configuration change through
latency → timeouts → retries → degradation → gateway errors → user impact.

---

## 9. Verified

- ✅ `npm run typecheck` — no TypeScript errors
- ✅ `npm test` — 17/17 tests pass (timeline ordering, first-failure detection, suspicious-change
  correlation, propagation direction + confidence, invalid-propagation rejection, root-cause
  ranking + contradiction penalty, causal-graph integrity, full INC-042 end-to-end)
- ✅ `npm run demo` — full INC-042 scenario runs and produces the expected investigation narrative
- ✅ API server smoke-tested live: `/health`, `run`, `GET investigation`, `timeline`,
  `causal-graph`, `root-causes`, `evidence` (with filters), `incidents/:id/investigation`,
  `list`, and 404 handling all verified via curl against a running server.
