import { Router, Request, Response } from "express";
import { InvestigationService } from "../../services/InvestigationService";

/**
 * PART 19 — REST API surface for the investigation engine. Adaptable to
 * whatever HTTP framework the real repository uses; this is a standalone
 * Express router since no existing backend was available to integrate
 * with.
 */
export function createInvestigationsRouter(service: InvestigationService): Router {
  const router = Router();

  // POST /api/investigations/:incidentId/run
  router.post("/investigations/:incidentId/run", async (req: Request, res: Response) => {
    try {
      const { incidentId } = req.params;
      const lookbackSeconds = req.body?.lookbackSeconds;
      const lookforwardSeconds = req.body?.lookforwardSeconds;
      const result = await service.runInvestigation(incidentId, { lookbackSeconds, lookforwardSeconds });
      if (result.status === "failed") {
        return res.status(422).json(result);
      }
      return res.status(201).json(result);
    } catch (err) {
      return res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
    }
  });

  // GET /api/investigations
  router.get("/investigations", (_req: Request, res: Response) => {
    return res.json(service.listInvestigations());
  });

  // GET /api/investigations/:investigationId
  router.get("/investigations/:investigationId", (req: Request, res: Response) => {
    const result = service.getInvestigation(req.params.investigationId);
    if (!result) return res.status(404).json({ error: "Investigation not found" });
    return res.json(result);
  });

  // GET /api/investigations/:investigationId/timeline
  router.get("/investigations/:investigationId/timeline", (req: Request, res: Response) => {
    const result = service.getInvestigation(req.params.investigationId);
    if (!result) return res.status(404).json({ error: "Investigation not found" });
    return res.json(result.timeline);
  });

  // GET /api/investigations/:investigationId/causal-graph
  router.get("/investigations/:investigationId/causal-graph", (req: Request, res: Response) => {
    const result = service.getInvestigation(req.params.investigationId);
    if (!result) return res.status(404).json({ error: "Investigation not found" });
    return res.json(result.causalGraph);
  });

  // GET /api/investigations/:investigationId/root-causes
  router.get("/investigations/:investigationId/root-causes", (req: Request, res: Response) => {
    const result = service.getInvestigation(req.params.investigationId);
    if (!result) return res.status(404).json({ error: "Investigation not found" });
    return res.json({
      primaryHypothesis: result.primaryHypothesis,
      candidates: result.rootCauseCandidates,
    });
  });

  // GET /api/investigations/:investigationId/evidence?serviceId=&sourceType=&minRelevance=
  router.get("/investigations/:investigationId/evidence", (req: Request, res: Response) => {
    const { serviceId, sourceType, minRelevance } = req.query;
    const evidence = service.getEvidence(req.params.investigationId, {
      serviceId: typeof serviceId === "string" ? serviceId : undefined,
      sourceType: typeof sourceType === "string" ? sourceType : undefined,
      minRelevance: typeof minRelevance === "string" ? Number(minRelevance) : undefined,
    });
    if (evidence === null) return res.status(404).json({ error: "Investigation not found" });
    return res.json(evidence);
  });

  // GET /api/investigations/:investigationId/ai-context (Member 3 integration contract)
  router.get("/investigations/:investigationId/ai-context", (req: Request, res: Response) => {
    const context = service.getAIContext(req.params.investigationId);
    if (!context) return res.status(404).json({ error: "Investigation not found" });
    return res.json(context);
  });

  return router;
}

/** GET /api/incidents/:incidentId/investigation — mounted separately under /api/incidents */
export function createIncidentsRouter(service: InvestigationService): Router {
  const router = Router();

  router.get("/incidents/:incidentId/investigation", (req: Request, res: Response) => {
    const result = service.getLatestForIncident(req.params.incidentId);
    if (!result) return res.status(404).json({ error: "No investigation found for this incident" });
    return res.json(result);
  });

  return router;
}
