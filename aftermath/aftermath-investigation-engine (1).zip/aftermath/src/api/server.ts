import express, { Express } from "express";
import cors from "cors";
import { InvestigationEngine } from "../investigation/InvestigationEngine";
import { InvestigationService } from "../services/InvestigationService";
import { createIncidentsRouter, createInvestigationsRouter } from "./routes/investigations";
import { IncidentDataProvider, TelemetryProvider, DependencyProvider } from "../providers/interfaces";

/**
 * =============================================================================
 * INTEGRATION POINT FOR MEMBER 1
 * =============================================================================
 * `createServer` takes the three provider interfaces as parameters rather
 * than constructing mock providers itself. `src/index.ts` is the only place
 * that currently passes in the mock implementations. To integrate Member
 * 1's real telemetry system, implement IncidentDataProvider,
 * TelemetryProvider, and DependencyProvider against their real data source
 * and pass those instances into `createServer` instead - nothing in this
 * file, or in `src/investigation/*`, needs to change.
 * =============================================================================
 */
export function createServer(
  incidentProvider: IncidentDataProvider,
  telemetryProvider: TelemetryProvider,
  dependencyProvider: DependencyProvider
): { app: Express; service: InvestigationService } {
  const engine = new InvestigationEngine(incidentProvider, telemetryProvider, dependencyProvider);
  const service = new InvestigationService(engine);

  const app = express();
  app.use(cors());
  app.use(express.json());

  app.get("/health", (_req, res) => res.json({ status: "ok", service: "aftermath-investigation-engine" }));

  app.use("/api", createInvestigationsRouter(service));
  app.use("/api", createIncidentsRouter(service));

  app.use((req, res) => {
    res.status(404).json({ error: `Not found: ${req.method} ${req.path}` });
  });

  return { app, service };
}
