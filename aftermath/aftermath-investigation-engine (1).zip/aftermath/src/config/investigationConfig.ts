/**
 * Centralized, non-scoring configuration for the investigation engine.
 * Keep all "magic numbers" here rather than scattered through modules.
 */
export const INVESTIGATION_WINDOW = {
  /** How far before incident.detectedAt to look for evidence. */
  lookbackSeconds: 60,
  /** How far after incident.detectedAt to keep looking (captures tail-end user impact). */
  lookforwardSeconds: 30,
};

export const TEMPORAL_CORRELATION = {
  veryCloseSeconds: 5,
  closeSeconds: 15,
  mediumSeconds: 30,
};

export const PROPAGATION = {
  /** Max seconds between an upstream and downstream abnormal event to still be considered a propagation candidate. */
  maximumPropagationWindowSeconds: 30,
  /** Max dependency-graph hops to consider when looking for a propagation relationship. */
  maximumDependencyDistance: 4,
};

export const EVIDENCE_CLUSTERING = {
  /** Evidence within this many seconds of each other, on the same service, is considered part of the same cluster. */
  clusterGapSeconds: 20,
};

export const SUSPICIOUS_EVENT_TYPES = [
  "configuration_changed",
  "deployment_started",
  "deployment_completed",
  "service_restarted",
  "infrastructure_change",
  "dependency_change",
] as const;
