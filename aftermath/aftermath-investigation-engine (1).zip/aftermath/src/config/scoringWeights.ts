/**
 * All scoring weights live here so the algorithms remain explainable and
 * tunable without hunting through analyzer files. Every weight set below
 * sums (in its "full credit" case) to 100, so resulting scores are already
 * on a 0-100 confidence scale.
 */

/** PART 8 - Propagation confidence scoring factors */
export const PROPAGATION_WEIGHTS = {
  dependencyRelationship: 30,
  correctTimeOrdering: 25,
  closeTemporalDistance: 20,
  traceCorrelation: 15,
  logicalFailureConsistency: 10,
};

/** PART 5 - Suspicious change scoring factors (0-100 suspicion score) */
export const SUSPICION_WEIGHTS = {
  temporalProximity: 50,
  serviceProximity: 30,
  dependencyProximity: 20,
};

/**
 * PART 11/24 - Root cause candidate scoring factors.
 *
 * Includes an "explanatoryDepth" factor beyond the base PART 11 list: a
 * candidate that identifies a preceding MECHANISM (a config change, deploy,
 * restart, infra/dependency change) is a more useful, more actionable root
 * cause than a candidate that merely restates "this service was the first
 * to fail" with no explanation of why. Both are legitimate candidates and
 * both are surfaced, but an explanatory candidate should rank higher when
 * the evidence is otherwise comparable - which mirrors how a human SRE
 * investigating the incident would reason about it.
 */
export const ROOT_CAUSE_WEIGHTS = {
  temporalProximity: 25,
  serviceCorrelation: 15,
  firstFailureCorrelation: 15,
  propagationConsistency: 15,
  evidenceSupport: 10,
  severityCorrelation: 10,
  explanatoryDepth: 10,
  contradictionPenalty: -30, // applied per contradiction, floor at 0
};

export const CONFIDENCE_LEVELS = [
  { min: 90, level: "very_high" as const },
  { min: 70, level: "high" as const },
  { min: 50, level: "moderate" as const },
  { min: 30, level: "low" as const },
  { min: 0, level: "weak" as const },
];

export function confidenceLevelFor(confidence: number): "very_high" | "high" | "moderate" | "low" | "weak" {
  for (const { min, level } of CONFIDENCE_LEVELS) {
    if (confidence >= min) return level;
  }
  return "weak";
}
