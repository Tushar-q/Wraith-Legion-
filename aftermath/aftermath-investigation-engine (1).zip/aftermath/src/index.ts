import { createServer } from "./api/server";
import { MockIncidentDataProvider, MockTelemetryProvider, MockDependencyProvider } from "./providers/mock/MockProviders";

const PORT = process.env.PORT ? Number(process.env.PORT) : 4000;

// TODO(Member 1 integration): replace these three mock providers with real
// implementations of IncidentDataProvider / TelemetryProvider /
// DependencyProvider once Member 1's telemetry system is available. See
// src/api/server.ts and src/providers/interfaces.ts for the contract.
const incidentProvider = new MockIncidentDataProvider();
const telemetryProvider = new MockTelemetryProvider();
const dependencyProvider = new MockDependencyProvider();

const { app } = createServer(incidentProvider, telemetryProvider, dependencyProvider);

app.listen(PORT, () => {
  console.log(`AFTERMATH Investigation Engine listening on http://localhost:${PORT}`);
  console.log(`Try: POST http://localhost:${PORT}/api/investigations/INC-042/run`);
});
