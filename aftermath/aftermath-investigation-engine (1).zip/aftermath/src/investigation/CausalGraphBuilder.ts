import {
  CausalEdge,
  CausalGraph,
  CausalNode,
  ChangeCandidate,
  ClassifiedEvent,
  PropagationEdge,
  TimelineEvent,
} from "../types/investigation";
import { nextId } from "../utils/id";

/**
 * CausalGraphBuilder
 *
 * PART 9 — builds a frontend-friendly causal graph (nodes + evidence-backed
 * edges) directly from the timeline, the classified events, and the
 * propagation edges already derived by FailurePropagationAnalyzer.
 *
 * IMPORTANT: every edge here is derived from real analysis performed
 * elsewhere in the pipeline (propagation edges, chronological adjacency of
 * classified stages) - nothing is invented.
 */
export class CausalGraphBuilder {
  build(
    timeline: TimelineEvent[],
    classifiedEvents: ClassifiedEvent[],
    propagation: PropagationEdge[],
    suspiciousChanges: ChangeCandidate[]
  ): CausalGraph {
    const classificationByEventId = new Map(classifiedEvents.map((c) => [c.eventId, c]));

    const nodes: CausalNode[] = timeline.map((event) => ({
      id: event.id,
      type: this.nodeType(event, classificationByEventId.get(event.id)?.classification),
      timestamp: event.timestamp,
      serviceId: event.serviceId,
      title: event.title,
      description: event.description,
      severity: event.severity,
      evidenceIds: event.evidenceIds,
    }));

    const edges: CausalEdge[] = [];

    // Edge type 1: propagation edges (service-level) mapped down to the specific timeline events that
    // represent the onset evidence on each side, when we can identify them.
    for (const p of propagation) {
      const sourceNode = this.findNodeForEvidence(nodes, p.sourceEventId, p.sourceServiceId);
      const targetNode = this.findNodeForEvidence(nodes, p.targetEventId, p.targetServiceId);
      if (!sourceNode || !targetNode || sourceNode.id === targetNode.id) continue;
      edges.push({
        id: nextId("edge"),
        sourceId: sourceNode.id,
        targetId: targetNode.id,
        relationship: "propagated_to",
        confidence: p.confidence,
        explanation: p.explanation,
      });
    }

    // Edge type 2: suspicious changes -> the first abnormal event on the same service, shortly after.
    for (const change of suspiciousChanges) {
      const changeNode = nodes.find((n) => n.evidenceIds.includes(change.eventId));
      if (!changeNode) continue;
      const followingNode = nodes
        .filter((n) => n.serviceId === change.serviceId && n.timestamp > changeNode.timestamp)
        .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())[0];
      if (!followingNode) continue;
      edges.push({
        id: nextId("edge"),
        sourceId: changeNode.id,
        targetId: followingNode.id,
        relationship: change.suspicionScore >= 70 ? "likely_caused" : "likely_contributed_to",
        confidence: change.suspicionScore,
        explanation: change.explanation,
      });
    }

    // Edge type 3: chronological "preceded" edges within the same service, connecting consecutive
    // abnormal events that aren't already linked, so the graph reads as one continuous chain per service.
    const byService = new Map<string, CausalNode[]>();
    for (const n of nodes) {
      if (!n.serviceId) continue;
      if (!byService.has(n.serviceId)) byService.set(n.serviceId, []);
      byService.get(n.serviceId)!.push(n);
    }
    for (const [, serviceNodes] of byService) {
      const sorted = [...serviceNodes].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      for (let i = 0; i < sorted.length - 1; i++) {
        const a = sorted[i];
        const b = sorted[i + 1];
        const alreadyLinked = edges.some(
          (e) => (e.sourceId === a.id && e.targetId === b.id) || (e.sourceId === b.id && e.targetId === a.id)
        );
        if (alreadyLinked) continue;
        edges.push({
          id: nextId("edge"),
          sourceId: a.id,
          targetId: b.id,
          relationship: "preceded",
          confidence: 60,
          explanation: `${b.title} followed ${a.title} on the same service (${a.serviceId}).`,
        });
      }
    }

    // Edge type 4: last known failure/health node on each service -> the final user_impact node, if present.
    const impactNode = nodes.find((n) => n.type === "impact");
    if (impactNode) {
      for (const [, serviceNodes] of byService) {
        const sorted = [...serviceNodes].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        const last = sorted[sorted.length - 1];
        if (!last || last.id === impactNode.id || last.timestamp >= impactNode.timestamp) continue;
        const alreadyLinked = edges.some((e) => e.sourceId === last.id && e.targetId === impactNode.id);
        if (alreadyLinked) continue;
        edges.push({
          id: nextId("edge"),
          sourceId: last.id,
          targetId: impactNode.id,
          relationship: "likely_contributed_to",
          confidence: 55,
          explanation: `${last.title} on ${last.serviceId} preceded and plausibly contributed to observed user impact.`,
        });
      }
    }

    return { nodes, edges };
  }

  private nodeType(event: TimelineEvent, classification?: ClassifiedEvent["classification"]): CausalNode["type"] {
    if (event.type === "user_impact") return "impact";
    if (event.type === "system_event") return "change";
    if (event.type === "health_change") return "health";
    if (classification === "potential_cause") return "change";
    if (classification === "downstream_symptom" || classification === "intermediate_failure") return "failure";
    return "anomaly";
  }

  private findNodeForEvidence(nodes: CausalNode[], evidenceId: string | undefined, serviceId: string): CausalNode | undefined {
    if (evidenceId) {
      const byEvidence = nodes.find((n) => n.evidenceIds.includes(evidenceId));
      if (byEvidence) return byEvidence;
    }
    // Fall back to the earliest node on that service.
    return [...nodes]
      .filter((n) => n.serviceId === serviceId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())[0];
  }
}
