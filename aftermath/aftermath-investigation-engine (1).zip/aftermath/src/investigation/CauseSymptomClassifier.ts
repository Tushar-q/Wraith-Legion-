import { ClassifiedEvent, FirstFailureResult, PropagationEdge, TimelineEvent } from "../types/investigation";
import { DependencyAnalyzer } from "./DependencyAnalyzer";

/**
 * CauseSymptomClassifier
 *
 * PART 15 — deterministically (no AI/ML) classifies every timeline event
 * as one of: potential_cause, intermediate_failure, downstream_symptom,
 * user_impact. Uses only: timeline ordering, dependency relationships,
 * the first-failure result, and propagation direction.
 *
 * Rules (evaluated in order):
 *   1. Explicit user-impact events -> user_impact.
 *   2. Suspicious change events (config/deploy/restart) at or before the
 *      first failure -> potential_cause.
 *   3. Events on the first-failure service, at/near the first failure
 *      time -> intermediate_failure (the failure itself, not its cause).
 *   4. Events on services that are downstream (per the propagation edges)
 *      of the first-failure service -> downstream_symptom.
 *   5. Everything else -> intermediate_failure (conservative default -
 *      we don't have enough signal to call it a symptom or a cause).
 */
export class CauseSymptomClassifier {
  classify(
    timeline: TimelineEvent[],
    firstFailure: FirstFailureResult | null,
    propagation: PropagationEdge[],
    dependencyAnalyzer: DependencyAnalyzer
  ): ClassifiedEvent[] {
    const downstreamOfFirstFailure = new Set<string>();
    if (firstFailure) {
      // Prefer the actual propagation graph (evidence-derived) over raw dependency-graph reachability,
      // but fall back to the dependency graph if no propagation edges exist yet.
      const reachableViaPropagation = this.reachableViaPropagation(firstFailure.serviceId, propagation);
      const reachableViaDependencyGraph = dependencyAnalyzer.getDownstreamServices(firstFailure.serviceId);
      for (const s of reachableViaPropagation) downstreamOfFirstFailure.add(s);
      for (const s of reachableViaDependencyGraph) downstreamOfFirstFailure.add(s);
    }

    return timeline.map((event) => this.classifyOne(event, firstFailure, downstreamOfFirstFailure));
  }

  private classifyOne(
    event: TimelineEvent,
    firstFailure: FirstFailureResult | null,
    downstreamServices: Set<string>
  ): ClassifiedEvent {
    if (event.type === "user_impact") {
      return {
        eventId: event.id,
        classification: "user_impact",
        confidence: 95,
        explanation: "Event explicitly represents end-user-visible impact.",
      };
    }

    const isSuspiciousChange = event.type === "system_event" && /changed|deploy|restart/i.test(event.title);
    const atOrBeforeFirstFailure = firstFailure ? event.timestamp <= firstFailure.timestamp : false;

    if (isSuspiciousChange && atOrBeforeFirstFailure) {
      return {
        eventId: event.id,
        classification: "potential_cause",
        confidence: 85,
        explanation: `A system change occurred at/before the first abnormal behavior (${firstFailure?.timestamp ?? "unknown"}), making it a plausible originating cause.`,
      };
    }

    if (firstFailure && event.serviceId === firstFailure.serviceId) {
      return {
        eventId: event.id,
        classification: "intermediate_failure",
        confidence: 75,
        explanation: `Event occurred on ${firstFailure.serviceId}, the first affected service - this is part of the initial failure, not an upstream cause or downstream symptom.`,
      };
    }

    if (firstFailure && event.serviceId && downstreamServices.has(event.serviceId)) {
      return {
        eventId: event.id,
        classification: "downstream_symptom",
        confidence: 80,
        explanation: `Event occurred on ${event.serviceId}, which is downstream of ${firstFailure.serviceId} in the dependency/propagation graph - this is a symptom of the upstream failure.`,
      };
    }

    return {
      eventId: event.id,
      classification: "intermediate_failure",
      confidence: 40,
      explanation: "Insufficient evidence to confidently classify as cause or symptom; defaulted to intermediate failure.",
    };
  }

  private reachableViaPropagation(startServiceId: string, propagation: PropagationEdge[]): Set<string> {
    const adjacency = new Map<string, string[]>();
    for (const edge of propagation) {
      if (!adjacency.has(edge.sourceServiceId)) adjacency.set(edge.sourceServiceId, []);
      adjacency.get(edge.sourceServiceId)!.push(edge.targetServiceId);
    }
    const visited = new Set<string>();
    const queue = [startServiceId];
    while (queue.length > 0) {
      const current = queue.shift()!;
      for (const next of adjacency.get(current) ?? []) {
        if (!visited.has(next)) {
          visited.add(next);
          queue.push(next);
        }
      }
    }
    return visited;
  }
}
