import { ChangeCandidate, FirstFailureResult, InvestigationContext } from "../types/investigation";
import { SUSPICIOUS_EVENT_TYPES, TEMPORAL_CORRELATION } from "../config/investigationConfig";
import { SUSPICION_WEIGHTS } from "../config/scoringWeights";
import { diffSeconds, clamp } from "../utils/time";
import { DependencyAnalyzer } from "./DependencyAnalyzer";

const SUSPICIOUS_TYPES = new Set<string>(SUSPICIOUS_EVENT_TYPES);

/**
 * ChangeCorrelationAnalyzer
 *
 * Looks for system changes (config changes, deploys, restarts, infra /
 * dependency changes) that occurred shortly before the first failure, and
 * scores how suspicious each one is based on temporal proximity, whether it
 * hit the same service, and whether it hit an upstream dependency.
 */
export class ChangeCorrelationAnalyzer {
  analyze(
    context: InvestigationContext,
    firstFailure: FirstFailureResult | null,
    dependencyAnalyzer: DependencyAnalyzer
  ): ChangeCandidate[] {
    if (!firstFailure) return [];

    const candidates: ChangeCandidate[] = [];

    for (const event of context.events) {
      if (!SUSPICIOUS_TYPES.has(event.type)) continue;

      // Only consider changes that happened at or before the first failure - a change
      // AFTER the failure cannot have caused it.
      const temporalDistanceSeconds = diffSeconds(event.timestamp, firstFailure.timestamp);
      if (temporalDistanceSeconds < 0) continue;

      // 1. Temporal proximity score (closer = more suspicious)
      let temporalScore = 0;
      if (temporalDistanceSeconds <= TEMPORAL_CORRELATION.veryCloseSeconds) temporalScore = 1;
      else if (temporalDistanceSeconds <= TEMPORAL_CORRELATION.closeSeconds) temporalScore = 0.7;
      else if (temporalDistanceSeconds <= TEMPORAL_CORRELATION.mediumSeconds) temporalScore = 0.4;
      else temporalScore = 0.15;

      // 2. Service proximity: did it hit the same service as the first failure?
      const sameService = event.serviceId === firstFailure.serviceId;
      let serviceCorrelation = 0;
      if (sameService) {
        serviceCorrelation = 1.0;
      } else if (event.serviceId) {
        // 3. Dependency proximity: did it hit an upstream dependency of the first-failure service?
        const distance = dependencyAnalyzer.findDependencyDistance(firstFailure.serviceId, event.serviceId);
        if (distance !== null && distance > 0) {
          serviceCorrelation = clamp(1 - distance * 0.3, 0, 0.9);
        } else {
          serviceCorrelation = 0.1; // unrelated service - very weak correlation
        }
      } else {
        serviceCorrelation = 0.3; // global/unscoped event - some relevance, unknown target
      }

      const suspicionScore = clamp(
        temporalScore * SUSPICION_WEIGHTS.temporalProximity +
          serviceCorrelation * (sameService ? SUSPICION_WEIGHTS.serviceProximity : 0) +
          (!sameService ? serviceCorrelation * SUSPICION_WEIGHTS.dependencyProximity : SUSPICION_WEIGHTS.dependencyProximity),
        0,
        100
      );

      candidates.push({
        eventId: event.id,
        serviceId: event.serviceId,
        timestamp: event.timestamp,
        changeType: event.type,
        temporalDistanceSeconds,
        serviceCorrelation,
        suspicionScore: Math.round(suspicionScore),
        explanation: this.explain(event.type, temporalDistanceSeconds, sameService, event.serviceId, firstFailure.serviceId),
      });
    }

    return candidates.sort((a, b) => b.suspicionScore - a.suspicionScore);
  }

  private explain(
    changeType: string,
    temporalDistanceSeconds: number,
    sameService: boolean,
    changeServiceId: string | undefined,
    firstFailureServiceId: string
  ): string {
    const timing =
      temporalDistanceSeconds <= TEMPORAL_CORRELATION.veryCloseSeconds
        ? `only ${temporalDistanceSeconds}s before`
        : `${temporalDistanceSeconds}s before`;
    const scope = sameService
      ? `directly on ${firstFailureServiceId}, the first affected service`
      : changeServiceId
      ? `on ${changeServiceId}, related to ${firstFailureServiceId}`
      : "with global scope";
    return `A ${changeType.replace(/_/g, " ")} occurred ${timing} the first abnormal behavior, ${scope}.`;
  }
}
