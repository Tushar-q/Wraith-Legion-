import { ServiceDependency } from "../types/telemetry";

/**
 * DependencyAnalyzer
 *
 * Wraps the static service dependency graph and provides traversal
 * utilities used by propagation and change-correlation analysis.
 *
 * DIRECTION CONVENTION (see types/telemetry.ts for the canonical doc):
 *   Edge { serviceId: A, dependsOnServiceId: B } means "A calls B".
 *   - UPSTREAM of A  = services A depends on (B, and B's own upstreams...) -
 *     closer to the root of a request chain / more likely original cause.
 *   - DOWNSTREAM of A = services that depend on A (i.e. A's callers) -
 *     these are the services AFFECTED when A fails.
 *   - Failure PROPAGATES from a service to its DOWNSTREAM (its callers),
 *     which is the reverse of the "dependsOn" arrow.
 *   - findPath(source, target) therefore searches the DOWNSTREAM
 *     (caller) direction, because that's the direction a real failure
 *     travels: source fails -> callers of source are affected -> callers
 *     of THOSE callers are affected, etc.
 */
export class DependencyAnalyzer {
  private readonly dependsOnMap = new Map<string, Set<string>>(); // serviceId -> set of services it depends on (upstream)
  private readonly dependedByMap = new Map<string, Set<string>>(); // serviceId -> set of services that depend on it (downstream)

  constructor(private readonly dependencies: ServiceDependency[]) {
    for (const dep of dependencies) {
      if (!this.dependsOnMap.has(dep.serviceId)) this.dependsOnMap.set(dep.serviceId, new Set());
      this.dependsOnMap.get(dep.serviceId)!.add(dep.dependsOnServiceId);

      if (!this.dependedByMap.has(dep.dependsOnServiceId)) this.dependedByMap.set(dep.dependsOnServiceId, new Set());
      this.dependedByMap.get(dep.dependsOnServiceId)!.add(dep.serviceId);
    }
  }

  /** Direct + transitive services that `serviceId` depends on. */
  getUpstreamServices(serviceId: string): string[] {
    return this.traverse(serviceId, this.dependsOnMap);
  }

  /** Direct + transitive services that depend on `serviceId` (i.e. are affected if it fails). */
  getDownstreamServices(serviceId: string): string[] {
    return this.traverse(serviceId, this.dependedByMap);
  }

  /** Direct dependencies only (services `serviceId` calls). */
  getDependencies(serviceId: string): string[] {
    return Array.from(this.dependsOnMap.get(serviceId) ?? []);
  }

  /** Direct dependents only (services that call `serviceId`). */
  getDependents(serviceId: string): string[] {
    return Array.from(this.dependedByMap.get(serviceId) ?? []);
  }

  /**
   * Finds a propagation path from `source` to `target`, walking the
   * DOWNSTREAM (dependent/caller) direction - i.e. the direction a real
   * failure would travel. Returns the path INCLUSIVE of source and target,
   * or null if target is not reachable downstream of source.
   */
  findPath(source: string, target: string): string[] | null {
    if (source === target) return [source];
    const queue: string[][] = [[source]];
    const visited = new Set<string>([source]);

    while (queue.length > 0) {
      const path = queue.shift()!;
      const last = path[path.length - 1];
      for (const next of this.getDependents(last)) {
        if (visited.has(next)) continue;
        const newPath = [...path, next];
        if (next === target) return newPath;
        visited.add(next);
        queue.push(newPath);
      }
    }
    return null;
  }

  /**
   * Number of hops in the downstream propagation direction from `source` to
   * `target`. Returns 0 if source === target, null if unreachable.
   */
  findDependencyDistance(source: string, target: string): number | null {
    const path = this.findPath(source, target);
    if (!path) return null;
    return path.length - 1;
  }

  private traverse(start: string, adjacency: Map<string, Set<string>>): string[] {
    const visited = new Set<string>();
    const queue = [start];
    while (queue.length > 0) {
      const current = queue.shift()!;
      for (const next of adjacency.get(current) ?? []) {
        if (!visited.has(next)) {
          visited.add(next);
          queue.push(next);
        }
      }
    }
    return Array.from(visited);
  }
}
