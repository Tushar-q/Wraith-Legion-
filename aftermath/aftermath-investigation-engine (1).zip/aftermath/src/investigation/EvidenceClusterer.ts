import { EvidenceCluster, EvidenceItem } from "../types/investigation";
import { EVIDENCE_CLUSTERING } from "../config/investigationConfig";
import { diffSeconds, sortByTimestampAsc } from "../utils/time";
import { nextId } from "../utils/id";

/**
 * EvidenceClusterer
 *
 * PART 14 — groups evidence into EvidenceCluster objects when it comes from
 * the same service and falls within a small time gap of other evidence in
 * the same group. This is a simple deterministic "single-linkage" temporal
 * clustering, per service. A cluster's confidence grows with the number and
 * diversity of independent evidence sources it contains.
 */
export class EvidenceClusterer {
  cluster(evidence: EvidenceItem[]): EvidenceCluster[] {
    const byService = new Map<string, EvidenceItem[]>();
    for (const item of evidence) {
      const key = item.serviceId ?? "__global__";
      if (!byService.has(key)) byService.set(key, []);
      byService.get(key)!.push(item);
    }

    const clusters: EvidenceCluster[] = [];

    for (const [serviceId, items] of byService.entries()) {
      const sorted = sortByTimestampAsc(items);
      let current: EvidenceItem[] = [];

      const flush = () => {
        if (current.length === 0) return;
        clusters.push(this.buildCluster(serviceId === "__global__" ? undefined : serviceId, current));
        current = [];
      };

      for (const item of sorted) {
        if (current.length === 0) {
          current.push(item);
          continue;
        }
        const last = current[current.length - 1];
        const gap = diffSeconds(last.timestamp, item.timestamp);
        if (gap <= EVIDENCE_CLUSTERING.clusterGapSeconds) {
          current.push(item);
        } else {
          flush();
          current.push(item);
        }
      }
      flush();
    }

    return clusters.sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
  }

  private buildCluster(serviceId: string | undefined, items: EvidenceItem[]): EvidenceCluster {
    const sourceTypes = new Set(items.map((i) => i.sourceType));
    const avgRelevance = items.reduce((sum, i) => sum + i.relevanceScore, 0) / items.length;
    // Confidence: more independent source types + higher average relevance = stronger cluster.
    const diversityBonus = Math.min(sourceTypes.size * 12, 48);
    const confidence = Math.max(0, Math.min(100, Math.round(avgRelevance * 0.5 + diversityBonus)));

    return {
      id: nextId("cluster"),
      serviceId,
      startTime: items[0].timestamp,
      endTime: items[items.length - 1].timestamp,
      theme: this.theme(serviceId, sourceTypes),
      evidenceIds: items.map((i) => i.id),
      confidence,
    };
  }

  private theme(serviceId: string | undefined, sourceTypes: Set<string>): string {
    const svc = serviceId ?? "system-wide";
    return `${svc} anomaly cluster (${Array.from(sourceTypes).join(", ")})`;
  }
}
