import { EvidenceItem, FirstFailureResult, InvestigationContext } from "../types/investigation";
import { diffSeconds, sortByTimestampAsc } from "../utils/time";

/**
 * EvidenceCollector
 *
 * PART 13 — normalizes every raw telemetry item in the InvestigationContext
 * into a single, uniform EvidenceItem[], with a relevance score reflecting
 * how central each piece of evidence is to the incident (proximity to the
 * first failure, severity, whether it's on an affected service).
 *
 * Every timeline event, propagation edge, and root cause candidate should
 * be traceable back to items produced here.
 */
export class EvidenceCollector {
  collect(context: InvestigationContext, firstFailure: FirstFailureResult | null): EvidenceItem[] {
    const items: EvidenceItem[] = [];

    for (const e of context.events) {
      items.push({
        id: e.id,
        sourceType: "event",
        sourceId: e.id,
        timestamp: e.timestamp,
        serviceId: e.serviceId,
        title: e.type.replace(/_/g, " "),
        description: e.description,
        relevanceScore: this.relevance(e.timestamp, e.serviceId, firstFailure, e.type === "configuration_changed" ? 15 : 0),
      });
    }

    for (const a of context.anomalies) {
      items.push({
        id: a.id,
        sourceType: "anomaly",
        sourceId: a.id,
        timestamp: a.timestamp,
        serviceId: a.serviceId,
        title: a.type.replace(/_/g, " "),
        description: a.description,
        relevanceScore: this.relevance(a.timestamp, a.serviceId, firstFailure, a.severity === "critical" ? 10 : 0),
      });
    }

    for (const l of context.logs) {
      if (l.level === "debug" || l.level === "info") continue;
      items.push({
        id: l.id,
        sourceType: "log",
        sourceId: l.id,
        timestamp: l.timestamp,
        serviceId: l.serviceId,
        title: `${l.level} log`,
        description: l.message,
        relevanceScore: this.relevance(l.timestamp, l.serviceId, firstFailure, l.level === "fatal" ? 10 : 0),
      });
    }

    for (const m of context.metrics) {
      items.push({
        id: m.id,
        sourceType: "metric",
        sourceId: m.id,
        timestamp: m.timestamp,
        serviceId: m.serviceId,
        title: m.name,
        description: `${m.name} = ${m.value}${m.unit ? m.unit : ""}`,
        relevanceScore: this.relevance(m.timestamp, m.serviceId, firstFailure, 0),
      });
    }

    for (const tr of context.traces) {
      items.push({
        id: tr.id,
        sourceType: "trace",
        sourceId: tr.id,
        timestamp: tr.timestamp,
        serviceId: tr.path[tr.path.length - 1],
        title: `trace ${tr.status}`,
        description: `Request through [${tr.path.join(" -> ")}] resulted in ${tr.status} after ${tr.durationMs}ms.`,
        relevanceScore: this.relevance(tr.timestamp, tr.path[0], firstFailure, tr.status !== "ok" ? 10 : -20),
      });
    }

    for (const h of context.healthHistory) {
      items.push({
        id: h.id,
        sourceType: "health",
        sourceId: h.id,
        timestamp: h.timestamp,
        serviceId: h.serviceId,
        title: `health: ${h.status}`,
        description: `Health score ${h.healthScore}, error rate ${(h.errorRate * 100).toFixed(0)}%, latency ${h.latencyMs}ms.`,
        relevanceScore: this.relevance(h.timestamp, h.serviceId, firstFailure, h.status === "unhealthy" ? 10 : 0),
      });
    }

    return sortByTimestampAsc(items);
  }

  /**
   * Base relevance decays with distance (in seconds) from the first
   * failure's timestamp, and gets a bonus if it's on the first-failure
   * service. A per-item bonus can be added by callers for source-specific
   * signals (e.g. critical severity).
   */
  private relevance(
    timestamp: string,
    serviceId: string | undefined,
    firstFailure: FirstFailureResult | null,
    bonus: number
  ): number {
    let score = 50 + bonus;
    if (firstFailure) {
      const distance = Math.abs(diffSeconds(firstFailure.timestamp, timestamp));
      score += Math.max(0, 30 - distance); // within 30s of first failure adds up to +30
      if (serviceId === firstFailure.serviceId) score += 15;
    }
    return Math.max(0, Math.min(100, Math.round(score)));
  }
}
