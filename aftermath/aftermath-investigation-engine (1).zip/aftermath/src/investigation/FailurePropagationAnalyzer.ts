import { InvestigationContext, PropagationEdge } from "../types/investigation";
import { DependencyAnalyzer } from "./DependencyAnalyzer";
import { PropagationScorer } from "./PropagationScorer";
import { PROPAGATION } from "../config/investigationConfig";
import { diffSeconds } from "../utils/time";

interface ServiceOnset {
  serviceId: string;
  timestamp: string;
  evidenceIds: string[];
  kind: "timeout" | "latency" | "error" | "retry" | "health" | "other";
}

const TIMEOUT_LIKE = new Set(["timeout_spike"]);
const LATENCY_LIKE = new Set(["latency_spike", "saturation"]);
const ERROR_LIKE = new Set(["error_rate_spike", "throughput_drop"]);

/**
 * FailurePropagationAnalyzer
 *
 * PART 7 — determines whether failures spread through the service
 * dependency graph over time, by:
 *   1. Computing each service's earliest "onset" of abnormal behavior.
 *   2. For every direct dependency edge (in the propagation/downstream
 *      direction), checking whether the downstream service's onset
 *      followed the upstream service's onset within the propagation
 *      window.
 *   3. Corroborating with trace evidence and logical failure-type
 *      consistency.
 *   4. Scoring the resulting edge with PropagationScorer.
 *
 * Edges are only created between services with a DIRECT dependency
 * relationship (dependencyDistance === 1), so the resulting graph is a
 * clean, chainable propagation path rather than a dense transitive mess.
 */
export class FailurePropagationAnalyzer {
  constructor(private readonly scorer: PropagationScorer = new PropagationScorer()) {}

  analyze(context: InvestigationContext, dependencyAnalyzer: DependencyAnalyzer): PropagationEdge[] {
    const onsets = this.computeServiceOnsets(context);
    const edges: PropagationEdge[] = [];

    const serviceIds = Array.from(onsets.keys());

    for (const sourceId of serviceIds) {
      const dependents = dependencyAnalyzer.getDependents(sourceId); // direct downstream (callers)
      for (const targetId of dependents) {
        const source = onsets.get(sourceId);
        const target = onsets.get(targetId);
        if (!source || !target) continue; // no evidence on one side -> nothing to correlate

        const timeDifferenceSeconds = diffSeconds(source.timestamp, target.timestamp);
        const correctTimeOrdering = timeDifferenceSeconds > 0;
        if (!correctTimeOrdering) continue; // downstream can't be caused by something that happened after it
        if (timeDifferenceSeconds > PROPAGATION.maximumPropagationWindowSeconds) continue; // too far apart to plausibly correlate

        const hasTraceCorrelation = context.traces.some(
          (tr) => tr.status !== "ok" && tr.path.includes(sourceId) && tr.path.includes(targetId)
        );

        const logicallyConsistent = this.isLogicallyConsistent(source.kind, target.kind);

        const { confidence, factors } = this.scorer.score({
          hasDirectDependency: true,
          correctTimeOrdering,
          timeDifferenceSeconds,
          hasTraceCorrelation,
          logicallyConsistent,
        });

        const traceEvidenceIds = context.traces
          .filter((tr) => tr.status !== "ok" && tr.path.includes(sourceId) && tr.path.includes(targetId))
          .map((tr) => tr.id);

        edges.push({
          sourceServiceId: sourceId,
          targetServiceId: targetId,
          sourceEventId: source.evidenceIds[0],
          targetEventId: target.evidenceIds[0],
          timeDifferenceSeconds,
          dependencyDistance: 1,
          confidence,
          explanation: this.explain(sourceId, targetId, timeDifferenceSeconds, source.kind, target.kind),
          evidenceIds: Array.from(new Set([...source.evidenceIds, ...target.evidenceIds, ...traceEvidenceIds])),
          factors,
        });
      }
    }

    return edges.sort((a, b) => b.confidence - a.confidence);
  }

  /** Earliest abnormal signal per service, classified by "kind" for logical-consistency checks. */
  private computeServiceOnsets(context: InvestigationContext): Map<string, ServiceOnset> {
    const onsets = new Map<string, ServiceOnset>();

    const consider = (serviceId: string | undefined, timestamp: string, evidenceId: string, kind: ServiceOnset["kind"]) => {
      if (!serviceId) return;
      const existing = onsets.get(serviceId);
      if (!existing || new Date(timestamp).getTime() < new Date(existing.timestamp).getTime()) {
        onsets.set(serviceId, { serviceId, timestamp, evidenceIds: [evidenceId], kind });
      } else if (existing.timestamp === timestamp) {
        existing.evidenceIds.push(evidenceId);
      }
    };

    for (const a of context.anomalies) {
      const kind: ServiceOnset["kind"] = TIMEOUT_LIKE.has(a.type)
        ? "timeout"
        : LATENCY_LIKE.has(a.type)
        ? "latency"
        : ERROR_LIKE.has(a.type)
        ? "error"
        : a.type === "health_degradation"
        ? "health"
        : "other";
      consider(a.serviceId, a.timestamp, a.id, kind);
    }

    for (const h of context.healthHistory) {
      if (h.status === "healthy") continue;
      consider(h.serviceId, h.timestamp, h.id, "health");
    }

    for (const l of context.logs) {
      if (l.level !== "error" && l.level !== "fatal") continue;
      const kind: ServiceOnset["kind"] = /retry/i.test(l.message)
        ? "retry"
        : /timeout/i.test(l.message)
        ? "timeout"
        : "error";
      consider(l.serviceId, l.timestamp, l.id, kind);
    }

    return onsets;
  }

  /**
   * Heuristic, deterministic (no ML) check for whether a downstream failure
   * "kind" is a plausible consequence of the upstream failure "kind".
   * E.g. an upstream timeout plausibly causes downstream retries, which
   * plausibly cause downstream error/health degradation.
   */
  private isLogicallyConsistent(sourceKind: ServiceOnset["kind"], targetKind: ServiceOnset["kind"]): boolean {
    const plausibleFollowers: Record<ServiceOnset["kind"], ServiceOnset["kind"][]> = {
      latency: ["timeout", "error", "retry", "health"],
      timeout: ["retry", "error", "health"],
      retry: ["error", "health"],
      error: ["error", "health"],
      health: ["error", "health"],
      other: ["timeout", "latency", "error", "retry", "health", "other"],
    };
    return plausibleFollowers[sourceKind]?.includes(targetKind) ?? false;
  }

  private explain(
    sourceId: string,
    targetId: string,
    timeDifferenceSeconds: number,
    sourceKind: string,
    targetKind: string
  ): string {
    return `${targetId} showed abnormal behavior (${targetKind}) ${timeDifferenceSeconds}s after ${sourceId} showed abnormal behavior (${sourceKind}), and ${targetId} depends on ${sourceId}.`;
  }
}
