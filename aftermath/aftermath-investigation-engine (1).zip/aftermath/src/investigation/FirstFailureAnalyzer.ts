import { FirstFailureResult, InvestigationContext } from "../types/investigation";
import { diffSeconds } from "../utils/time";

interface Candidate {
  serviceId: string;
  timestamp: string;
  anomalyId?: string;
  evidenceIds: string[];
  weight: number; // how strong a signal this evidence type is, used to break ties
  reason: string;
}

/**
 * FirstFailureAnalyzer
 *
 * Determines which service showed the earliest abnormal behavior, by
 * scanning ALL evidence types (anomalies, health degradations, error/fatal
 * logs, timeouts in traces) rather than trusting incident.detectedAt or any
 * single signal. The earliest timestamp wins; ties are broken by evidence
 * strength (severity of the underlying signal).
 */
export class FirstFailureAnalyzer {
  analyze(context: InvestigationContext): FirstFailureResult | null {
    const candidates: Candidate[] = [];

    for (const a of context.anomalies) {
      candidates.push({
        serviceId: a.serviceId,
        timestamp: a.timestamp,
        anomalyId: a.id,
        evidenceIds: [a.id],
        weight: a.severity === "critical" ? 4 : a.severity === "error" ? 3 : a.severity === "warning" ? 2 : 1,
        reason: `first anomaly (${a.type.replace(/_/g, " ")})`,
      });
    }

    for (const h of context.healthHistory) {
      if (h.status === "healthy") continue;
      candidates.push({
        serviceId: h.serviceId,
        timestamp: h.timestamp,
        evidenceIds: [h.id],
        weight: h.status === "unhealthy" ? 3 : 2,
        reason: "first health degradation",
      });
    }

    for (const l of context.logs) {
      if (l.level !== "error" && l.level !== "fatal") continue;
      candidates.push({
        serviceId: l.serviceId,
        timestamp: l.timestamp,
        evidenceIds: [l.id],
        weight: l.level === "fatal" ? 3 : 2,
        reason: "first error log",
      });
    }

    for (const tr of context.traces) {
      if (tr.status === "ok") continue;
      // Attribute a trace failure to the deepest (most upstream) failing span if we have span data.
      const failingSpan = tr.spans?.find((s) => s.status !== "ok");
      const serviceId = failingSpan?.serviceId ?? tr.path[tr.path.length - 1] ?? tr.serviceId;
      candidates.push({
        serviceId,
        timestamp: tr.timestamp,
        evidenceIds: [tr.id],
        weight: tr.status === "timeout" ? 3 : 2,
        reason: "first failed trace",
      });
    }

    if (candidates.length === 0) return null;

    // Sort by time first, then by weight (descending) to break exact ties deterministically.
    candidates.sort((a, b) => {
      const byTime = new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
      if (byTime !== 0) return byTime;
      return b.weight - a.weight;
    });

    const earliestTimestamp = candidates[0].timestamp;
    // Among all candidates at (or within 1s of) the earliest timestamp, prefer the strongest signal.
    const atEarliest = candidates.filter((c) => Math.abs(diffSeconds(earliestTimestamp, c.timestamp)) <= 1);
    atEarliest.sort((a, b) => b.weight - a.weight);
    const winner = atEarliest[0];

    // Confidence reflects how much corroborating evidence exists close to the winning service/time,
    // and how clearly it precedes other services' first abnormal signals.
    const evidenceIds = new Set<string>();
    let corroboration = 0;
    for (const c of candidates) {
      if (c.serviceId === winner.serviceId && Math.abs(diffSeconds(winner.timestamp, c.timestamp)) <= 10) {
        c.evidenceIds.forEach((id) => evidenceIds.add(id));
        corroboration += 1;
      }
    }

    const otherServicesEarliest = new Map<string, string>();
    for (const c of candidates) {
      if (c.serviceId === winner.serviceId) continue;
      if (!otherServicesEarliest.has(c.serviceId) || c.timestamp < otherServicesEarliest.get(c.serviceId)!) {
        otherServicesEarliest.set(c.serviceId, c.timestamp);
      }
    }
    const marginsSeconds = [...otherServicesEarliest.values()].map((ts) => diffSeconds(winner.timestamp, ts));
    const minMargin = marginsSeconds.length > 0 ? Math.min(...marginsSeconds) : 999;

    let confidence = 60;
    confidence += Math.min(corroboration * 8, 24); // more corroborating evidence -> more confident
    confidence += minMargin >= 3 ? 16 : minMargin >= 1 ? 8 : 0; // clear separation from next-earliest service
    confidence = Math.max(0, Math.min(100, confidence));

    return {
      serviceId: winner.serviceId,
      timestamp: winner.timestamp,
      anomalyId: winner.anomalyId,
      evidenceIds: Array.from(evidenceIds.size > 0 ? evidenceIds : winner.evidenceIds),
      confidence,
      explanation: `${winner.serviceId} showed the earliest abnormal behavior (${winner.reason} at ${winner.timestamp}), preceding abnormal behavior in any other affected service.`,
    };
  }
}
