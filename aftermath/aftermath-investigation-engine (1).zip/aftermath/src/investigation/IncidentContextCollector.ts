import { IncidentDataProvider, TelemetryProvider, DependencyProvider } from "../providers/interfaces";
import { InvestigationContext } from "../types/investigation";
import { INVESTIGATION_WINDOW } from "../config/investigationConfig";
import { addSeconds, sortByTimestampAsc } from "../utils/time";

export interface EvidenceWindowOptions {
  lookbackSeconds?: number;
  lookforwardSeconds?: number;
}

/**
 * IncidentContextCollector
 *
 * Gathers everything relevant to one incident - the incident itself,
 * affected services, the dependency graph, and all telemetry within a
 * configurable evidence window - and organizes it into a single
 * InvestigationContext that every downstream analyzer consumes.
 *
 * This is the ONLY module that talks to the provider interfaces. Every
 * other analyzer in this engine works purely off InvestigationContext.
 */
export class IncidentContextCollector {
  constructor(
    private readonly incidentProvider: IncidentDataProvider,
    private readonly telemetryProvider: TelemetryProvider,
    private readonly dependencyProvider: DependencyProvider
  ) {}

  async collect(incidentId: string, options: EvidenceWindowOptions = {}): Promise<InvestigationContext> {
    const incident = await this.incidentProvider.getIncident(incidentId);
    if (!incident) {
      throw new Error(`Incident not found: ${incidentId}`);
    }

    const lookbackSeconds = options.lookbackSeconds ?? INVESTIGATION_WINDOW.lookbackSeconds;
    const lookforwardSeconds = options.lookforwardSeconds ?? INVESTIGATION_WINDOW.lookforwardSeconds;

    // PART 2 - Evidence window: investigate before AND after detection time.
    const windowStart = addSeconds(incident.detectedAt, -lookbackSeconds);
    const windowEnd = addSeconds(incident.detectedAt, lookforwardSeconds);

    // All services + full dependency graph (small system, cheap to load in full;
    // needed anyway for propagation/dependency analysis beyond just affected services).
    const [allServices, dependencies] = await Promise.all([
      this.dependencyProvider.getAllServices(),
      this.dependencyProvider.getDependencies(),
    ]);

    const affectedServiceIds = incident.affectedServiceIds;
    const affectedServices = allServices.filter((s) => affectedServiceIds.includes(s.id));

    // Telemetry is scoped to affected services for the primary query set, but events
    // are also fetched globally (serviceId undefined) since some events (e.g. detection)
    // aren't tied to a single service.
    const [anomalies, logs, metrics, events, traces, healthHistory] = await Promise.all([
      this.telemetryProvider.getAnomalies(affectedServiceIds, windowStart, windowEnd),
      this.telemetryProvider.getLogs(affectedServiceIds, windowStart, windowEnd),
      this.telemetryProvider.getMetrics(affectedServiceIds, windowStart, windowEnd),
      this.telemetryProvider.getEvents(undefined, windowStart, windowEnd),
      this.telemetryProvider.getTraces(affectedServiceIds, windowStart, windowEnd),
      this.telemetryProvider.getHealthHistory(affectedServiceIds, windowStart, windowEnd),
    ]);

    return {
      incident,
      services: affectedServices.length > 0 ? affectedServices : allServices,
      dependencies,
      anomalies: sortByTimestampAsc(anomalies),
      logs: sortByTimestampAsc(logs),
      metrics: sortByTimestampAsc(metrics),
      events: sortByTimestampAsc(events),
      traces: sortByTimestampAsc(traces),
      healthHistory: sortByTimestampAsc(healthHistory),
      window: {
        start: windowStart,
        end: windowEnd,
        lookbackSeconds,
        lookforwardSeconds,
      },
    };
  }
}
