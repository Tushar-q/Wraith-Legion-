import { IncidentDataProvider, TelemetryProvider, DependencyProvider } from "../providers/interfaces";
import { IncidentContextCollector, EvidenceWindowOptions } from "./IncidentContextCollector";
import { TimelineBuilder } from "./TimelineBuilder";
import { FirstFailureAnalyzer } from "./FirstFailureAnalyzer";
import { ChangeCorrelationAnalyzer } from "./ChangeCorrelationAnalyzer";
import { DependencyAnalyzer } from "./DependencyAnalyzer";
import { FailurePropagationAnalyzer } from "./FailurePropagationAnalyzer";
import { EvidenceCollector } from "./EvidenceCollector";
import { EvidenceClusterer } from "./EvidenceClusterer";
import { CauseSymptomClassifier } from "./CauseSymptomClassifier";
import { RootCauseCandidateGenerator } from "./RootCauseCandidateGenerator";
import { RootCauseScorer } from "./RootCauseScorer";
import { CausalGraphBuilder } from "./CausalGraphBuilder";
import { AIInvestigationContext, InvestigationResult } from "../types/investigation";
import { nextId } from "../utils/id";

/**
 * InvestigationEngine
 *
 * PART 16 — the central orchestrator. Wires together every analyzer in the
 * correct order and produces a single InvestigationResult. This is the
 * class other layers (API, Member 3, Member 4) should talk to; nothing else
 * in this package needs to be imported directly by external code.
 */
export class InvestigationEngine {
  private readonly contextCollector: IncidentContextCollector;
  private readonly timelineBuilder = new TimelineBuilder();
  private readonly firstFailureAnalyzer = new FirstFailureAnalyzer();
  private readonly changeCorrelationAnalyzer = new ChangeCorrelationAnalyzer();
  private readonly propagationAnalyzer = new FailurePropagationAnalyzer();
  private readonly evidenceCollector = new EvidenceCollector();
  private readonly evidenceClusterer = new EvidenceClusterer();
  private readonly classifier = new CauseSymptomClassifier();
  private readonly candidateGenerator = new RootCauseCandidateGenerator();
  private readonly rootCauseScorer = new RootCauseScorer();
  private readonly causalGraphBuilder = new CausalGraphBuilder();

  constructor(
    incidentProvider: IncidentDataProvider,
    telemetryProvider: TelemetryProvider,
    private readonly dependencyProvider: DependencyProvider
  ) {
    this.contextCollector = new IncidentContextCollector(incidentProvider, telemetryProvider, dependencyProvider);
  }

  async run(incidentId: string, options: EvidenceWindowOptions = {}): Promise<InvestigationResult> {
    const { result } = await this.runWithDetails(incidentId, options);
    return result;
  }

  /**
   * Same as `run`, but also returns the evidence list and the source
   * incident, for callers (like InvestigationService) that need to persist
   * or expose evidence separately from the main InvestigationResult shape.
   */
  async runWithDetails(
    incidentId: string,
    options: EvidenceWindowOptions = {}
  ): Promise<{ result: InvestigationResult; evidence: import("../types/investigation").EvidenceItem[]; incident: import("../types/telemetry").Incident | null }> {
    const investigationId = nextId("investigation");
    const createdAt = new Date().toISOString();

    try {
      // 1-2. Collect context + evidence window.
      const context = await this.contextCollector.collect(incidentId, options);
      const dependencyAnalyzer = new DependencyAnalyzer(context.dependencies);

      // 3. Timeline.
      const timeline = this.timelineBuilder.build(context);

      // 4. First failure.
      const firstFailure = this.firstFailureAnalyzer.analyze(context);

      // 5. Suspicious changes.
      const suspiciousChanges = this.changeCorrelationAnalyzer.analyze(context, firstFailure, dependencyAnalyzer);

      // 6-7. Dependency + propagation analysis.
      const propagation = this.propagationAnalyzer.analyze(context, dependencyAnalyzer);

      // Evidence collection + clustering.
      const evidence = this.evidenceCollector.collect(context, firstFailure);
      const evidenceClusters = this.evidenceClusterer.cluster(evidence);

      // 9. Cause vs symptom classification.
      const classifiedEvents = this.classifier.classify(timeline, firstFailure, propagation, dependencyAnalyzer);

      // 10-11-12. Root cause candidates -> scoring -> confidence.
      const rawCandidates = this.candidateGenerator.generate(context, firstFailure, suspiciousChanges);
      const rootCauseCandidates = rawCandidates
        .map((c) =>
          this.rootCauseScorer.score(c, firstFailure, propagation, evidence, dependencyAnalyzer, context.incident.severity)
        )
        .sort((a, b) => b.confidence - a.confidence);

      const primaryHypothesis = rootCauseCandidates[0] ?? null;

      // 9(cont). Causal graph.
      const causalGraph = this.causalGraphBuilder.build(timeline, classifiedEvents, propagation, suspiciousChanges);

      // Build propagation path string (service IDs in order of onset, following propagation edges from first failure).
      const propagationPath = this.buildPropagationPath(firstFailure?.serviceId, propagation);

      const result: InvestigationResult = {
        investigationId,
        incidentId,
        status: "completed",
        timeline,
        firstFailure,
        suspiciousChanges,
        propagation,
        causalGraph,
        evidenceClusters,
        rootCauseCandidates,
        primaryHypothesis,
        classifiedEvents,
        summary: {
          affectedServices: context.incident.affectedServiceIds,
          firstAffectedService: firstFailure?.serviceId,
          estimatedStartTime: firstFailure?.timestamp,
          propagationPath,
          totalEvidenceItems: evidence.length,
          confidence: primaryHypothesis?.confidence ?? 0,
        },
        createdAt,
      };

      return { result, evidence, incident: context.incident };
    } catch (err) {
      const failedResult: InvestigationResult = {
        investigationId,
        incidentId,
        status: "failed",
        timeline: [],
        firstFailure: null,
        suspiciousChanges: [],
        propagation: [],
        causalGraph: { nodes: [], edges: [] },
        evidenceClusters: [],
        rootCauseCandidates: [],
        primaryHypothesis: null,
        classifiedEvents: [],
        summary: {
          affectedServices: [],
          propagationPath: [],
          totalEvidenceItems: 0,
          confidence: 0,
        },
        createdAt,
        error: err instanceof Error ? err.message : String(err),
      };
      return { result: failedResult, evidence: [], incident: null };
    }
  }

  /** Builds Member 3's AI-ready context from an already-computed InvestigationResult + the source incident. */
  buildAIContext(result: InvestigationResult, incident: import("../types/telemetry").Incident, evidence: import("../types/investigation").EvidenceItem[]): AIInvestigationContext {
    return {
      incident,
      summary: result.summary,
      primaryHypothesis: result.primaryHypothesis,
      alternativeHypotheses: result.rootCauseCandidates.filter((c) => c.id !== result.primaryHypothesis?.id),
      timeline: result.timeline,
      causalChain: result.causalGraph,
      evidence,
      confidenceAnalysis: result.primaryHypothesis
        ? {
            confidence: result.primaryHypothesis.confidence,
            confidenceLevel: result.primaryHypothesis.confidenceLevel,
            reasons: result.primaryHypothesis.reasons,
          }
        : null,
    };
  }

  private buildPropagationPath(startServiceId: string | undefined, propagation: import("../types/investigation").PropagationEdge[]): string[] {
    if (!startServiceId) return [];
    const path = [startServiceId];
    let current = startServiceId;
    const visited = new Set([startServiceId]);

    while (true) {
      const next = propagation
        .filter((e) => e.sourceServiceId === current && !visited.has(e.targetServiceId))
        .sort((a, b) => b.confidence - a.confidence)[0];
      if (!next) break;
      path.push(next.targetServiceId);
      visited.add(next.targetServiceId);
      current = next.targetServiceId;
    }

    return path;
  }
}
