import { PROPAGATION_WEIGHTS } from "../config/scoringWeights";
import { TEMPORAL_CORRELATION } from "../config/investigationConfig";
import { clamp } from "../utils/time";

export interface PropagationScoreInput {
  hasDirectDependency: boolean;
  correctTimeOrdering: boolean;
  timeDifferenceSeconds: number;
  hasTraceCorrelation: boolean;
  logicallyConsistent: boolean;
}

export interface PropagationScoreResult {
  confidence: number; // 0-100
  factors: string[];
}

/**
 * PropagationScorer
 *
 * PART 8 — turns the raw propagation signals gathered by
 * FailurePropagationAnalyzer into a single explainable 0-100 confidence
 * score, using the centralized PROPAGATION_WEIGHTS.
 */
export class PropagationScorer {
  score(input: PropagationScoreInput): PropagationScoreResult {
    const factors: string[] = [];
    let total = 0;

    if (input.hasDirectDependency) {
      total += PROPAGATION_WEIGHTS.dependencyRelationship;
      factors.push("Direct dependency relationship between services");
    }

    if (input.correctTimeOrdering) {
      total += PROPAGATION_WEIGHTS.correctTimeOrdering;
      factors.push("Upstream service became abnormal before downstream service");
    }

    if (input.correctTimeOrdering) {
      const d = input.timeDifferenceSeconds;
      let temporalCredit = 0;
      if (d <= TEMPORAL_CORRELATION.veryCloseSeconds) {
        temporalCredit = 1;
        factors.push(`Downstream anomaly occurred within ${TEMPORAL_CORRELATION.veryCloseSeconds}s`);
      } else if (d <= TEMPORAL_CORRELATION.closeSeconds) {
        temporalCredit = 0.7;
        factors.push(`Downstream anomaly occurred within ${TEMPORAL_CORRELATION.closeSeconds}s`);
      } else if (d <= TEMPORAL_CORRELATION.mediumSeconds) {
        temporalCredit = 0.4;
        factors.push(`Downstream anomaly occurred within ${TEMPORAL_CORRELATION.mediumSeconds}s`);
      } else {
        temporalCredit = 0.1;
      }
      total += temporalCredit * PROPAGATION_WEIGHTS.closeTemporalDistance;
    }

    if (input.hasTraceCorrelation) {
      total += PROPAGATION_WEIGHTS.traceCorrelation;
      factors.push("Trace evidence connects both services in the same failed request");
    }

    if (input.logicallyConsistent) {
      total += PROPAGATION_WEIGHTS.logicalFailureConsistency;
      factors.push("Failure type is logically consistent with propagation (e.g. timeout -> retries -> degradation)");
    }

    return { confidence: Math.round(clamp(total, 0, 100)), factors };
  }
}
