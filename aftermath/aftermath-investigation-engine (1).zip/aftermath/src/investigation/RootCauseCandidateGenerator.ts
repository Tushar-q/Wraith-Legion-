import {
  ChangeCandidate,
  FirstFailureResult,
  InvestigationContext,
  RootCauseType,
} from "../types/investigation";
import { nextId } from "../utils/id";

export interface RawRootCauseCandidate {
  id: string;
  type: RootCauseType;
  title: string;
  description: string;
  serviceId?: string;
  timestamp?: string;
  evidenceIds: string[];
}

/**
 * RootCauseCandidateGenerator
 *
 * PART 10 — generates MULTIPLE plausible root cause candidates (not just
 * one) from: suspicious changes, the first-failure service/anomaly itself,
 * and upstream external dependencies. Candidates are scored later by
 * RootCauseScorer; this module's job is only to propose plausible
 * hypotheses with their supporting raw evidence IDs.
 */
export class RootCauseCandidateGenerator {
  generate(
    context: InvestigationContext,
    firstFailure: FirstFailureResult | null,
    suspiciousChanges: ChangeCandidate[]
  ): RawRootCauseCandidate[] {
    const candidates: RawRootCauseCandidate[] = [];

    // 1. Every suspicious change is a candidate (configuration/deploy/restart/infra/dependency changes).
    //    Its evidence includes not just the change event itself, but the corroborating evidence that
    //    followed it on the same service up through the first failure - i.e. the effects that support
    //    treating this change as the causal mechanism, not just an isolated coincidence.
    for (const change of suspiciousChanges) {
      const corroboratingIds = this.corroboratingEvidenceIds(context, change, firstFailure);
      candidates.push({
        id: nextId("candidate"),
        type: this.mapChangeType(change.changeType),
        title: this.titleForChange(change),
        description: `A ${change.changeType.replace(/_/g, " ")} on ${change.serviceId ?? "an unscoped target"} at ${change.timestamp}, ${change.temporalDistanceSeconds}s before the first abnormal behavior.`,
        serviceId: change.serviceId,
        timestamp: change.timestamp,
        evidenceIds: Array.from(new Set([change.eventId, ...corroboratingIds])),
      });
    }

    // 2. The first-failure service itself, as a "service failure" candidate (in case no change explains it -
    //    e.g. the service may have simply failed with no known preceding change, such as an external dependency issue).
    if (firstFailure) {
      candidates.push({
        id: nextId("candidate"),
        type: "service_failure",
        title: `${firstFailure.serviceId} service failure`,
        description: `${firstFailure.serviceId} was the first service to show abnormal behavior, at ${firstFailure.timestamp}. ${firstFailure.explanation}`,
        serviceId: firstFailure.serviceId,
        timestamp: firstFailure.timestamp,
        evidenceIds: firstFailure.evidenceIds,
      });

      // 3. Upstream EXTERNAL dependency failure candidate, if the first-failure service calls an external service
      //    and there's trace evidence reaching it.
      const externalTraceEvidence = context.traces.filter(
        (tr) => tr.status !== "ok" && tr.path.includes(firstFailure.serviceId)
      );
      const externalHop = externalTraceEvidence
        .flatMap((tr) => tr.path)
        .find((serviceId) => {
          const svc = context.services.find((s) => s.id === serviceId);
          return svc?.tier === "external";
        });
      if (externalHop) {
        candidates.push({
          id: nextId("candidate"),
          type: "dependency_failure",
          title: `${externalHop} slowdown or failure`,
          description: `Failed traces from ${firstFailure.serviceId} traveled through the external dependency ${externalHop}, suggesting it may be a contributing or root cause.`,
          serviceId: externalHop,
          timestamp: firstFailure.timestamp,
          evidenceIds: externalTraceEvidence.map((t) => t.id),
        });
      }
    }

    // 4. A generic "unknown external dependency issue" candidate always exists as a low-confidence fallback,
    //    representing the honest possibility that the true cause isn't captured in available telemetry.
    if (firstFailure) {
      candidates.push({
        id: nextId("candidate"),
        type: "unknown",
        title: "Unknown external factor",
        description: "Available evidence may not capture the true originating cause (e.g. an unmonitored external dependency or environmental factor).",
        timestamp: firstFailure.timestamp,
        evidenceIds: [],
      });
    }

    return candidates;
  }

  /**
   * Evidence on the same service, between the change and (a small buffer after) the first
   * failure, that corroborates the change as the causal mechanism behind that failure.
   */
  private corroboratingEvidenceIds(
    context: InvestigationContext,
    change: ChangeCandidate,
    firstFailure: FirstFailureResult | null
  ): string[] {
    if (!change.serviceId || !firstFailure) return [];
    const rangeEnd = firstFailure.timestamp; // evidence up through the first-failure moment
    const ids: string[] = [];

    for (const a of context.anomalies) {
      if (a.serviceId === change.serviceId && a.timestamp >= change.timestamp && a.timestamp <= rangeEnd) ids.push(a.id);
    }
    for (const h of context.healthHistory) {
      if (h.serviceId === change.serviceId && h.status !== "healthy" && h.timestamp >= change.timestamp && h.timestamp <= rangeEnd)
        ids.push(h.id);
    }
    for (const l of context.logs) {
      if (
        l.serviceId === change.serviceId &&
        (l.level === "error" || l.level === "fatal") &&
        l.timestamp >= change.timestamp &&
        l.timestamp <= rangeEnd
      )
        ids.push(l.id);
    }
    return ids;
  }

  private mapChangeType(changeType: string): RootCauseType {
    switch (changeType) {
      case "configuration_changed":
        return "configuration_change";
      case "deployment_started":
      case "deployment_completed":
        return "deployment";
      case "infrastructure_change":
        return "infrastructure_change";
      case "dependency_change":
        return "dependency_failure";
      default:
        return "unknown";
    }
  }

  private titleForChange(change: ChangeCandidate): string {
    switch (change.changeType) {
      case "configuration_changed":
        return `${change.serviceId ?? "Service"} configuration change`;
      case "deployment_started":
      case "deployment_completed":
        return `${change.serviceId ?? "Service"} deployment`;
      case "service_restarted":
        return `${change.serviceId ?? "Service"} restart`;
      case "infrastructure_change":
        return `${change.serviceId ?? "Infrastructure"} change`;
      case "dependency_change":
        return `${change.serviceId ?? "Dependency"} change`;
      default:
        return `${change.serviceId ?? "Service"} change`;
    }
  }
}
