import {
  EvidenceItem,
  FirstFailureResult,
  PropagationEdge,
  RootCauseCandidate,
  RootCauseScoreBreakdown,
} from "../types/investigation";
import { RawRootCauseCandidate } from "./RootCauseCandidateGenerator";
import { DependencyAnalyzer } from "./DependencyAnalyzer";
import { ROOT_CAUSE_WEIGHTS, confidenceLevelFor } from "../config/scoringWeights";
import { TEMPORAL_CORRELATION } from "../config/investigationConfig";
import { diffSeconds, clamp } from "../utils/time";

/**
 * RootCauseScorer
 *
 * PART 11/12 — scores each raw candidate on 7 explainable factors (PART 11)
 * and converts the result into a 0-100 confidence with a human-readable
 * confidence level and reasons (PART 12). All weights come from
 * ROOT_CAUSE_WEIGHTS - nothing is hardcoded here.
 */
export class RootCauseScorer {
  score(
    candidate: RawRootCauseCandidate,
    firstFailure: FirstFailureResult | null,
    propagation: PropagationEdge[],
    allEvidence: EvidenceItem[],
    dependencyAnalyzer: DependencyAnalyzer,
    incidentSeverity: string
  ): RootCauseCandidate {
    const supportingEvidence = allEvidence.filter((e) => candidate.evidenceIds.includes(e.id));

    // 1. TEMPORAL PROXIMITY - how close to the first failure did this candidate occur?
    let temporalProximity = 0;
    let contradictionPenalty = 0;
    const contradictingEvidence: EvidenceItem[] = [];

    if (candidate.timestamp && firstFailure) {
      const distance = diffSeconds(candidate.timestamp, firstFailure.timestamp);
      if (distance < 0) {
        // Candidate happened AFTER the first failure - it cannot be the root cause. Large penalty.
        contradictionPenalty += ROOT_CAUSE_WEIGHTS.contradictionPenalty;
        temporalProximity = 0;
      } else if (distance <= TEMPORAL_CORRELATION.veryCloseSeconds) {
        temporalProximity = 1;
      } else if (distance <= TEMPORAL_CORRELATION.closeSeconds) {
        temporalProximity = 0.7;
      } else if (distance <= TEMPORAL_CORRELATION.mediumSeconds) {
        temporalProximity = 0.4;
      } else {
        temporalProximity = 0.15;
      }
    } else if (!candidate.timestamp) {
      temporalProximity = 0.1; // unknown timing (e.g. "unknown external factor") - weak but nonzero
    }

    // 2. SERVICE CORRELATION - same service as first failure, or an upstream dependency of it?
    let serviceCorrelation = 0;
    if (firstFailure && candidate.serviceId) {
      if (candidate.serviceId === firstFailure.serviceId) {
        serviceCorrelation = 1;
      } else {
        const distance = dependencyAnalyzer.findDependencyDistance(candidate.serviceId, firstFailure.serviceId);
        // candidate.serviceId is upstream of firstFailure.serviceId if firstFailure.serviceId is downstream of it
        if (distance !== null) {
          serviceCorrelation = clamp(0.8 - distance * 0.2, 0.1, 0.8);
        } else {
          serviceCorrelation = 0.1;
        }
      }
    } else if (!candidate.serviceId) {
      serviceCorrelation = 0.15; // unscoped/unknown candidate
    }

    // 3. FIRST FAILURE CORRELATION - is the candidate directly tied to the first-failure evidence?
    let firstFailureCorrelation = 0;
    if (firstFailure) {
      const sharesEvidence = candidate.evidenceIds.some((id) => firstFailure.evidenceIds.includes(id));
      const sameService = candidate.serviceId === firstFailure.serviceId;
      if (sharesEvidence) firstFailureCorrelation = 1;
      else if (sameService) firstFailureCorrelation = 0.8;
      else if (candidate.serviceId) {
        const distance = dependencyAnalyzer.findDependencyDistance(candidate.serviceId, firstFailure.serviceId);
        firstFailureCorrelation = distance !== null ? clamp(0.6 - distance * 0.15, 0.1, 0.6) : 0.1;
      } else {
        firstFailureCorrelation = 0.1;
      }
    }

    // 4. PROPAGATION CONSISTENCY - does the resulting failure chain follow the dependency graph
    //    starting from this candidate's service?
    let propagationConsistency = 0;
    if (candidate.serviceId && propagation.length > 0) {
      const edgesFromCandidate = propagation.filter((e) => e.sourceServiceId === candidate.serviceId);
      const edgesInvolvingCandidateChain = propagation.filter(
        (e) => e.sourceServiceId === candidate.serviceId || e.targetServiceId === candidate.serviceId
      );
      if (edgesFromCandidate.length > 0) {
        const avgConfidence = edgesFromCandidate.reduce((s, e) => s + e.confidence, 0) / edgesFromCandidate.length / 100;
        propagationConsistency = avgConfidence;
      } else if (edgesInvolvingCandidateChain.length > 0) {
        propagationConsistency = 0.4;
      } else {
        propagationConsistency = 0.1;
      }
    } else if (candidate.serviceId === firstFailure?.serviceId) {
      propagationConsistency = 0.5; // first-failure service itself, no outgoing propagation edges found yet
    }

    // 5. EVIDENCE SUPPORT - how many independent evidence sources back this candidate?
    const uniqueSourceTypes = new Set(supportingEvidence.map((e) => e.sourceType));
    const evidenceSupport = clamp(uniqueSourceTypes.size / 4, 0, 1); // 4+ distinct source types = full credit

    // 6. SEVERITY CORRELATION - does the candidate's severity/impact align with the incident's severity?
    const severityCorrelation = incidentSeverity === "critical" || incidentSeverity === "error" ? 0.8 : 0.5;

    // 7. EXPLANATORY DEPTH - does this candidate identify a preceding MECHANISM (a change) rather than
    //    just restating that a service failed? Explanatory candidates are more actionable root causes.
    const explanatoryTypes = new Set(["configuration_change", "deployment", "infrastructure_change", "dependency_failure"]);
    let explanatoryDepth: number;
    if (explanatoryTypes.has(candidate.type)) explanatoryDepth = 1;
    else if (candidate.type === "service_failure") explanatoryDepth = 0.3;
    else explanatoryDepth = 0.1; // "unknown" fallback candidate

    const breakdown: RootCauseScoreBreakdown = {
      temporalProximity: Math.round(temporalProximity * ROOT_CAUSE_WEIGHTS.temporalProximity),
      serviceCorrelation: Math.round(serviceCorrelation * ROOT_CAUSE_WEIGHTS.serviceCorrelation),
      firstFailureCorrelation: Math.round(firstFailureCorrelation * ROOT_CAUSE_WEIGHTS.firstFailureCorrelation),
      propagationConsistency: Math.round(propagationConsistency * ROOT_CAUSE_WEIGHTS.propagationConsistency),
      evidenceSupport: Math.round(evidenceSupport * ROOT_CAUSE_WEIGHTS.evidenceSupport),
      severityCorrelation: Math.round(severityCorrelation * ROOT_CAUSE_WEIGHTS.severityCorrelation),
      explanatoryDepth: Math.round(explanatoryDepth * ROOT_CAUSE_WEIGHTS.explanatoryDepth),
      contradictionPenalty,
      total: 0,
    };

    const rawTotal =
      breakdown.temporalProximity +
      breakdown.serviceCorrelation +
      breakdown.firstFailureCorrelation +
      breakdown.propagationConsistency +
      breakdown.evidenceSupport +
      breakdown.severityCorrelation +
      breakdown.explanatoryDepth +
      breakdown.contradictionPenalty;

    breakdown.total = Math.round(clamp(rawTotal, 0, 100));

    if (contradictionPenalty < 0) {
      contradictingEvidence.push(
        ...supportingEvidence.filter((e) => candidate.timestamp && e.timestamp > (firstFailure?.timestamp ?? ""))
      );
    }

    const confidence = breakdown.total;
    const reasons = this.buildReasons(candidate, firstFailure, breakdown);

    return {
      id: candidate.id,
      type: candidate.type,
      title: candidate.title,
      description: candidate.description,
      serviceId: candidate.serviceId,
      timestamp: candidate.timestamp,
      confidence,
      confidenceLevel: confidenceLevelFor(confidence),
      score: breakdown,
      evidenceIds: candidate.evidenceIds,
      supportingEvidence,
      contradictingEvidence,
      reasons,
    };
  }

  private buildReasons(
    candidate: RawRootCauseCandidate,
    firstFailure: FirstFailureResult | null,
    breakdown: RootCauseScoreBreakdown
  ): string[] {
    const reasons: string[] = [];

    if (firstFailure && candidate.timestamp) {
      const distance = diffSeconds(candidate.timestamp, firstFailure.timestamp);
      if (distance >= 0 && distance <= TEMPORAL_CORRELATION.veryCloseSeconds) {
        reasons.push(`Occurred only ${distance}s before the first abnormal behavior`);
      } else if (distance < 0) {
        reasons.push("Occurred AFTER the first abnormal behavior - contradicts a causal role");
      }
    }

    if (firstFailure && candidate.serviceId === firstFailure.serviceId) {
      reasons.push(`Directly affected ${firstFailure.serviceId}, the first service to show abnormal behavior`);
    }

    if (breakdown.propagationConsistency >= Math.round(ROOT_CAUSE_WEIGHTS.propagationConsistency * 0.6)) {
      reasons.push("Resulting failure chain is consistent with the service dependency graph");
    }

    if (breakdown.evidenceSupport >= Math.round(ROOT_CAUSE_WEIGHTS.evidenceSupport * 0.5)) {
      reasons.push("Supported by multiple independent evidence sources");
    }

    if (breakdown.explanatoryDepth >= Math.round(ROOT_CAUSE_WEIGHTS.explanatoryDepth * 0.8)) {
      reasons.push("Identifies a specific preceding mechanism (a system change), not just the failure itself");
    }

    if (breakdown.contradictionPenalty < 0) {
      reasons.push("Confidence reduced due to contradicting evidence");
    }

    if (reasons.length === 0) {
      reasons.push("Limited supporting evidence available for this candidate");
    }

    return reasons;
  }
}
