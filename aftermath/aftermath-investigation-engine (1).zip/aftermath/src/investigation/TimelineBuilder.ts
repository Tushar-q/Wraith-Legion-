import { InvestigationContext, TimelineEvent } from "../types/investigation";
import { Severity } from "../types/telemetry";
import { sortByTimestampAsc } from "../utils/time";
import { nextId } from "../utils/id";

const LOG_LEVEL_TO_SEVERITY: Record<string, Severity> = {
  debug: "info",
  info: "info",
  warn: "warning",
  error: "error",
  fatal: "critical",
};

/**
 * TimelineBuilder
 *
 * Converts the scattered evidence in an InvestigationContext (events,
 * anomalies, health changes, trace failures, error logs) into a single
 * chronologically sorted TimelineEvent[], with obvious duplicates removed
 * and links back to source evidence preserved.
 */
export class TimelineBuilder {
  build(context: InvestigationContext): TimelineEvent[] {
    const events: TimelineEvent[] = [];

    for (const e of context.events) {
      const isUserImpact = e.metadata?.kind === "user_impact";
      events.push({
        id: nextId("timeline"),
        timestamp: e.timestamp,
        type: isUserImpact ? "user_impact" : "system_event",
        serviceId: e.serviceId,
        severity: isUserImpact ? "critical" : e.type === "configuration_changed" ? "warning" : "info",
        title: this.titleForEvent(e.type, isUserImpact),
        description: e.description,
        evidenceIds: [e.id],
      });
    }

    for (const a of context.anomalies) {
      events.push({
        id: nextId("timeline"),
        timestamp: a.timestamp,
        type: "anomaly",
        serviceId: a.serviceId,
        severity: a.severity,
        title: `Anomaly: ${a.type.replace(/_/g, " ")}`,
        description: a.description,
        evidenceIds: [a.id],
      });
    }

    for (const h of context.healthHistory) {
      if (h.status === "healthy") continue; // only surface degradations, not steady-state health pings
      events.push({
        id: nextId("timeline"),
        timestamp: h.timestamp,
        type: "health_change",
        serviceId: h.serviceId,
        severity: h.status === "unhealthy" ? "error" : "warning",
        title: `Health ${h.status}`,
        description: `${h.serviceId} health score dropped to ${h.healthScore} (error rate ${(h.errorRate * 100).toFixed(0)}%, latency ${h.latencyMs}ms).`,
        evidenceIds: [h.id],
      });
    }

    for (const tr of context.traces) {
      if (tr.status === "ok") continue;
      events.push({
        id: nextId("timeline"),
        timestamp: tr.timestamp,
        type: "trace_failure",
        serviceId: tr.path[tr.path.length - 1] ?? tr.serviceId,
        severity: tr.status === "timeout" ? "critical" : "error",
        title: `Trace ${tr.status}`,
        description: `Request through [${tr.path.join(" -> ")}] resulted in ${tr.status} after ${tr.durationMs}ms.`,
        evidenceIds: [tr.id],
      });
    }

    for (const l of context.logs) {
      if (l.level === "debug" || l.level === "info") continue; // noise reduction: only surface warn+ logs
      events.push({
        id: nextId("timeline"),
        timestamp: l.timestamp,
        type: "metric_change",
        serviceId: l.serviceId,
        severity: LOG_LEVEL_TO_SEVERITY[l.level] ?? "info",
        title: `Log: ${l.level}`,
        description: l.message,
        evidenceIds: [l.id],
      });
    }

    return this.deduplicate(sortByTimestampAsc(events));
  }

  private titleForEvent(type: string, isUserImpact: boolean): string {
    if (isUserImpact) return "User impact detected";
    switch (type) {
      case "configuration_changed":
        return "Configuration changed";
      case "deployment_started":
        return "Deployment started";
      case "deployment_completed":
        return "Deployment completed";
      case "service_restarted":
        return "Service restarted";
      case "infrastructure_change":
        return "Infrastructure changed";
      case "dependency_change":
        return "Dependency changed";
      default:
        return "System event";
    }
  }

  /** Remove near-duplicate entries: same service, same type, same timestamp, same title. */
  private deduplicate(events: TimelineEvent[]): TimelineEvent[] {
    const seen = new Set<string>();
    const result: TimelineEvent[] = [];
    for (const e of events) {
      const key = `${e.timestamp}|${e.type}|${e.serviceId ?? ""}|${e.title}|${e.description}`;
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(e);
    }
    return result;
  }
}
