/**
 * =============================================================================
 * PROVIDER INTERFACES
 * =============================================================================
 *
 * The investigation engine NEVER talks to a data source directly. It only
 * talks to these three interfaces. Today they are implemented by
 * `providers/mock/*`, which serves deterministic seeded demo data
 * (including the INC-042 scenario).
 *
 * INTEGRATING MEMBER 1's REAL SYSTEM:
 *   Implement these same three interfaces against Member 1's real telemetry
 *   store (DB, in-memory store, HTTP client, whatever it is) and pass the
 *   new instances into `InvestigationEngine` / `IncidentContextCollector`
 *   instead of the mock ones. See src/index.ts for where they're wired up -
 *   that is the ONLY place that needs to change.
 *
 *   If Member 1's real data shapes differ from `types/telemetry.ts`, write a
 *   thin mapping inside the new provider implementation (translate their
 *   shape -> ours). Do not change the investigation modules themselves.
 * =============================================================================
 */

import {
  Anomaly,
  Incident,
  Log,
  Metric,
  Service,
  ServiceDependency,
  ServiceHealth,
  SystemEvent,
  Trace,
} from "../types/telemetry";

/** Provides incidents and the services they touch. */
export interface IncidentDataProvider {
  getIncident(incidentId: string): Promise<Incident | null>;
  listIncidents(): Promise<Incident[]>;
  getServicesByIds(serviceIds: string[]): Promise<Service[]>;
}

/**
 * Provides raw observability data for a set of services within a time
 * window. All timestamps are ISO-8601 strings; `start`/`end` are inclusive.
 */
export interface TelemetryProvider {
  getAnomalies(serviceIds: string[], start: string, end: string): Promise<Anomaly[]>;
  getLogs(serviceIds: string[], start: string, end: string): Promise<Log[]>;
  getMetrics(serviceIds: string[], start: string, end: string): Promise<Metric[]>;
  /** System events (config changes, deploys, restarts...). serviceIds=undefined means "global" events too. */
  getEvents(serviceIds: string[] | undefined, start: string, end: string): Promise<SystemEvent[]>;
  getTraces(serviceIds: string[], start: string, end: string): Promise<Trace[]>;
  getHealthHistory(serviceIds: string[], start: string, end: string): Promise<ServiceHealth[]>;
}

/** Provides the static service dependency graph. */
export interface DependencyProvider {
  getAllServices(): Promise<Service[]>;
  getDependencies(): Promise<ServiceDependency[]>;
}
