import { IncidentDataProvider, TelemetryProvider, DependencyProvider } from "../interfaces";
import { Anomaly, Incident, Log, Metric, Service, ServiceDependency, ServiceHealth, SystemEvent, Trace } from "../../types/telemetry";
import * as data from "./mockData";

function inWindow(timestamp: string, start: string, end: string): boolean {
  return timestamp >= start && timestamp <= end;
}

function byService<T extends { serviceId?: string }>(items: T[], serviceIds: string[] | undefined): T[] {
  if (!serviceIds || serviceIds.length === 0) return items;
  const set = new Set(serviceIds);
  return items.filter((i) => (i.serviceId ? set.has(i.serviceId) : true));
}

/**
 * MockIncidentDataProvider
 * Serves seeded demo incidents (currently just INC-042). This is the
 * reference implementation of IncidentDataProvider - swap for a real one
 * backed by Member 1's incident store when it's ready.
 */
export class MockIncidentDataProvider implements IncidentDataProvider {
  async getIncident(incidentId: string): Promise<Incident | null> {
    return data.allIncidents.find((i) => i.id === incidentId) ?? null;
  }

  async listIncidents(): Promise<Incident[]> {
    return data.allIncidents;
  }

  async getServicesByIds(serviceIds: string[]): Promise<Service[]> {
    const set = new Set(serviceIds);
    return data.services.filter((s) => set.has(s.id));
  }
}

/**
 * MockTelemetryProvider
 * Serves seeded demo telemetry (anomalies, logs, metrics, events, traces,
 * health) filtered to a service set and time window. Reference
 * implementation of TelemetryProvider.
 */
export class MockTelemetryProvider implements TelemetryProvider {
  async getAnomalies(serviceIds: string[], start: string, end: string): Promise<Anomaly[]> {
    return byService(data.anomalies042, serviceIds).filter((a) => inWindow(a.timestamp, start, end));
  }

  async getLogs(serviceIds: string[], start: string, end: string): Promise<Log[]> {
    return byService(data.logs042, serviceIds).filter((l) => inWindow(l.timestamp, start, end));
  }

  async getMetrics(serviceIds: string[], start: string, end: string): Promise<Metric[]> {
    return byService(data.metrics042, serviceIds).filter((m) => inWindow(m.timestamp, start, end));
  }

  async getEvents(serviceIds: string[] | undefined, start: string, end: string): Promise<SystemEvent[]> {
    return byService(data.allEvents042, serviceIds).filter((e) => inWindow(e.timestamp, start, end));
  }

  async getTraces(serviceIds: string[], start: string, end: string): Promise<Trace[]> {
    const set = new Set(serviceIds);
    return data.traces042.filter(
      (tr) => inWindow(tr.timestamp, start, end) && tr.path.some((s) => set.has(s))
    );
  }

  async getHealthHistory(serviceIds: string[], start: string, end: string): Promise<ServiceHealth[]> {
    return byService(data.healthHistory042, serviceIds).filter((h) => inWindow(h.timestamp, start, end));
  }
}

/**
 * MockDependencyProvider
 * Serves the seeded static service dependency graph. Reference
 * implementation of DependencyProvider.
 */
export class MockDependencyProvider implements DependencyProvider {
  async getAllServices(): Promise<Service[]> {
    return data.services;
  }

  async getDependencies(): Promise<ServiceDependency[]> {
    return data.dependencies;
  }
}
