/**
 * =============================================================================
 * MOCK / DEMO DATA — INC-042 "Payment Failure Propagation"
 * =============================================================================
 *
 * This is the deterministic seeded scenario used to demo (and test) the
 * investigation engine while Member 1's real telemetry system does not
 * exist yet. It intentionally encodes the exact timeline described in the
 * project brief so the engine's OUTPUT can be verified against a known
 * ground truth. The investigation engine itself contains no knowledge of
 * "INC-042" - it derives all conclusions from this evidence.
 * =============================================================================
 */

import {
  Anomaly,
  Incident,
  Log,
  Metric,
  Service,
  ServiceDependency,
  ServiceHealth,
  SystemEvent,
  Trace,
} from "../../types/telemetry";

// Base day for the scenario. Keep this fixed so the mock data is fully deterministic.
const DAY = "2026-08-29";
const t = (hhmmss: string) => `${DAY}T${hhmmss}Z`;

// ---------------------------------------------------------------------------
// SERVICES
// ---------------------------------------------------------------------------

export const services: Service[] = [
  { id: "api-gateway", name: "API Gateway", description: "Public edge entrypoint", tier: "edge" },
  { id: "order-service", name: "Order Service", description: "Manages orders and checkout", tier: "internal" },
  { id: "payment-service", name: "Payment Service", description: "Processes payments", tier: "internal" },
  { id: "external-payment-gateway", name: "External Payment Gateway", description: "3rd-party payment processor", tier: "external" },
  { id: "inventory-service", name: "Inventory Service", description: "Tracks stock levels", tier: "internal" },
];

// ---------------------------------------------------------------------------
// DEPENDENCIES
// Semantics: { serviceId, dependsOnServiceId } => serviceId calls dependsOnServiceId.
// api-gateway -> order-service -> payment-service -> external-payment-gateway
// order-service -> inventory-service (unrelated branch, used for "no false correlation" tests)
// ---------------------------------------------------------------------------

export const dependencies: ServiceDependency[] = [
  { serviceId: "api-gateway", dependsOnServiceId: "order-service", protocol: "http" },
  { serviceId: "order-service", dependsOnServiceId: "payment-service", protocol: "http" },
  { serviceId: "order-service", dependsOnServiceId: "inventory-service", protocol: "http" },
  { serviceId: "payment-service", dependsOnServiceId: "external-payment-gateway", protocol: "http" },
];

// ---------------------------------------------------------------------------
// INCIDENT
// ---------------------------------------------------------------------------

export const incident042: Incident = {
  id: "INC-042",
  title: "Payment Failure Propagation",
  description:
    "Widespread checkout and payment failures beginning in Payment Service and propagating through Order Service and API Gateway.",
  status: "investigating",
  severity: "critical",
  detectedAt: t("09:00:40"),
  affectedServiceIds: ["payment-service", "order-service", "api-gateway"],
};

// ---------------------------------------------------------------------------
// SYSTEM EVENTS
// ---------------------------------------------------------------------------

export const systemEvents042: SystemEvent[] = [
  {
    id: "event-config-001",
    serviceId: "payment-service",
    timestamp: t("09:00:05"),
    type: "configuration_changed",
    description: "Payment Service timeout configuration changed from 5000ms to 500ms.",
    metadata: { field: "payment.timeoutMs", oldValue: 5000, newValue: 500 },
  },
  {
    id: "event-detect-001",
    serviceId: undefined,
    timestamp: t("09:00:40"),
    type: "other",
    description: "Incident INC-042 auto-detected by Member 1 telemetry system.",
    metadata: { incidentId: "INC-042" },
  },
];

// ---------------------------------------------------------------------------
// ANOMALIES
// ---------------------------------------------------------------------------

export const anomalies042: Anomaly[] = [
  {
    id: "anomaly-payment-latency",
    serviceId: "payment-service",
    timestamp: t("09:00:10"),
    type: "latency_spike",
    metric: "p95_latency_ms",
    baselineValue: 120,
    observedValue: 1500,
    severity: "warning",
    description: "Payment Service p95 latency rose from 120ms baseline to 1500ms.",
  },
  {
    id: "anomaly-payment-timeout",
    serviceId: "payment-service",
    timestamp: t("09:00:15"),
    type: "timeout_spike",
    metric: "timeout_rate",
    baselineValue: 0.001,
    observedValue: 0.62,
    severity: "critical",
    description: "Payment Service timeout rate spiked to 62% of requests.",
  },
  {
    id: "anomaly-order-retry",
    serviceId: "order-service",
    timestamp: t("09:00:20"),
    type: "error_rate_spike",
    metric: "retry_rate",
    baselineValue: 0.01,
    observedValue: 0.55,
    severity: "warning",
    description: "Order Service retry rate against Payment Service spiked significantly.",
  },
  {
    id: "anomaly-order-degradation",
    serviceId: "order-service",
    timestamp: t("09:00:25"),
    type: "health_degradation",
    metric: "health_score",
    baselineValue: 98,
    observedValue: 41,
    severity: "error",
    description: "Order Service health score dropped from 98 to 41.",
  },
  {
    id: "anomaly-gateway-5xx",
    serviceId: "api-gateway",
    timestamp: t("09:00:30"),
    type: "error_rate_spike",
    metric: "5xx_rate",
    baselineValue: 0.001,
    observedValue: 0.48,
    severity: "critical",
    description: "API Gateway 5xx error rate spiked to 48%.",
  },
];

// ---------------------------------------------------------------------------
// METRICS (a sparser sample sufficient to support the anomalies above)
// ---------------------------------------------------------------------------

export const metrics042: Metric[] = [
  { id: "metric-001", serviceId: "payment-service", timestamp: t("09:00:00"), name: "p95_latency_ms", value: 120 },
  { id: "metric-002", serviceId: "payment-service", timestamp: t("09:00:10"), name: "p95_latency_ms", value: 1500 },
  { id: "metric-003", serviceId: "payment-service", timestamp: t("09:00:12"), name: "p95_latency_ms", value: 3000 },
  { id: "metric-004", serviceId: "payment-service", timestamp: t("09:00:15"), name: "p95_latency_ms", value: 4500 },
  { id: "metric-005", serviceId: "order-service", timestamp: t("09:00:20"), name: "retry_count", value: 340 },
  { id: "metric-006", serviceId: "order-service", timestamp: t("09:00:25"), name: "health_score", value: 41 },
  { id: "metric-007", serviceId: "api-gateway", timestamp: t("09:00:30"), name: "latency_ms", value: 2200 },
];

// ---------------------------------------------------------------------------
// LOGS
// ---------------------------------------------------------------------------

export const logs042: Log[] = [
  {
    id: "log-001",
    serviceId: "payment-service",
    timestamp: t("09:00:05"),
    level: "info",
    message: "Configuration reload: payment.timeoutMs 5000 -> 500",
  },
  {
    id: "log-002",
    serviceId: "payment-service",
    timestamp: t("09:00:15"),
    level: "error",
    message: "Timeout calling external-payment-gateway after 500ms",
  },
  {
    id: "log-003",
    serviceId: "order-service",
    timestamp: t("09:00:20"),
    level: "warn",
    message: "Retrying payment-service request (attempt 3/3)",
  },
  {
    id: "log-004",
    serviceId: "order-service",
    timestamp: t("09:00:25"),
    level: "error",
    message: "Order creation failed: downstream payment-service unavailable",
  },
  {
    id: "log-005",
    serviceId: "api-gateway",
    timestamp: t("09:00:30"),
    level: "error",
    message: "Upstream order-service returned 503",
  },
  {
    id: "log-006",
    serviceId: "api-gateway",
    timestamp: t("09:00:35"),
    level: "fatal",
    message: "Checkout endpoint failing for majority of users",
  },
];

// ---------------------------------------------------------------------------
// TRACES
// ---------------------------------------------------------------------------

export const traces042: Trace[] = [
  {
    id: "trace-001",
    timestamp: t("09:00:16"),
    serviceId: "api-gateway",
    durationMs: 5000,
    status: "timeout",
    path: ["api-gateway", "order-service", "payment-service", "external-payment-gateway"],
    spans: [
      { serviceId: "api-gateway", durationMs: 5000, status: "error" },
      { serviceId: "order-service", durationMs: 4800, status: "error" },
      { serviceId: "payment-service", durationMs: 4500, status: "timeout" },
      { serviceId: "external-payment-gateway", durationMs: 500, status: "timeout" },
    ],
  },
  {
    id: "trace-002",
    timestamp: t("09:00:22"),
    serviceId: "api-gateway",
    durationMs: 4200,
    status: "error",
    path: ["api-gateway", "order-service", "payment-service"],
    spans: [
      { serviceId: "api-gateway", durationMs: 4200, status: "error" },
      { serviceId: "order-service", durationMs: 4000, status: "error" },
      { serviceId: "payment-service", durationMs: 3800, status: "timeout" },
    ],
  },
  {
    id: "trace-003",
    timestamp: t("09:00:32"),
    serviceId: "api-gateway",
    durationMs: 2200,
    status: "error",
    path: ["api-gateway", "order-service"],
    spans: [
      { serviceId: "api-gateway", durationMs: 2200, status: "error" },
      { serviceId: "order-service", durationMs: 2100, status: "error" },
    ],
  },
];

// ---------------------------------------------------------------------------
// HEALTH HISTORY
// ---------------------------------------------------------------------------

export const healthHistory042: ServiceHealth[] = [
  { id: "health-001", serviceId: "payment-service", timestamp: t("09:00:00"), healthScore: 99, errorRate: 0.001, latencyMs: 120, status: "healthy" },
  { id: "health-002", serviceId: "payment-service", timestamp: t("09:00:10"), healthScore: 80, errorRate: 0.02, latencyMs: 1500, status: "degraded" },
  { id: "health-003", serviceId: "payment-service", timestamp: t("09:00:15"), healthScore: 35, errorRate: 0.62, latencyMs: 4500, status: "unhealthy" },
  { id: "health-004", serviceId: "order-service", timestamp: t("09:00:00"), healthScore: 98, errorRate: 0.002, latencyMs: 90, status: "healthy" },
  { id: "health-005", serviceId: "order-service", timestamp: t("09:00:20"), healthScore: 70, errorRate: 0.1, latencyMs: 900, status: "degraded" },
  { id: "health-006", serviceId: "order-service", timestamp: t("09:00:25"), healthScore: 41, errorRate: 0.55, latencyMs: 2100, status: "unhealthy" },
  { id: "health-007", serviceId: "api-gateway", timestamp: t("09:00:00"), healthScore: 99, errorRate: 0.001, latencyMs: 60, status: "healthy" },
  { id: "health-008", serviceId: "api-gateway", timestamp: t("09:00:30"), healthScore: 52, errorRate: 0.48, latencyMs: 2200, status: "unhealthy" },
  { id: "health-009", serviceId: "api-gateway", timestamp: t("09:00:35"), healthScore: 30, errorRate: 0.65, latencyMs: 2600, status: "unhealthy" },
];

// ---------------------------------------------------------------------------
// USER IMPACT (modeled as a critical system event so it appears on the
// timeline / causal graph as a distinct "impact" node)
// ---------------------------------------------------------------------------

export const userImpactEvent042: SystemEvent = {
  id: "event-user-impact-001",
  serviceId: "api-gateway",
  timestamp: t("09:00:35"),
  type: "other",
  description: "Users began experiencing failed checkouts and failed payments.",
  metadata: { kind: "user_impact", failedCheckoutRate: 0.61 },
};

export const allEvents042: SystemEvent[] = [...systemEvents042, userImpactEvent042];

export const allIncidents: Incident[] = [incident042];
