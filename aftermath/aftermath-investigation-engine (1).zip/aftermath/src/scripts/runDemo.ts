import { InvestigationEngine } from "../investigation/InvestigationEngine";
import { MockIncidentDataProvider, MockTelemetryProvider, MockDependencyProvider } from "../providers/mock/MockProviders";

async function main() {
  const engine = new InvestigationEngine(
    new MockIncidentDataProvider(),
    new MockTelemetryProvider(),
    new MockDependencyProvider()
  );

  const result = await engine.run("INC-042");

  console.log("\n================ AFTERMATH INVESTIGATION REPORT ================\n");
  console.log(`Incident: ${result.incidentId}   Status: ${result.status}   Investigation: ${result.investigationId}\n`);

  console.log("--- TIMELINE ---");
  for (const e of result.timeline) {
    console.log(`${e.timestamp}  [${e.severity.padEnd(8)}] ${e.serviceId ?? "-"}: ${e.title} - ${e.description}`);
  }

  console.log("\n--- FIRST FAILURE ---");
  if (result.firstFailure) {
    console.log(`${result.firstFailure.serviceId} @ ${result.firstFailure.timestamp} (confidence ${result.firstFailure.confidence}%)`);
    console.log(result.firstFailure.explanation);
  } else {
    console.log("Could not determine first failure.");
  }

  console.log("\n--- SUSPICIOUS CHANGES ---");
  for (const c of result.suspiciousChanges) {
    console.log(`${c.timestamp}  ${c.changeType} on ${c.serviceId ?? "-"}  suspicion=${c.suspicionScore}  (${c.temporalDistanceSeconds}s before first failure)`);
  }

  console.log("\n--- PROPAGATION ---");
  for (const p of result.propagation) {
    console.log(`${p.sourceServiceId} -> ${p.targetServiceId}   confidence=${p.confidence}%   Δt=${p.timeDifferenceSeconds}s`);
    console.log(`   ${p.explanation}`);
  }
  console.log(`   Propagation path: ${result.summary.propagationPath.join(" -> ")}`);

  console.log("\n--- CAUSE / SYMPTOM CLASSIFICATION ---");
  for (const c of result.classifiedEvents) {
    const evt = result.timeline.find((t) => t.id === c.eventId);
    console.log(`[${c.classification}] ${evt?.title ?? c.eventId} (${evt?.serviceId ?? "-"}) confidence=${c.confidence}%`);
  }

  console.log("\n--- ROOT CAUSE CANDIDATES (ranked) ---");
  for (const rc of result.rootCauseCandidates) {
    console.log(`\n#${rc.confidence}%  [${rc.confidenceLevel}]  ${rc.title}  (${rc.type})`);
    console.log(`   ${rc.description}`);
    console.log(`   Score breakdown: ${JSON.stringify(rc.score)}`);
    console.log(`   Reasons: ${rc.reasons.join("; ")}`);
  }

  console.log("\n--- PRIMARY HYPOTHESIS ---");
  if (result.primaryHypothesis) {
    console.log(`${result.primaryHypothesis.title} — confidence ${result.primaryHypothesis.confidence}% (${result.primaryHypothesis.confidenceLevel})`);
  }

  console.log("\n--- CAUSAL GRAPH ---");
  console.log(`Nodes: ${result.causalGraph.nodes.length}, Edges: ${result.causalGraph.edges.length}`);
  for (const edge of result.causalGraph.edges) {
    const s = result.causalGraph.nodes.find((n) => n.id === edge.sourceId);
    const t = result.causalGraph.nodes.find((n) => n.id === edge.targetId);
    console.log(`   [${s?.title}] --${edge.relationship}(${edge.confidence}%)--> [${t?.title}]`);
  }

  console.log("\n--- EVIDENCE CLUSTERS ---");
  for (const cluster of result.evidenceClusters) {
    console.log(`${cluster.theme}: ${cluster.evidenceIds.length} items, confidence=${cluster.confidence}% (${cluster.startTime} - ${cluster.endTime})`);
  }

  console.log("\n--- SUMMARY ---");
  console.log(JSON.stringify(result.summary, null, 2));

  console.log("\n==================================================================\n");
}

main().catch((err) => {
  console.error("Demo failed:", err);
  process.exit(1);
});
