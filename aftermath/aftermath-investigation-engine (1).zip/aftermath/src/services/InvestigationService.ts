import { InvestigationEngine } from "../investigation/InvestigationEngine";
import { EvidenceWindowOptions } from "../investigation/IncidentContextCollector";
import { AIInvestigationContext, EvidenceItem, InvestigationResult } from "../types/investigation";
import { Incident } from "../types/telemetry";

interface StoredInvestigation {
  result: InvestigationResult;
  evidence: EvidenceItem[];
  incident: Incident | null;
}

/**
 * InvestigationService
 *
 * Thin service layer on top of InvestigationEngine: runs investigations,
 * stores results in memory (fine for a 48h hackathon demo - swap for a
 * real datastore later without touching the engine), and answers the
 * lookups the REST API needs (by investigation id, by incident id,
 * filtered evidence, etc).
 */
export class InvestigationService {
  private readonly byInvestigationId = new Map<string, StoredInvestigation>();
  private readonly latestInvestigationIdByIncidentId = new Map<string, string>();

  constructor(private readonly engine: InvestigationEngine) {}

  async runInvestigation(incidentId: string, options: EvidenceWindowOptions = {}): Promise<InvestigationResult> {
    const { result, evidence, incident } = await this.engine.runWithDetails(incidentId, options);
    this.byInvestigationId.set(result.investigationId, { result, evidence, incident });
    this.latestInvestigationIdByIncidentId.set(incidentId, result.investigationId);
    return result;
  }

  listInvestigations(): InvestigationResult[] {
    return Array.from(this.byInvestigationId.values())
      .map((s) => s.result)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  getInvestigation(investigationId: string): InvestigationResult | null {
    return this.byInvestigationId.get(investigationId)?.result ?? null;
  }

  getLatestForIncident(incidentId: string): InvestigationResult | null {
    const id = this.latestInvestigationIdByIncidentId.get(incidentId);
    if (!id) return null;
    return this.getInvestigation(id);
  }

  getEvidence(
    investigationId: string,
    filters: { serviceId?: string; sourceType?: string; minRelevance?: number } = {}
  ): EvidenceItem[] | null {
    const stored = this.byInvestigationId.get(investigationId);
    if (!stored) return null;
    return stored.evidence.filter((e) => {
      if (filters.serviceId && e.serviceId !== filters.serviceId) return false;
      if (filters.sourceType && e.sourceType !== filters.sourceType) return false;
      if (filters.minRelevance !== undefined && e.relevanceScore < filters.minRelevance) return false;
      return true;
    });
  }

  getAIContext(investigationId: string): AIInvestigationContext | null {
    const stored = this.byInvestigationId.get(investigationId);
    if (!stored || !stored.incident) return null;
    return this.engine.buildAIContext(stored.result, stored.incident, stored.evidence);
  }
}
