import {
  Anomaly,
  Incident,
  Log,
  Metric,
  Service,
  ServiceDependency,
  ServiceHealth,
  Severity,
  SystemEvent,
  Trace,
} from "./telemetry";

/** Everything gathered about one incident, before any analysis happens. */
export interface InvestigationContext {
  incident: Incident;
  services: Service[];
  dependencies: ServiceDependency[];
  anomalies: Anomaly[];
  logs: Log[];
  metrics: Metric[];
  events: SystemEvent[];
  traces: Trace[];
  healthHistory: ServiceHealth[];
  /** The evidence window actually used to collect the data above. */
  window: {
    start: string;
    end: string;
    lookbackSeconds: number;
    lookforwardSeconds: number;
  };
}

// ---------------------------------------------------------------------------
// TIMELINE
// ---------------------------------------------------------------------------

export type TimelineEventType =
  | "system_event"
  | "anomaly"
  | "health_change"
  | "trace_failure"
  | "user_impact"
  | "metric_change";

export interface TimelineEvent {
  id: string;
  timestamp: string;
  type: TimelineEventType;
  serviceId?: string;
  severity: Severity;
  title: string;
  description: string;
  evidenceIds: string[];
}

// ---------------------------------------------------------------------------
// FIRST FAILURE
// ---------------------------------------------------------------------------

export interface FirstFailureResult {
  serviceId: string;
  timestamp: string;
  anomalyId?: string;
  evidenceIds: string[];
  confidence: number; // 0-100
  explanation: string;
}

// ---------------------------------------------------------------------------
// SUSPICIOUS CHANGES
// ---------------------------------------------------------------------------

export interface ChangeCandidate {
  eventId: string;
  serviceId?: string;
  timestamp: string;
  changeType: string;
  temporalDistanceSeconds: number;
  serviceCorrelation: number; // 0-1
  suspicionScore: number; // 0-100
  explanation: string;
}

// ---------------------------------------------------------------------------
// PROPAGATION
// ---------------------------------------------------------------------------

export interface PropagationEdge {
  sourceServiceId: string;
  targetServiceId: string;
  sourceEventId?: string;
  targetEventId?: string;
  timeDifferenceSeconds: number;
  dependencyDistance: number;
  confidence: number; // 0-100
  explanation: string;
  evidenceIds: string[];
  factors: string[];
}

// ---------------------------------------------------------------------------
// EVIDENCE
// ---------------------------------------------------------------------------

export type EvidenceSourceType = "metric" | "log" | "event" | "trace" | "anomaly" | "health";

export interface EvidenceItem {
  id: string;
  sourceType: EvidenceSourceType;
  sourceId: string;
  timestamp: string;
  serviceId?: string;
  title: string;
  description: string;
  relevanceScore: number; // 0-100
}

export interface EvidenceCluster {
  id: string;
  serviceId?: string;
  startTime: string;
  endTime: string;
  theme: string;
  evidenceIds: string[];
  confidence: number; // 0-100
}

// ---------------------------------------------------------------------------
// CAUSE / SYMPTOM CLASSIFICATION
// ---------------------------------------------------------------------------

export type EventClassification =
  | "potential_cause"
  | "intermediate_failure"
  | "downstream_symptom"
  | "user_impact";

export interface ClassifiedEvent {
  eventId: string;
  classification: EventClassification;
  confidence: number; // 0-100
  explanation: string;
}

// ---------------------------------------------------------------------------
// ROOT CAUSE CANDIDATES
// ---------------------------------------------------------------------------

export type RootCauseType =
  | "configuration_change"
  | "deployment"
  | "dependency_failure"
  | "service_failure"
  | "infrastructure_change"
  | "unknown";

export interface RootCauseScoreBreakdown {
  temporalProximity: number;
  serviceCorrelation: number;
  firstFailureCorrelation: number;
  propagationConsistency: number;
  evidenceSupport: number;
  severityCorrelation: number;
  explanatoryDepth: number;
  contradictionPenalty: number;
  total: number; // 0-100 (clamped)
}

export interface RootCauseCandidate {
  id: string;
  type: RootCauseType;
  title: string;
  description: string;
  serviceId?: string;
  timestamp?: string;
  confidence: number; // 0-100
  confidenceLevel: "very_high" | "high" | "moderate" | "low" | "weak";
  score: RootCauseScoreBreakdown;
  evidenceIds: string[];
  supportingEvidence: EvidenceItem[];
  contradictingEvidence: EvidenceItem[];
  reasons: string[];
}

// ---------------------------------------------------------------------------
// CAUSAL GRAPH
// ---------------------------------------------------------------------------

export type CausalNodeType = "change" | "anomaly" | "failure" | "health" | "impact";

export interface CausalNode {
  id: string;
  type: CausalNodeType;
  timestamp: string;
  serviceId?: string;
  title: string;
  description: string;
  severity?: Severity;
  evidenceIds: string[];
}

export type CausalRelationship =
  | "preceded"
  | "correlated_with"
  | "likely_contributed_to"
  | "likely_caused"
  | "propagated_to";

export interface CausalEdge {
  id: string;
  sourceId: string;
  targetId: string;
  relationship: CausalRelationship;
  confidence: number; // 0-100
  explanation: string;
}

export interface CausalGraph {
  nodes: CausalNode[];
  edges: CausalEdge[];
}

// ---------------------------------------------------------------------------
// FINAL RESULT
// ---------------------------------------------------------------------------

export interface InvestigationSummary {
  affectedServices: string[];
  firstAffectedService?: string;
  estimatedStartTime?: string;
  propagationPath: string[];
  totalEvidenceItems: number;
  confidence: number; // 0-100, overall confidence in primaryHypothesis
}

export type InvestigationStatus = "completed" | "partial" | "failed";

export interface InvestigationResult {
  investigationId: string;
  incidentId: string;
  status: InvestigationStatus;
  timeline: TimelineEvent[];
  firstFailure: FirstFailureResult | null;
  suspiciousChanges: ChangeCandidate[];
  propagation: PropagationEdge[];
  causalGraph: CausalGraph;
  evidenceClusters: EvidenceCluster[];
  rootCauseCandidates: RootCauseCandidate[];
  primaryHypothesis: RootCauseCandidate | null;
  classifiedEvents: ClassifiedEvent[];
  summary: InvestigationSummary;
  createdAt: string;
  error?: string;
}

/** Clean, structured context handed off to Member 3 (AI reasoning layer). */
export interface AIInvestigationContext {
  incident: Incident;
  summary: InvestigationSummary;
  primaryHypothesis: RootCauseCandidate | null;
  alternativeHypotheses: RootCauseCandidate[];
  timeline: TimelineEvent[];
  causalChain: CausalGraph;
  evidence: EvidenceItem[];
  confidenceAnalysis: {
    confidence: number;
    confidenceLevel: string;
    reasons: string[];
  } | null;
}
