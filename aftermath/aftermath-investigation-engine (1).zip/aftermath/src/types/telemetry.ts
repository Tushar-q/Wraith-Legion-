/**
 * =============================================================================
 * TELEMETRY / INCIDENT DATA CONTRACTS
 * =============================================================================
 *
 * These are the data contracts that MEMBER 1 (Telemetry & Incident Detection)
 * is expected to produce. Since Member 1's real implementation is not yet
 * available, these types define a stable "seam" between the two systems.
 *
 * The investigation engine (Member 2) NEVER depends on how this data was
 * produced. It only depends on these shapes, delivered through the provider
 * interfaces in `src/providers/interfaces.ts`.
 *
 * When Member 1's real system is ready, someone only needs to write new
 * implementations of IncidentDataProvider / TelemetryProvider /
 * DependencyProvider that return data in these shapes (or map their real
 * shapes into these ones in a thin adapter). No investigation logic changes.
 * =============================================================================
 */

export type Severity = "info" | "warning" | "error" | "critical";

export type IncidentStatus = "open" | "investigating" | "mitigated" | "resolved";

export interface Incident {
  id: string;
  title: string;
  description: string;
  status: IncidentStatus;
  severity: Severity;
  detectedAt: string; // ISO timestamp
  resolvedAt?: string;
  affectedServiceIds: string[];
  /** Optional hint from Member 1's detector; the investigation engine treats this as a lead, never as ground truth. */
  suspectedPrimaryServiceId?: string;
}

export interface Service {
  id: string;
  name: string;
  description?: string;
  tier?: "edge" | "internal" | "external";
}

/**
 * A dependency edge.
 *
 * Semantics (IMPORTANT - documented once, used consistently everywhere):
 *   { serviceId: "order-service", dependsOnServiceId: "payment-service" }
 *   means "order-service calls / depends on payment-service to do its job".
 *
 * Consequences:
 *   - "payment-service" is UPSTREAM of "order-service" (closer to the root of a request chain).
 *   - "order-service" is DOWNSTREAM of "payment-service" (it is affected when payment-service fails).
 *   - Failure PROPAGATES from a dependency (callee) to its dependents (callers),
 *     i.e. propagation flows in the OPPOSITE direction of the "dependsOn" arrow.
 */
export interface ServiceDependency {
  serviceId: string;
  dependsOnServiceId: string;
  /** Optional label, e.g. "http", "grpc", "queue" */
  protocol?: string;
}

export type AnomalyType =
  | "latency_spike"
  | "error_rate_spike"
  | "timeout_spike"
  | "throughput_drop"
  | "health_degradation"
  | "saturation"
  | "other";

export interface Anomaly {
  id: string;
  serviceId: string;
  timestamp: string;
  type: AnomalyType;
  metric?: string;
  baselineValue?: number;
  observedValue?: number;
  severity: Severity;
  description: string;
}

export type LogLevel = "debug" | "info" | "warn" | "error" | "fatal";

export interface Log {
  id: string;
  serviceId: string;
  timestamp: string;
  level: LogLevel;
  message: string;
}

export interface Metric {
  id: string;
  serviceId: string;
  timestamp: string;
  name: string;
  value: number;
  unit?: string;
}

export type SystemEventType =
  | "configuration_changed"
  | "deployment_started"
  | "deployment_completed"
  | "service_restarted"
  | "infrastructure_change"
  | "dependency_change"
  | "other";

export interface SystemEvent {
  id: string;
  serviceId?: string;
  timestamp: string;
  type: SystemEventType;
  description: string;
  metadata?: Record<string, unknown>;
}

export type TraceStatus = "ok" | "error" | "timeout";

export interface TraceSpan {
  serviceId: string;
  durationMs: number;
  status: TraceStatus;
}

export interface Trace {
  id: string;
  timestamp: string;
  serviceId: string; // service where the trace/root span originates from the caller's perspective
  durationMs: number;
  status: TraceStatus;
  /** Ordered list of services the request traveled through, e.g. ["api-gateway", "order-service", "payment-service"] */
  path: string[];
  spans?: TraceSpan[];
}

export interface ServiceHealth {
  id: string;
  serviceId: string;
  timestamp: string;
  healthScore: number; // 0-100, 100 = perfectly healthy
  errorRate: number; // 0-1
  latencyMs: number;
  status: "healthy" | "degraded" | "unhealthy";
}
