let counter = 0;

/**
 * Deterministic, human-readable ID generator. Not globally unique across
 * process restarts by design - investigation runs are meant to be
 * reproducible within a single process/demo run. A prefix keeps IDs
 * self-describing (e.g. "timeline-3", "cluster-1").
 */
export function nextId(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

export function resetIdCounter(): void {
  counter = 0;
}
