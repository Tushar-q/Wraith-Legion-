import { describe, it, expect } from "vitest";
import { InvestigationEngine } from "../src/investigation/InvestigationEngine";
import { MockIncidentDataProvider, MockTelemetryProvider, MockDependencyProvider } from "../src/providers/mock/MockProviders";
import { resetIdCounter } from "../src/utils/id";

describe("CausalGraphBuilder (via InvestigationEngine)", () => {
  it("produces a causal graph with expected node coverage and evidence-backed, chronologically consistent edges (TEST 8)", async () => {
    resetIdCounter();
    const engine = new InvestigationEngine(
      new MockIncidentDataProvider(),
      new MockTelemetryProvider(),
      new MockDependencyProvider()
    );
    const result = await engine.run("INC-042");

    expect(result.causalGraph.nodes.length).toBeGreaterThan(0);
    expect(result.causalGraph.edges.length).toBeGreaterThan(0);

    // Expected conceptual nodes should be present by title/service.
    const titles = result.causalGraph.nodes.map((n) => n.title.toLowerCase());
    expect(titles.some((t) => t.includes("configuration changed"))).toBe(true);
    expect(titles.some((t) => t.includes("latency"))).toBe(true);
    expect(titles.some((t) => t.includes("timeout"))).toBe(true);
    expect(result.causalGraph.nodes.some((n) => n.type === "impact")).toBe(true);

    // Every edge must reference real, existing nodes (no dangling/invented edges).
    const nodeIds = new Set(result.causalGraph.nodes.map((n) => n.id));
    for (const edge of result.causalGraph.edges) {
      expect(nodeIds.has(edge.sourceId)).toBe(true);
      expect(nodeIds.has(edge.targetId)).toBe(true);
      expect(edge.confidence).toBeGreaterThanOrEqual(0);
      expect(edge.confidence).toBeLessThanOrEqual(100);
    }

    // Every edge must be chronologically forward (source at or before target) - no time-travel edges.
    const nodeById = new Map(result.causalGraph.nodes.map((n) => [n.id, n]));
    for (const edge of result.causalGraph.edges) {
      const source = nodeById.get(edge.sourceId)!;
      const target = nodeById.get(edge.targetId)!;
      expect(new Date(source.timestamp).getTime()).toBeLessThanOrEqual(new Date(target.timestamp).getTime());
    }

    // The configuration-change node should have an outgoing edge (it "likely_caused" or
    // "likely_contributed_to" something downstream), not be an isolated node.
    const configNode = result.causalGraph.nodes.find((n) => n.title.toLowerCase().includes("configuration changed"));
    expect(configNode).toBeDefined();
    expect(result.causalGraph.edges.some((e) => e.sourceId === configNode!.id)).toBe(true);
  });
});
