import { describe, it, expect } from "vitest";
import { InvestigationEngine } from "../src/investigation/InvestigationEngine";
import { MockIncidentDataProvider, MockTelemetryProvider, MockDependencyProvider } from "../src/providers/mock/MockProviders";
import { InvestigationService } from "../src/services/InvestigationService";
import { resetIdCounter } from "../src/utils/id";

function makeEngine() {
  return new InvestigationEngine(new MockIncidentDataProvider(), new MockTelemetryProvider(), new MockDependencyProvider());
}

describe("InvestigationEngine end-to-end (TEST 9)", () => {
  it("produces a complete InvestigationResult for INC-042 with the expected primary hypothesis", async () => {
    resetIdCounter();
    const engine = makeEngine();
    const result = await engine.run("INC-042");

    expect(result.status).toBe("completed");
    expect(result.incidentId).toBe("INC-042");
    expect(result.investigationId).toBeTruthy();

    // Timeline
    expect(result.timeline.length).toBeGreaterThan(0);

    // First failure
    expect(result.firstFailure?.serviceId).toBe("payment-service");

    // Suspicious change
    expect(result.suspiciousChanges[0]?.changeType).toBe("configuration_changed");

    // Propagation path
    expect(result.summary.propagationPath).toEqual(["payment-service", "order-service", "api-gateway"]);

    // Root cause candidates + primary hypothesis
    expect(result.rootCauseCandidates.length).toBeGreaterThan(1);
    expect(result.primaryHypothesis).not.toBeNull();
    expect(result.primaryHypothesis!.type).toBe("configuration_change");
    expect(result.primaryHypothesis!.serviceId).toBe("payment-service");

    // Confidence: high but not 100% (never claim certainty)
    expect(result.primaryHypothesis!.confidence).toBeGreaterThanOrEqual(85);
    expect(result.primaryHypothesis!.confidence).toBeLessThan(100);
    expect(result.summary.confidence).toBe(result.primaryHypothesis!.confidence);

    // Causal graph
    expect(result.causalGraph.nodes.length).toBeGreaterThan(0);
    expect(result.causalGraph.edges.length).toBeGreaterThan(0);

    // Evidence clusters
    expect(result.evidenceClusters.length).toBeGreaterThan(0);

    // Classified events
    expect(result.classifiedEvents.length).toBe(result.timeline.length);
  });

  it("throws no unhandled errors and returns status=failed gracefully for an unknown incident", async () => {
    resetIdCounter();
    const engine = makeEngine();
    const result = await engine.run("INC-DOES-NOT-EXIST");
    expect(result.status).toBe("failed");
    expect(result.error).toBeTruthy();
  });

  it("supports the full service layer: run, list, get, evidence filters, AI context", async () => {
    resetIdCounter();
    const engine = makeEngine();
    const service = new InvestigationService(engine);

    const result = await service.runInvestigation("INC-042");
    expect(result.status).toBe("completed");

    const listed = service.listInvestigations();
    expect(listed.length).toBe(1);

    const fetched = service.getInvestigation(result.investigationId);
    expect(fetched?.investigationId).toBe(result.investigationId);

    const latestForIncident = service.getLatestForIncident("INC-042");
    expect(latestForIncident?.investigationId).toBe(result.investigationId);

    const allEvidence = service.getEvidence(result.investigationId);
    expect(allEvidence).not.toBeNull();
    expect(allEvidence!.length).toBeGreaterThan(0);

    const paymentEvidence = service.getEvidence(result.investigationId, { serviceId: "payment-service" });
    expect(paymentEvidence!.every((e) => e.serviceId === "payment-service")).toBe(true);
    expect(paymentEvidence!.length).toBeLessThan(allEvidence!.length);

    const highRelevance = service.getEvidence(result.investigationId, { minRelevance: 90 });
    expect(highRelevance!.every((e) => e.relevanceScore >= 90)).toBe(true);

    const aiContext = service.getAIContext(result.investigationId);
    expect(aiContext).not.toBeNull();
    expect(aiContext!.primaryHypothesis?.type).toBe("configuration_change");
    expect(aiContext!.incident.id).toBe("INC-042");
  });
});
