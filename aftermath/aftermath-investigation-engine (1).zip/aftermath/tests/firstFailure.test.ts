import { describe, it, expect } from "vitest";
import { FirstFailureAnalyzer } from "../src/investigation/FirstFailureAnalyzer";
import { buildInc042Context } from "./testHelpers";

describe("FirstFailureAnalyzer", () => {
  it("identifies payment-service as the first abnormal service (TEST 2)", async () => {
    const context = await buildInc042Context();
    const result = new FirstFailureAnalyzer().analyze(context);

    expect(result).not.toBeNull();
    expect(result!.serviceId).toBe("payment-service");
    expect(result!.timestamp).toBe("2026-08-29T09:00:10Z");
    expect(result!.confidence).toBeGreaterThan(0);
    expect(result!.confidence).toBeLessThanOrEqual(100);
  });

  it("returns null when there is no evidence", () => {
    const analyzer = new FirstFailureAnalyzer();
    const empty = analyzer.analyze({
      incident: {
        id: "X",
        title: "x",
        description: "",
        status: "open",
        severity: "info",
        detectedAt: new Date().toISOString(),
        affectedServiceIds: [],
      },
      services: [],
      dependencies: [],
      anomalies: [],
      logs: [],
      metrics: [],
      events: [],
      traces: [],
      healthHistory: [],
      window: { start: "", end: "", lookbackSeconds: 0, lookforwardSeconds: 0 },
    });
    expect(empty).toBeNull();
  });
});
