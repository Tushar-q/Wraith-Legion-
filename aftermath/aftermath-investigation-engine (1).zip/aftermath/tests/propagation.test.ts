import { describe, it, expect } from "vitest";
import { FirstFailureAnalyzer } from "../src/investigation/FirstFailureAnalyzer";
import { ChangeCorrelationAnalyzer } from "../src/investigation/ChangeCorrelationAnalyzer";
import { DependencyAnalyzer } from "../src/investigation/DependencyAnalyzer";
import { FailurePropagationAnalyzer } from "../src/investigation/FailurePropagationAnalyzer";
import { buildInc042Context } from "./testHelpers";

describe("ChangeCorrelationAnalyzer", () => {
  it("identifies the payment timeout configuration change with ~5s distance and high suspicion (TEST 3)", async () => {
    const context = await buildInc042Context();
    const firstFailure = new FirstFailureAnalyzer().analyze(context);
    const dependencyAnalyzer = new DependencyAnalyzer(context.dependencies);
    const changes = new ChangeCorrelationAnalyzer().analyze(context, firstFailure, dependencyAnalyzer);

    expect(changes.length).toBeGreaterThan(0);
    const top = changes[0];
    expect(top.changeType).toBe("configuration_changed");
    expect(top.serviceId).toBe("payment-service");
    expect(top.temporalDistanceSeconds).toBe(5);
    expect(top.suspicionScore).toBeGreaterThanOrEqual(80);
  });
});

describe("DependencyAnalyzer", () => {
  it("resolves upstream/downstream relationships and paths correctly", async () => {
    const context = await buildInc042Context();
    const dep = new DependencyAnalyzer(context.dependencies);

    // order-service depends on payment-service -> payment-service is upstream of order-service
    expect(dep.getUpstreamServices("order-service")).toContain("payment-service");
    // payment-service's failure affects order-service -> order-service is downstream of payment-service
    expect(dep.getDownstreamServices("payment-service")).toContain("order-service");
    expect(dep.getDownstreamServices("payment-service")).toContain("api-gateway");

    const path = dep.findPath("payment-service", "api-gateway");
    expect(path).toEqual(["payment-service", "order-service", "api-gateway"]);

    expect(dep.findDependencyDistance("payment-service", "order-service")).toBe(1);
    expect(dep.findDependencyDistance("payment-service", "api-gateway")).toBe(2);
  });
});

describe("FailurePropagationAnalyzer", () => {
  it("produces payment-service -> order-service -> api-gateway with meaningful confidence (TEST 4)", async () => {
    const context = await buildInc042Context();
    const dependencyAnalyzer = new DependencyAnalyzer(context.dependencies);
    const edges = new FailurePropagationAnalyzer().analyze(context, dependencyAnalyzer);

    const paymentToOrder = edges.find((e) => e.sourceServiceId === "payment-service" && e.targetServiceId === "order-service");
    const orderToGateway = edges.find((e) => e.sourceServiceId === "order-service" && e.targetServiceId === "api-gateway");

    expect(paymentToOrder).toBeDefined();
    expect(orderToGateway).toBeDefined();
    expect(paymentToOrder!.confidence).toBeGreaterThanOrEqual(70);
    expect(orderToGateway!.confidence).toBeGreaterThanOrEqual(70);
    expect(paymentToOrder!.dependencyDistance).toBe(1);
    expect(paymentToOrder!.factors.length).toBeGreaterThan(0);
  });

  it("does not connect an unrelated / out-of-order service with no dependency relationship (TEST 5)", async () => {
    const context = await buildInc042Context();
    const dependencyAnalyzer = new DependencyAnalyzer(context.dependencies);
    const edges = new FailurePropagationAnalyzer().analyze(context, dependencyAnalyzer);

    // inventory-service has no telemetry/anomalies in this scenario and no dependency edge FROM
    // payment/order that would make it a plausible propagation target here (order depends on it,
    // not the other way around) - it must not appear as a target of any propagation edge.
    expect(edges.some((e) => e.targetServiceId === "inventory-service")).toBe(false);

    // api-gateway must never be listed as a SOURCE of propagation to payment-service or order-service -
    // that would be backwards relative to the dependency graph and the actual failure order.
    expect(edges.some((e) => e.sourceServiceId === "api-gateway")).toBe(false);
  });
});
