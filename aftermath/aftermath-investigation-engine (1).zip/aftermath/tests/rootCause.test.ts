import { describe, it, expect } from "vitest";
import { FirstFailureAnalyzer } from "../src/investigation/FirstFailureAnalyzer";
import { ChangeCorrelationAnalyzer } from "../src/investigation/ChangeCorrelationAnalyzer";
import { DependencyAnalyzer } from "../src/investigation/DependencyAnalyzer";
import { FailurePropagationAnalyzer } from "../src/investigation/FailurePropagationAnalyzer";
import { EvidenceCollector } from "../src/investigation/EvidenceCollector";
import { RootCauseCandidateGenerator } from "../src/investigation/RootCauseCandidateGenerator";
import { RootCauseScorer } from "../src/investigation/RootCauseScorer";
import { buildInc042Context } from "./testHelpers";

async function runRootCausePipeline() {
  const context = await buildInc042Context();
  const dependencyAnalyzer = new DependencyAnalyzer(context.dependencies);
  const firstFailure = new FirstFailureAnalyzer().analyze(context);
  const changes = new ChangeCorrelationAnalyzer().analyze(context, firstFailure, dependencyAnalyzer);
  const propagation = new FailurePropagationAnalyzer().analyze(context, dependencyAnalyzer);
  const evidence = new EvidenceCollector().collect(context, firstFailure);
  const raw = new RootCauseCandidateGenerator().generate(context, firstFailure, changes);
  const scorer = new RootCauseScorer();
  const scored = raw
    .map((c) => scorer.score(c, firstFailure, propagation, evidence, dependencyAnalyzer, context.incident.severity))
    .sort((a, b) => b.confidence - a.confidence);
  return { scored, firstFailure };
}

describe("RootCauseCandidateGenerator + RootCauseScorer", () => {
  it("ranks the configuration change candidate highest, with multiple other candidates present (TEST 6)", async () => {
    const { scored } = await runRootCausePipeline();

    expect(scored.length).toBeGreaterThan(1);
    expect(scored[0].type).toBe("configuration_change");
    expect(scored[0].serviceId).toBe("payment-service");
    expect(scored[0].confidence).toBeGreaterThanOrEqual(85);
    expect(scored[0].confidence).toBeLessThanOrEqual(100);

    // candidates are ranked in descending confidence order
    for (let i = 1; i < scored.length; i++) {
      expect(scored[i - 1].confidence).toBeGreaterThanOrEqual(scored[i].confidence);
    }
  });

  it("every candidate confidence is within 0-100 and has a non-empty reasons list", async () => {
    const { scored } = await runRootCausePipeline();
    for (const c of scored) {
      expect(c.confidence).toBeGreaterThanOrEqual(0);
      expect(c.confidence).toBeLessThanOrEqual(100);
      expect(c.reasons.length).toBeGreaterThan(0);
    }
  });

  it("significantly reduces confidence for a candidate that occurred AFTER the first failure (TEST 7)", async () => {
    const context = await buildInc042Context();
    const dependencyAnalyzer = new DependencyAnalyzer(context.dependencies);
    const firstFailure = new FirstFailureAnalyzer().analyze(context);
    const evidence = new EvidenceCollector().collect(context, firstFailure);
    const scorer = new RootCauseScorer();

    // A candidate whose change happened AFTER first failure - contradicts causality.
    const contradictingCandidate = {
      id: "test-contradicting",
      type: "configuration_change" as const,
      title: "Suspicious late change",
      description: "test",
      serviceId: "payment-service",
      timestamp: "2026-08-29T09:00:35Z", // 25s AFTER first failure at 09:00:10
      evidenceIds: [],
    };

    // An otherwise-comparable candidate that happened BEFORE the first failure.
    const supportingCandidate = {
      ...contradictingCandidate,
      id: "test-supporting",
      timestamp: "2026-08-29T09:00:05Z", // before first failure
    };

    const scoredContradicting = scorer.score(
      contradictingCandidate,
      firstFailure,
      [],
      evidence,
      dependencyAnalyzer,
      context.incident.severity
    );
    const scoredSupporting = scorer.score(
      supportingCandidate,
      firstFailure,
      [],
      evidence,
      dependencyAnalyzer,
      context.incident.severity
    );

    expect(scoredContradicting.confidence).toBeLessThan(scoredSupporting.confidence);
    expect(scoredContradicting.score.contradictionPenalty).toBeLessThan(0);
  });
});
