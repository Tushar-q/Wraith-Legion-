import { IncidentContextCollector } from "../src/investigation/IncidentContextCollector";
import { MockIncidentDataProvider, MockTelemetryProvider, MockDependencyProvider } from "../src/providers/mock/MockProviders";
import { resetIdCounter } from "../src/utils/id";

export async function buildInc042Context() {
  resetIdCounter();
  const collector = new IncidentContextCollector(
    new MockIncidentDataProvider(),
    new MockTelemetryProvider(),
    new MockDependencyProvider()
  );
  return collector.collect("INC-042");
}
