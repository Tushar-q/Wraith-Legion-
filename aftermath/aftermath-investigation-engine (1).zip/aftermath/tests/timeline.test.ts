import { describe, it, expect } from "vitest";
import { TimelineBuilder } from "../src/investigation/TimelineBuilder";
import { buildInc042Context } from "./testHelpers";

describe("TimelineBuilder", () => {
  it("produces a correctly ordered chronological timeline (TEST 1)", async () => {
    const context = await buildInc042Context();
    const timeline = new TimelineBuilder().build(context);

    expect(timeline.length).toBeGreaterThan(0);

    for (let i = 1; i < timeline.length; i++) {
      const prev = new Date(timeline[i - 1].timestamp).getTime();
      const curr = new Date(timeline[i].timestamp).getTime();
      expect(curr).toBeGreaterThanOrEqual(prev);
    }
  });

  it("includes the configuration change as the first timeline entry", async () => {
    const context = await buildInc042Context();
    const timeline = new TimelineBuilder().build(context);
    expect(timeline[0].title).toMatch(/configuration changed/i);
    expect(timeline[0].serviceId).toBe("payment-service");
  });

  it("includes a user impact entry", async () => {
    const context = await buildInc042Context();
    const timeline = new TimelineBuilder().build(context);
    expect(timeline.some((e) => e.type === "user_impact")).toBe(true);
  });

  it("removes exact duplicate entries", async () => {
    const context = await buildInc042Context();
    const timeline = new TimelineBuilder().build(context);
    const keys = timeline.map((e) => `${e.timestamp}|${e.type}|${e.serviceId}|${e.title}|${e.description}`);
    expect(new Set(keys).size).toBe(keys.length);
  });
});
