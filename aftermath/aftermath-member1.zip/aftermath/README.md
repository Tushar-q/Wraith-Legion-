# AFTERMATH — Member 1 Module

Telemetry generation/ingestion, normalization, storage, rule-based anomaly detection, service health calculation, incident detection, and the deterministic **Payment Failure Propagation** incident simulator for the AFTERMATH incident investigation platform.

This is a standalone TypeScript/Node.js/Express project. It has no dependency on any other member's code and exposes clean REST APIs + reusable classes so Members 2 (causal analysis), 3 (AI reasoning), and 4 (frontend) can integrate against it.

## Stack

- TypeScript (strict mode) + Node.js
- Express (REST API layer only — no business logic in routes)
- In-memory storage (no DB, no Kafka, no Redis — hackathon-appropriate)
- Jest + Supertest for automated tests
- Zero ML — every anomaly/health/severity calculation is deterministic, rule-based, and explainable

## Install & Run

```bash
npm install

# Development (auto-reload)
npm run dev

# Type-check only
npm run typecheck

# Production build
npm run build
npm start          # runs dist/server.js

# Tests (41 tests, all passing)
npm test
```

The server listens on `http://localhost:4000` by default (override with `PORT=...`).

## Verified Status

- ✅ `npm run build` compiles with **zero TypeScript errors**
- ✅ `npm test` → **6 suites, 41 tests, all passing**
- ✅ Server actually started and the full demo lifecycle was exercised live via `curl` against the running process (not just unit tests) — see "Example API Responses" below for real captured output
- ✅ Determinism verified: resetting and re-running the scenario produces the same incident, same anomaly counts, same affected services every time

## Project Structure

```
src/
  types/            Shared TypeScript contracts (Service, Telemetry, Anomaly, Incident, Demo...)
  config/           Centralized service definitions, dependency graph, baselines, thresholds
  telemetry/        TelemetryGenerator, TelemetryNormalizer, TelemetryStore (in-memory)
  detectors/        LatencyDetector, ErrorRateDetector, RetryDetector, TimeoutDetector,
                     RequestFailureDetector + AnomalyDetectionEngine
  health/           HealthCalculator (rule-based 0-100 scoring)
  incidents/        IncidentDetector (grouping rules), SeverityCalculator, IncidentManager
  simulator/        IncidentScenario (deterministic step data), IncidentSimulator (the engine)
  events/           EventBus (Node EventEmitter wrapper) + EventTypes
  services/         Thin facades over the simulator/store for the API layer
                     (SystemService, ServicesService, TelemetryService, AnomalyService,
                      IncidentService, DemoService, context.ts)
  api/              Express routers — HTTP only, no business logic
  app.ts            Express app factory
  server.ts         Entry point
tests/              Jest test suites (unit + API integration)
```

### Why this shape

- **Simulator is independent of the API layer.** `IncidentSimulator` has zero Express imports; it's a plain class you can `new` up and drive in a script or a test (see `tests/incidentSimulator.test.ts`).
- **Business logic lives in `detectors/`, `health/`, `incidents/`, `simulator/`** — never in routes. Routes in `api/*.routes.ts` only translate HTTP ⇄ service method calls.
- **Deterministic time.** The simulator uses an internal monotonic clock (`SIMULATION_BASE_TIME` + a step counter), never `Date.now()` or `Math.random()`, so `reset()` → `start()` always reproduces the identical scenario.
- **Centralized config.** No magic numbers scattered in code — see `config/baselines.ts` and `config/thresholds.ts`.

## The Distributed Application Model

8 simulated services with a real dependency graph:

```
API Gateway
├── Order Service
└── User Service

Order Service
├── Payment Service
├── Delivery Service
└── Database

Payment Service
├── External Payment Gateway
└── Database

Notification Service
└── Order Service

Delivery Service ── Database
User Service ── Database
```

Defined once in `src/config/services.ts` as the single source of truth; both the runtime `Service[]` objects and the flattened `ServiceDependency[]` edges are derived from it.

## The Deterministic Scenario — "Payment Failure Propagation" (INC-042)

9 steps (0–8), each of which generates **real structured telemetry** (not just a UI flag):

| Step | Name | What happens |
|---|---|---|
| 0 | HEALTHY_SYSTEM | All 8 services healthy, baseline metrics/logs/trace emitted |
| 1 | CONFIGURATION_CHANGE | `payment.timeout_ms` 5000 → 500, preserved as a `configuration_changed` system event (no anomaly, no incident yet) |
| 2 | PAYMENT_LATENCY_SPIKE | Payment latency climbs 500 → 1500 → 3000 → 4500ms; **critical latency anomaly** |
| 3 | PAYMENT_TIMEOUTS | Timeout + failed-request metrics, `ERROR` logs, a **failed distributed trace**, timeout + error-rate anomalies |
| 4 | ORDER_RETRY_STORM | Order Service retries climb 20 → 50 → 100 → 150; **critical retry anomaly** |
| 5 | ORDER_SERVICE_DEGRADATION | Order latency/error-rate rise further; `service_degraded` event; health drops to degraded/critical |
| 6 | API_GATEWAY_ERRORS | API Gateway 5xx rate and latency rise; anomalies fire for api-gateway |
| 7 | USER_IMPACT | `user_impact_detected` system event + critical log (failed checkouts/orders) |
| 8 | INCIDENT_CREATED | **INC-042 "Payment Failure Propagation"** created: `severity: critical`, `status: detected`, affected services = `payment-service`, `order-service`, `api-gateway` |

Member 1 **never** declares a root cause — the configuration-change event is preserved purely as evidence for Member 2/3 to reason about later.

## Simulator Control Flow

```
POST /api/demo/reset    -> idle, healthy, empty state
POST /api/demo/start    -> runs step 0, status: running
POST /api/demo/next     -> advances exactly one step (steps 1-8)
POST /api/demo/pause    -> freezes without advancing
POST /api/demo/resume   -> unfreezes
POST /api/demo/previous -> deterministically replays from step 0 up to step-1
GET  /api/demo/state    -> current DemoState snapshot
```

`reset()` fully clears telemetry, anomalies, incidents, and restores every service to `healthy` / score 100.

## API Endpoint List

All responses are wrapped as `{ data: ... }` (or `{ data, count }` for list endpoints) for predictable frontend consumption. Errors are `{ error: string }` with an appropriate HTTP status.

| Method | Path | Description |
|---|---|---|
| GET | `/health` | Liveness check |
| GET | `/api/system` | Overall system health summary |
| GET | `/api/services` | All services + current health |
| GET | `/api/services/dependencies` | Full dependency graph |
| GET | `/api/services/:id` | Service detail, dependencies, recent anomalies/metrics |
| GET | `/api/services/:id/summary` | Compact AI-friendly service summary |
| GET | `/api/telemetry` | Unified telemetry, filters: `serviceId`, `category`, `startTime`, `endTime`, `traceId`, `limit` |
| GET | `/api/telemetry/logs` | Raw logs (optional `serviceId`) |
| GET | `/api/telemetry/metrics` | Raw metrics (optional `serviceId`) |
| GET | `/api/telemetry/events` | Raw system events (optional `serviceId`) |
| GET | `/api/telemetry/traces` | Traces (optional `serviceId`) |
| GET | `/api/telemetry/traces/:traceId` | Single trace |
| GET | `/api/telemetry/health-history` | Service health change history |
| GET | `/api/anomalies` | All anomalies, filters: `serviceId`, `severity` |
| GET | `/api/anomalies/:id` | Single anomaly |
| GET | `/api/incidents` | All incidents |
| GET | `/api/incidents/active` | Non-resolved incidents |
| GET | `/api/incidents/:id` | Single incident |
| GET | `/api/incidents/:id/context` | **Member 2 contract** — full investigation package |
| GET | `/api/incidents/:id/summary` | **Member 3 contract** — evidence-oriented narrative |
| GET | `/api/incidents/:id/events` | Important events (config changes, degradation, user impact) |
| GET | `/api/incidents/:id/anomaly-summary` | Anomaly counts by severity/service + top 5 |
| GET | `/api/incidents/:id/logs` | Error/critical logs for the incident |
| POST | `/api/demo/start` | Start simulation |
| POST | `/api/demo/pause` | Pause |
| POST | `/api/demo/resume` | Resume |
| POST | `/api/demo/next` | Advance one step |
| POST | `/api/demo/previous` | Rewind one step (deterministic replay) |
| POST | `/api/demo/reset` | Reset to idle/healthy |
| GET | `/api/demo/state` | Current `DemoState` |

## Example API Responses (captured from a real running instance)

**`GET /api/system`** (before starting):
```json
{
  "data": {
    "overallStatus": "healthy",
    "serviceCount": 8,
    "healthyServiceCount": 8,
    "degradedServiceCount": 0,
    "criticalServiceCount": 0,
    "activeIncidentCount": 0,
    "totalAnomalyCount": 0,
    "totalTelemetryCount": 0,
    "simulation": { "status": "idle", "currentStep": 0, "totalSteps": 9, "currentStepName": "NOT_STARTED" }
  }
}
```

**`GET /api/incidents/INC-042`** (after running the full scenario):
```json
{
  "data": {
    "id": "INC-042",
    "title": "Payment Failure Propagation",
    "severity": "critical",
    "status": "detected",
    "detectedAt": "2026-08-29T09:06:15.000Z",
    "startTime": "2026-08-29T09:06:15.000Z",
    "affectedServices": ["payment-service", "order-service", "api-gateway"],
    "anomalyIds": ["anomaly-payment-service-latency-...", "... 13 more"],
    "description": "Multiple services are experiencing related failures affecting the payment and order workflow. Evidence includes a recent payment-service configuration change, a payment latency spike, payment timeouts, an order-service retry storm, and API Gateway errors. Root cause investigation is handled by downstream analysis."
  }
}
```

**`GET /api/incidents/INC-042/summary`**:
```json
{
  "data": {
    "id": "INC-042",
    "title": "Payment Failure Propagation",
    "severity": "critical",
    "anomalyCount": 14,
    "criticalAnomalyCount": 7,
    "configurationChanges": [
      { "description": "Payment timeout changed from 5000ms to 500ms", "timestamp": "2026-08-29T09:02:30.000Z" }
    ],
    "narrative": "Incident INC-042 (Payment Failure Propagation) was detected at 2026-08-29T09:06:15.000Z affecting payment-service, order-service, api-gateway. 14 anomalies were recorded (7 critical). 1 configuration change(s) were preserved as evidence. This summary presents detected evidence only; root cause has not been determined."
  }
}
```

## How Member 2 should consume `getIncidentContext()`

```ts
import { engine } from './services/context';
import { IncidentService } from './services/IncidentService';

const incidentService = new IncidentService(engine.simulator, engine.store);
const context = incidentService.getIncidentContext('INC-042');

// context = {
//   incident,            // the Incident record
//   anomalies,           // every Anomaly that contributed
//   affectedServices,    // full Service objects (current state) for each affected service
//   telemetry,           // unified TelemetryEvent[] for all affected services
//   traces,              // Trace[] touching any affected service (includes failed traces)
//   events,              // SystemEvent[] (config changes, degradation, user impact, ...)
//   healthHistory,       // ServiceHealthEvent[] — every status transition
//   dependencies,        // ServiceDependency[] edges touching affected services
// }
```

Or over HTTP: `GET /api/incidents/INC-042/context`. Member 2 uses `dependencies` + `telemetry` + `traces` to reconstruct the causal chain — Member 1 deliberately does not pre-compute or claim it.

## How Member 3 should consume the incident data

Use the evidence-oriented, LLM-prompt-friendly endpoints — never raw firehoses:

- `GET /api/incidents/:id/summary` → `IncidentSummary` (narrative + counts, no root-cause claim)
- `GET /api/incidents/:id/anomaly-summary` → counts by severity/service + top 5 most severe
- `GET /api/incidents/:id/events` → only the "important" event types (config changes, degradation, user impact)
- `GET /api/incidents/:id/logs` → only ERROR/CRITICAL logs
- `GET /api/services/:id/summary` → compact per-service state for grounding

All of these are also available as plain TypeScript methods on `IncidentService` for in-process use if Member 3's reasoning layer runs in the same Node process.

## How Member 4 should consume the APIs

- `GET /api/services` + `GET /api/services/dependencies` → render the dependency graph
- `GET /api/telemetry/health-history` → health timeline per service
- `GET /api/telemetry?category=...` → logs/metrics/events/traces for a timeline/evidence explorer
- `GET /api/anomalies` and `GET /api/incidents/active` → highlight problems
- `POST /api/demo/*` + `GET /api/demo/state` → drive/replay the incident from the UI
- All list responses are `{ data: [...], count }`; all single-resource responses are `{ data: {...} }`; errors are always `{ error: string }` with a proper status code — safe to build a generic HTTP client against.

## Limitations (by design, for a 48-hour hackathon)

- **In-memory only.** All state (telemetry, anomalies, incidents) is lost on process restart. `TelemetryStore` is written as a clean abstraction specifically so it can be swapped for a persistent backend later without touching callers.
- **Single simulator instance.** `services/context.ts` exports one shared `engine` singleton — fine for a single-session demo; would need per-session engines for concurrent demos.
- **One scenario.** Only "Payment Failure Propagation" is implemented, per the hackathon brief. `IncidentScenario.ts` is intentionally data-only so a second scenario could be added without touching the simulator engine.
- **Incident detection is scoped to the active anomaly list**, not a sliding time window — appropriate for a single deterministic demo run, would need windowing for a long-running production system.
- **No auth, no rate limiting, no persistence** — explicitly out of scope per the hackathon constraints.
