import { Router } from 'express';
import { AnomalyService } from '../services/AnomalyService';
import { AnomalySeverity } from '../types';

const VALID_SEVERITIES: AnomalySeverity[] = ['low', 'medium', 'high', 'critical'];

export function anomaliesRouter(anomalyService: AnomalyService): Router {
  const router = Router();

  /** GET /api/anomalies?serviceId=&severity= */
  router.get('/', (req, res) => {
    const { serviceId, severity } = req.query;

    if (severity && !VALID_SEVERITIES.includes(severity as AnomalySeverity)) {
      return res.status(400).json({
        error: `Invalid severity '${severity}'. Must be one of: ${VALID_SEVERITIES.join(', ')}`,
      });
    }

    const anomalies = anomalyService.list({
      serviceId: serviceId as string | undefined,
      severity: severity as AnomalySeverity | undefined,
    });
    res.json({ data: anomalies, count: anomalies.length });
  });

  /** GET /api/anomalies/:id */
  router.get('/:id', (req, res) => {
    const anomaly = anomalyService.getById(req.params.id);
    if (!anomaly) {
      return res.status(404).json({ error: `Anomaly '${req.params.id}' not found` });
    }
    res.json({ data: anomaly });
  });

  return router;
}
