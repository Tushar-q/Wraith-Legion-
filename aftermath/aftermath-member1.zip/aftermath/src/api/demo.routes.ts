import { Router } from 'express';
import { DemoService } from '../services/DemoService';

/**
 * Simulator control endpoints. All logic lives in DemoService /
 * IncidentSimulator - routes only translate HTTP <-> method calls.
 */
export function demoRouter(demoService: DemoService): Router {
  const router = Router();

  /** POST /api/demo/start */
  router.post('/start', (_req, res) => {
    res.json({ data: demoService.start() });
  });

  /** POST /api/demo/pause */
  router.post('/pause', (_req, res) => {
    res.json({ data: demoService.pause() });
  });

  /** POST /api/demo/resume */
  router.post('/resume', (_req, res) => {
    res.json({ data: demoService.resume() });
  });

  /** POST /api/demo/next */
  router.post('/next', (_req, res) => {
    res.json({ data: demoService.next() });
  });

  /** POST /api/demo/previous */
  router.post('/previous', (_req, res) => {
    res.json({ data: demoService.previous() });
  });

  /** POST /api/demo/reset */
  router.post('/reset', (_req, res) => {
    res.json({ data: demoService.reset() });
  });

  /** GET /api/demo/state */
  router.get('/state', (_req, res) => {
    res.json({ data: demoService.getState() });
  });

  return router;
}
