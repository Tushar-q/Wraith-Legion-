import { Router } from 'express';
import { IncidentService } from '../services/IncidentService';

/**
 * Incident routes. In addition to plain CRUD-style reads, exposes the
 * critical integration endpoints other members will use:
 *  - GET /api/incidents/:id/context  -> Member 2 (getIncidentContext)
 *  - GET /api/incidents/:id/summary  -> Member 3 (AI-friendly summary)
 */
export function incidentsRouter(incidentService: IncidentService): Router {
  const router = Router();

  /** GET /api/incidents */
  router.get('/', (_req, res) => {
    res.json({ data: incidentService.list() });
  });

  /** GET /api/incidents/active */
  router.get('/active', (_req, res) => {
    res.json({ data: incidentService.listActive() });
  });

  /** GET /api/incidents/:id */
  router.get('/:id', (req, res) => {
    const incident = incidentService.getById(req.params.id);
    if (!incident) {
      return res.status(404).json({ error: `Incident '${req.params.id}' not found` });
    }
    res.json({ data: incident });
  });

  /** GET /api/incidents/:id/context - full structured package for Member 2. */
  router.get('/:id/context', (req, res) => {
    const context = incidentService.getIncidentContext(req.params.id);
    if (!context) {
      return res.status(404).json({ error: `Incident '${req.params.id}' not found` });
    }
    res.json({ data: context });
  });

  /** GET /api/incidents/:id/summary - evidence-oriented summary for Member 3. */
  router.get('/:id/summary', (req, res) => {
    const summary = incidentService.getIncidentSummary(req.params.id);
    if (!summary) {
      return res.status(404).json({ error: `Incident '${req.params.id}' not found` });
    }
    res.json({ data: summary });
  });

  /** GET /api/incidents/:id/events - important events (config changes, degradation, user impact). */
  router.get('/:id/events', (req, res) => {
    res.json({ data: incidentService.getImportantEvents(req.params.id) });
  });

  /** GET /api/incidents/:id/anomaly-summary */
  router.get('/:id/anomaly-summary', (req, res) => {
    const summary = incidentService.getAnomalySummary(req.params.id);
    if (!summary) {
      return res.status(404).json({ error: `Incident '${req.params.id}' not found` });
    }
    res.json({ data: summary });
  });

  /** GET /api/incidents/:id/logs - important (error/critical) logs for Member 3. */
  router.get('/:id/logs', (req, res) => {
    res.json({ data: incidentService.getImportantLogs(req.params.id) });
  });

  return router;
}
