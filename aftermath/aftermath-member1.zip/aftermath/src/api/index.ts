import { Router } from 'express';
import { AftermathEngine } from '../services/context';
import { SystemService } from '../services/SystemService';
import { ServicesService } from '../services/ServicesService';
import { TelemetryService } from '../services/TelemetryService';
import { AnomalyService } from '../services/AnomalyService';
import { IncidentService } from '../services/IncidentService';
import { DemoService } from '../services/DemoService';
import { systemRouter } from './system.routes';
import { servicesRouter } from './services.routes';
import { telemetryRouter } from './telemetry.routes';
import { anomaliesRouter } from './anomalies.routes';
import { incidentsRouter } from './incidents.routes';
import { demoRouter } from './demo.routes';

/**
 * Builds the full /api router tree, wiring service facades to routes.
 * Kept as a factory (rather than importing the singleton engine
 * directly in each route file) so tests can construct isolated
 * engines/routers without shared global state.
 */
export function buildApiRouter(engine: AftermathEngine): Router {
  const router = Router();

  const systemService = new SystemService(engine.simulator, engine.store);
  const servicesService = new ServicesService(engine.simulator, engine.store);
  const telemetryService = new TelemetryService(engine.store);
  const anomalyService = new AnomalyService(engine.simulator);
  const incidentService = new IncidentService(engine.simulator, engine.store);
  const demoService = new DemoService(engine.simulator);

  router.use('/system', systemRouter(systemService));
  router.use('/services', servicesRouter(servicesService, incidentService));
  router.use('/telemetry', telemetryRouter(telemetryService));
  router.use('/anomalies', anomaliesRouter(anomalyService));
  router.use('/incidents', incidentsRouter(incidentService));
  router.use('/demo', demoRouter(demoService));

  return router;
}
