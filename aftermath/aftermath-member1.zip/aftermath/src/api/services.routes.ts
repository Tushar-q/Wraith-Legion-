import { Router } from 'express';
import { ServicesService } from '../services/ServicesService';
import { IncidentService } from '../services/IncidentService';

export function servicesRouter(servicesService: ServicesService, incidentService: IncidentService): Router {
  const router = Router();

  /** GET /api/services - all services with health + dependencies. */
  router.get('/', (_req, res) => {
    res.json({ data: servicesService.listServices() });
  });

  /** GET /api/services/dependencies - full dependency graph. */
  router.get('/dependencies', (_req, res) => {
    res.json({ data: servicesService.getDependencyGraph() });
  });

  /** GET /api/services/:serviceId/summary - compact, AI-friendly service summary. */
  router.get('/:serviceId/summary', (req, res) => {
    const summary = incidentService.getServiceSummary(req.params.serviceId);
    if (!summary) {
      return res.status(404).json({ error: `Service '${req.params.serviceId}' not found` });
    }
    res.json({ data: summary });
  });

  /** GET /api/services/:serviceId - service detail. */
  router.get('/:serviceId', (req, res) => {
    const detail = servicesService.getServiceDetail(req.params.serviceId);
    if (!detail) {
      return res.status(404).json({ error: `Service '${req.params.serviceId}' not found` });
    }
    res.json({ data: detail });
  });

  return router;
}
