import { Router } from 'express';
import { SystemService } from '../services/SystemService';

export function systemRouter(systemService: SystemService): Router {
  const router = Router();

  /** GET /api/system - overall system health snapshot. */
  router.get('/', (_req, res) => {
    res.json({ data: systemService.getSummary() });
  });

  return router;
}
