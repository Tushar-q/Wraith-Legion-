import { Router } from 'express';
import { TelemetryCategory } from '../types';
import { TelemetryService } from '../services/TelemetryService';

const VALID_CATEGORIES: TelemetryCategory[] = ['metric', 'log', 'event', 'trace', 'health'];

export function telemetryRouter(telemetryService: TelemetryService): Router {
  const router = Router();

  /**
   * GET /api/telemetry
   * Query params: serviceId, category, startTime, endTime, traceId, limit
   */
  router.get('/', (req, res) => {
    const { serviceId, category, startTime, endTime, traceId, limit } = req.query;

    if (category && !VALID_CATEGORIES.includes(category as TelemetryCategory)) {
      return res.status(400).json({
        error: `Invalid category '${category}'. Must be one of: ${VALID_CATEGORIES.join(', ')}`,
      });
    }

    const results = telemetryService.query({
      serviceId: serviceId as string | undefined,
      category: category as TelemetryCategory | undefined,
      startTime: startTime as string | undefined,
      endTime: endTime as string | undefined,
      traceId: traceId as string | undefined,
      limit: limit ? Number(limit) : undefined,
    });

    res.json({ data: results, count: results.length });
  });

  /** GET /api/telemetry/logs */
  router.get('/logs', (req, res) => {
    res.json({ data: telemetryService.getLogs(req.query.serviceId as string | undefined) });
  });

  /** GET /api/telemetry/metrics */
  router.get('/metrics', (req, res) => {
    res.json({ data: telemetryService.getMetrics(req.query.serviceId as string | undefined) });
  });

  /** GET /api/telemetry/events */
  router.get('/events', (req, res) => {
    res.json({ data: telemetryService.getSystemEvents(req.query.serviceId as string | undefined) });
  });

  /** GET /api/telemetry/traces */
  router.get('/traces', (req, res) => {
    res.json({ data: telemetryService.getTraces(req.query.serviceId as string | undefined) });
  });

  /** GET /api/telemetry/traces/:traceId */
  router.get('/traces/:traceId', (req, res) => {
    const trace = telemetryService.getTraceById(req.params.traceId);
    if (!trace) {
      return res.status(404).json({ error: `Trace '${req.params.traceId}' not found` });
    }
    res.json({ data: trace });
  });

  /** GET /api/telemetry/health-history */
  router.get('/health-history', (req, res) => {
    res.json({ data: telemetryService.getHealthHistory(req.query.serviceId as string | undefined) });
  });

  return router;
}
