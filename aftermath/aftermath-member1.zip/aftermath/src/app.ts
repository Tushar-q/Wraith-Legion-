import express, { Express, NextFunction, Request, Response } from 'express';
import cors from 'cors';
import { AftermathEngine } from './services/context';
import { buildApiRouter } from './api';

/**
 * Builds an Express app wired to the given engine (store + simulator).
 * Exported as a factory (not a singleton) so tests can spin up an
 * isolated app + engine per test file.
 */
export function createApp(engine: AftermathEngine): Express {
  const app = express();

  app.use(cors());
  app.use(express.json());

  app.get('/health', (_req, res) => {
    res.json({ status: 'ok', service: 'aftermath-member1' });
  });

  app.use('/api', buildApiRouter(engine));

  app.use((req: Request, res: Response) => {
    res.status(404).json({ error: `Not found: ${req.method} ${req.originalUrl}` });
  });

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    console.error(err);
    res.status(500).json({ error: 'Internal server error', message: err.message });
  });

  return app;
}
