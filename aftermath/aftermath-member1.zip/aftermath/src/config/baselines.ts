/**
 * Centralized "healthy" baseline values per service. Anomaly detectors
 * and the health calculator compare current telemetry against these
 * baselines rather than hard-coding magic numbers throughout the code.
 */
export interface ServiceBaseline {
  latency: number; // ms
  errorRate: number; // fraction 0-1
  retryCount: number; // per observation window
  timeoutCount: number; // per observation window
  failedRequestCount: number; // per observation window
  requestCount: number; // per observation window
}

export const DEFAULT_BASELINE: ServiceBaseline = {
  latency: 80,
  errorRate: 0.002,
  retryCount: 1,
  timeoutCount: 0,
  failedRequestCount: 0,
  requestCount: 100,
};

export const SERVICE_BASELINES: Record<string, ServiceBaseline> = {
  'api-gateway': {
    latency: 55,
    errorRate: 0.001,
    retryCount: 0,
    timeoutCount: 0,
    failedRequestCount: 0,
    requestCount: 500,
  },
  'order-service': {
    latency: 80,
    errorRate: 0.002,
    retryCount: 2,
    timeoutCount: 0,
    failedRequestCount: 0,
    requestCount: 300,
  },
  'payment-service': {
    latency: 120,
    errorRate: 0.005,
    retryCount: 2,
    timeoutCount: 0,
    failedRequestCount: 0,
    requestCount: 200,
  },
  'delivery-service': {
    latency: 90,
    errorRate: 0.003,
    retryCount: 1,
    timeoutCount: 0,
    failedRequestCount: 0,
    requestCount: 120,
  },
  'user-service': {
    latency: 70,
    errorRate: 0.002,
    retryCount: 1,
    timeoutCount: 0,
    failedRequestCount: 0,
    requestCount: 150,
  },
  'notification-service': {
    latency: 60,
    errorRate: 0.001,
    retryCount: 1,
    timeoutCount: 0,
    failedRequestCount: 0,
    requestCount: 90,
  },
  database: {
    latency: 15,
    errorRate: 0.0005,
    retryCount: 0,
    timeoutCount: 0,
    failedRequestCount: 0,
    requestCount: 800,
  },
  'external-payment-gateway': {
    latency: 200,
    errorRate: 0.005,
    retryCount: 0,
    timeoutCount: 0,
    failedRequestCount: 0,
    requestCount: 200,
  },
};

export function getBaseline(serviceId: string): ServiceBaseline {
  return SERVICE_BASELINES[serviceId] ?? DEFAULT_BASELINE;
}
