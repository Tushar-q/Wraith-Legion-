import { Service, ServiceDependency, ServiceType } from '../types';

/**
 * Static definition of every service in the simulated distributed
 * application. This is the single source of truth for service ids,
 * names, and types. Health/latency/etc. are runtime state, seeded
 * from baselines.ts and mutated by the simulator.
 */
export interface ServiceDefinition {
  id: string;
  name: string;
  type: ServiceType;
  dependencies: string[];
}

export const SERVICE_DEFINITIONS: ServiceDefinition[] = [
  {
    id: 'api-gateway',
    name: 'API Gateway',
    type: 'gateway',
    dependencies: ['order-service', 'user-service'],
  },
  {
    id: 'order-service',
    name: 'Order Service',
    type: 'application',
    dependencies: ['payment-service', 'delivery-service', 'database'],
  },
  {
    id: 'payment-service',
    name: 'Payment Service',
    type: 'application',
    dependencies: ['external-payment-gateway', 'database'],
  },
  {
    id: 'delivery-service',
    name: 'Delivery Service',
    type: 'application',
    dependencies: ['database'],
  },
  {
    id: 'user-service',
    name: 'User Service',
    type: 'application',
    dependencies: ['database'],
  },
  {
    id: 'notification-service',
    name: 'Notification Service',
    type: 'application',
    dependencies: ['order-service'],
  },
  {
    id: 'database',
    name: 'Database',
    type: 'database',
    dependencies: [],
  },
  {
    id: 'external-payment-gateway',
    name: 'External Payment Gateway',
    type: 'external',
    dependencies: [],
  },
];

/**
 * Flattened directed edges (source depends on / calls target).
 * Derived from SERVICE_DEFINITIONS so it can never drift out of sync.
 */
export const SERVICE_DEPENDENCIES: ServiceDependency[] = SERVICE_DEFINITIONS.flatMap(
  (def) =>
    def.dependencies.map((target) => ({
      source: def.id,
      target,
      relationship: 'calls',
    }))
);

export function getServiceIds(): string[] {
  return SERVICE_DEFINITIONS.map((s) => s.id);
}

/**
 * Build fresh, healthy runtime Service objects from the static
 * definitions and baseline values. Used by the store / simulator on
 * initialization and on reset().
 */
export function createInitialServices(
  baselineFor: (serviceId: string) => {
    latency: number;
    errorRate: number;
  },
  now: () => string
): Service[] {
  return SERVICE_DEFINITIONS.map((def) => {
    const baseline = baselineFor(def.id);
    const service: Service = {
      id: def.id,
      name: def.name,
      type: def.type,
      dependencies: def.dependencies,
      status: 'healthy',
      healthScore: 100,
      latency: baseline.latency,
      errorRate: baseline.errorRate,
      requestCount: 0,
      retryCount: 0,
      timeoutCount: 0,
      failedRequestCount: 0,
      cpuUsage: 0.2,
      memoryUsage: 0.3,
      lastUpdated: now(),
    };
    return service;
  });
}
