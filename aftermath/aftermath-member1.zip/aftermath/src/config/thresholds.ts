/**
 * Centralized thresholds used by anomaly detectors and the health
 * calculator. Keeping these in one place avoids scattering magic
 * numbers across the codebase.
 */

export const LATENCY_THRESHOLDS = {
  warningMs: 500,
  criticalMs: 2000,
};

export const ERROR_RATE_THRESHOLDS = {
  warning: 0.05, // 5%
  critical: 0.25, // 25%
};

export const RETRY_THRESHOLDS = {
  warning: 10,
  critical: 50,
};

export const TIMEOUT_THRESHOLDS = {
  warning: 5,
  critical: 20,
};

export const FAILED_REQUEST_THRESHOLDS = {
  warning: 10,
  critical: 50,
};

/** Minimum deviation (%) above baseline before something counts as an anomaly at all. */
export const MIN_ANOMALY_DEVIATION_PERCENT = 50;

export const HEALTH_SCORE = {
  initial: 100,
  penalties: {
    criticalLatency: 30,
    warningLatency: 12,
    highErrorRate: 30,
    warningErrorRate: 12,
    timeoutSpike: 25,
    warningTimeouts: 10,
    retryStorm: 15,
    warningRetries: 6,
    failedRequests: 15,
  },
  statusBands: {
    healthyMin: 80,
    degradedMin: 50, // 50-79 = degraded, below = critical
  },
};

export const SEVERITY_SCORING = {
  anomalyPoints: {
    critical: 40,
    high: 25,
    medium: 10,
    low: 5,
  },
  multipleServicesBonus: 20,
  userImpactBonus: 30,
  bands: {
    lowMax: 20,
    mediumMax: 50,
    highMax: 80,
    // anything above highMax => critical
  },
};
