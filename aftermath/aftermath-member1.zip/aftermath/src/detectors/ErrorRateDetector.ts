import { v4 as uuidv4 } from 'uuid';
import { Anomaly, AnomalyDetector, AnomalySeverity, DetectionInput } from '../types';
import { ERROR_RATE_THRESHOLDS, MIN_ANOMALY_DEVIATION_PERCENT } from '../config/thresholds';

export class ErrorRateDetector implements AnomalyDetector {
  name = 'ErrorRateDetector';

  detect(input: DetectionInput): Anomaly[] {
    const { serviceId, timestamp, baseline, current, relatedTelemetryIds } = input;
    const expected = baseline.errorRate;
    const actual = current.errorRate;

    const deviation = expected > 0 ? ((actual - expected) / expected) * 100 : actual > 0 ? 100 : 0;

    if (actual < ERROR_RATE_THRESHOLDS.warning || deviation < MIN_ANOMALY_DEVIATION_PERCENT) {
      return [];
    }

    const severity: AnomalySeverity = actual >= ERROR_RATE_THRESHOLDS.critical ? 'critical' : 'high';

    const anomaly: Anomaly = {
      id: `anomaly-${serviceId}-error-rate-${uuidv4()}`,
      timestamp,
      serviceId,
      metric: 'error_rate',
      expectedValue: Math.round(expected * 1000) / 10, // as percent
      actualValue: Math.round(actual * 1000) / 10,
      deviation: Math.round(deviation),
      severity,
      description: `${serviceId} error rate rose to ${(actual * 100).toFixed(1)}%, well above its normal baseline of ${(expected * 100).toFixed(2)}%.`,
      relatedTelemetryIds,
    };

    return [anomaly];
  }
}
