import { v4 as uuidv4 } from 'uuid';
import { Anomaly, AnomalyDetector, AnomalySeverity, DetectionInput } from '../types';
import { LATENCY_THRESHOLDS, MIN_ANOMALY_DEVIATION_PERCENT } from '../config/thresholds';

export class LatencyDetector implements AnomalyDetector {
  name = 'LatencyDetector';

  detect(input: DetectionInput): Anomaly[] {
    const { serviceId, timestamp, baseline, current, relatedTelemetryIds } = input;
    const expected = baseline.latency;
    const actual = current.latency;

    const deviation = expected > 0 ? ((actual - expected) / expected) * 100 : 0;

    if (deviation < MIN_ANOMALY_DEVIATION_PERCENT) {
      return [];
    }

    let severity: AnomalySeverity;
    if (actual >= LATENCY_THRESHOLDS.criticalMs) {
      severity = 'critical';
    } else if (actual >= LATENCY_THRESHOLDS.warningMs) {
      severity = 'high';
    } else {
      severity = 'medium';
    }

    const anomaly: Anomaly = {
      id: `anomaly-${serviceId}-latency-${uuidv4()}`,
      timestamp,
      serviceId,
      metric: 'latency',
      expectedValue: expected,
      actualValue: actual,
      deviation: Math.round(deviation),
      severity,
      description: `${serviceId} latency increased significantly above its normal baseline (expected ~${expected}ms, observed ${actual}ms).`,
      relatedTelemetryIds,
    };

    return [anomaly];
  }
}
