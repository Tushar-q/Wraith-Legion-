import { v4 as uuidv4 } from 'uuid';
import { Anomaly, AnomalyDetector, AnomalySeverity, DetectionInput } from '../types';
import { FAILED_REQUEST_THRESHOLDS } from '../config/thresholds';

export class RequestFailureDetector implements AnomalyDetector {
  name = 'RequestFailureDetector';

  detect(input: DetectionInput): Anomaly[] {
    const { serviceId, timestamp, baseline, current, relatedTelemetryIds } = input;
    const expected = baseline.failedRequestCount;
    const actual = current.failedRequestCount;

    if (actual < FAILED_REQUEST_THRESHOLDS.warning) {
      return [];
    }

    const severity: AnomalySeverity =
      actual >= FAILED_REQUEST_THRESHOLDS.critical ? 'critical' : 'high';
    const deviation = expected > 0 ? ((actual - expected) / expected) * 100 : 100;

    const anomaly: Anomaly = {
      id: `anomaly-${serviceId}-failed-requests-${uuidv4()}`,
      timestamp,
      serviceId,
      metric: 'failed_request_count',
      expectedValue: expected,
      actualValue: actual,
      deviation: Math.round(deviation),
      severity,
      description: `${serviceId} has a sudden increase in failed requests (expected ~${expected}, observed ${actual}).`,
      relatedTelemetryIds,
    };

    return [anomaly];
  }
}
