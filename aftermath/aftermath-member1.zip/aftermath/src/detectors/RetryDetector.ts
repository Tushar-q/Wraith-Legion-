import { v4 as uuidv4 } from 'uuid';
import { Anomaly, AnomalyDetector, AnomalySeverity, DetectionInput } from '../types';
import { MIN_ANOMALY_DEVIATION_PERCENT, RETRY_THRESHOLDS } from '../config/thresholds';

export class RetryDetector implements AnomalyDetector {
  name = 'RetryDetector';

  detect(input: DetectionInput): Anomaly[] {
    const { serviceId, timestamp, baseline, current, relatedTelemetryIds } = input;
    const expected = baseline.retryCount;
    const actual = current.retryCount;

    if (actual < RETRY_THRESHOLDS.warning) {
      return [];
    }

    const deviation = expected > 0 ? ((actual - expected) / expected) * 100 : actual > 0 ? 100 : 0;
    if (deviation < MIN_ANOMALY_DEVIATION_PERCENT) {
      return [];
    }

    const severity: AnomalySeverity = actual >= RETRY_THRESHOLDS.critical ? 'critical' : 'high';

    const anomaly: Anomaly = {
      id: `anomaly-${serviceId}-retry-storm-${uuidv4()}`,
      timestamp,
      serviceId,
      metric: 'retry_count',
      expectedValue: expected,
      actualValue: actual,
      deviation: Math.round(deviation),
      severity,
      description: `${serviceId} is retrying requests far more than normal (expected ~${expected}, observed ${actual}), consistent with a retry storm.`,
      relatedTelemetryIds,
    };

    return [anomaly];
  }
}
