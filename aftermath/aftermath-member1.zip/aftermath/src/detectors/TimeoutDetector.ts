import { v4 as uuidv4 } from 'uuid';
import { Anomaly, AnomalyDetector, AnomalySeverity, DetectionInput } from '../types';
import { TIMEOUT_THRESHOLDS } from '../config/thresholds';

export class TimeoutDetector implements AnomalyDetector {
  name = 'TimeoutDetector';

  detect(input: DetectionInput): Anomaly[] {
    const { serviceId, timestamp, baseline, current, relatedTelemetryIds } = input;
    const expected = baseline.timeoutCount;
    const actual = current.timeoutCount;

    if (actual < TIMEOUT_THRESHOLDS.warning) {
      return [];
    }

    const severity: AnomalySeverity = actual >= TIMEOUT_THRESHOLDS.critical ? 'critical' : 'high';
    const deviation = expected > 0 ? ((actual - expected) / expected) * 100 : 100;

    const anomaly: Anomaly = {
      id: `anomaly-${serviceId}-timeout-${uuidv4()}`,
      timestamp,
      serviceId,
      metric: 'timeout_count',
      expectedValue: expected,
      actualValue: actual,
      deviation: Math.round(deviation),
      severity,
      description: `${serviceId} is experiencing request timeouts (expected ~${expected}, observed ${actual}), indicating downstream unavailability or an overly aggressive timeout configuration.`,
      relatedTelemetryIds,
    };

    return [anomaly];
  }
}
