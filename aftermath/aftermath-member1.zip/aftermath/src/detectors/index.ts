import { Anomaly, AnomalyDetector, DetectionInput } from '../types';
import { LatencyDetector } from './LatencyDetector';
import { ErrorRateDetector } from './ErrorRateDetector';
import { RetryDetector } from './RetryDetector';
import { TimeoutDetector } from './TimeoutDetector';
import { RequestFailureDetector } from './RequestFailureDetector';

export { LatencyDetector } from './LatencyDetector';
export { ErrorRateDetector } from './ErrorRateDetector';
export { RetryDetector } from './RetryDetector';
export { TimeoutDetector } from './TimeoutDetector';
export { RequestFailureDetector } from './RequestFailureDetector';

/**
 * Runs the full set of rule-based anomaly detectors against a given
 * detection input and returns every anomaly found. Deliberately
 * simple/rule-based (no ML) so the demo is deterministic and every
 * anomaly is explainable.
 */
export class AnomalyDetectionEngine {
  private detectors: AnomalyDetector[];

  constructor(detectors?: AnomalyDetector[]) {
    this.detectors = detectors ?? [
      new LatencyDetector(),
      new ErrorRateDetector(),
      new RetryDetector(),
      new TimeoutDetector(),
      new RequestFailureDetector(),
    ];
  }

  run(input: DetectionInput): Anomaly[] {
    return this.detectors.flatMap((detector) => detector.detect(input));
  }
}
