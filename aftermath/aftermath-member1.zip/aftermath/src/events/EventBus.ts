import { EventEmitter } from 'events';
import { EventMessage } from '../types';

/**
 * Lightweight internal pub/sub used across the module. Wraps Node's
 * built-in EventEmitter so we get a typed publish() helper and a
 * consistent EventMessage envelope, without introducing a message
 * broker like Kafka (explicitly out of scope for the hackathon).
 */
export class EventBus {
  private emitter = new EventEmitter();

  constructor() {
    // Telemetry/anomaly volume can be high during a fast-forwarded
    // simulation; raise the default listener cap to avoid noisy warnings.
    this.emitter.setMaxListeners(50);
  }

  publish<T>(eventType: string, data: T): void {
    const message: EventMessage<T> = {
      eventType,
      timestamp: new Date().toISOString(),
      data,
    };
    this.emitter.emit(eventType, message);
    this.emitter.emit('*', message);
  }

  subscribe<T>(eventType: string, handler: (message: EventMessage<T>) => void): () => void {
    this.emitter.on(eventType, handler);
    return () => this.emitter.off(eventType, handler);
  }

  /** Subscribe to every event published on this bus. */
  subscribeAll(handler: (message: EventMessage<unknown>) => void): () => void {
    this.emitter.on('*', handler);
    return () => this.emitter.off('*', handler);
  }

  removeAllListeners(): void {
    this.emitter.removeAllListeners();
  }
}

/** Shared singleton instance used across the module. */
export const eventBus = new EventBus();
