/**
 * Canonical list of internal event names published on the EventBus.
 * Other modules (Members 2/3/4) can subscribe to these to react to
 * telemetry, anomalies, health changes, incidents, and simulator
 * lifecycle changes without polling the APIs.
 */
export const EVENT_TYPES = {
  TELEMETRY_RECEIVED: 'telemetry.received',
  ANOMALY_DETECTED: 'anomaly.detected',
  SERVICE_HEALTH_CHANGED: 'service.health.changed',
  INCIDENT_CREATED: 'incident.created',
  INCIDENT_UPDATED: 'incident.updated',
  DEMO_STARTED: 'demo.started',
  DEMO_STEP_COMPLETED: 'demo.step.completed',
  DEMO_RESET: 'demo.reset',
  DEMO_PAUSED: 'demo.paused',
  DEMO_RESUMED: 'demo.resumed',
} as const;

export type EventTypeValue = (typeof EVENT_TYPES)[keyof typeof EVENT_TYPES];
