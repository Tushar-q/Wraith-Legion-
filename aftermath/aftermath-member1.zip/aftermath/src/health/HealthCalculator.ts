import { Service, ServiceHealth, ServiceStatus } from '../types';
import { ServiceBaseline } from '../config/baselines';
import {
  ERROR_RATE_THRESHOLDS,
  HEALTH_SCORE,
  LATENCY_THRESHOLDS,
  RETRY_THRESHOLDS,
  TIMEOUT_THRESHOLDS,
  FAILED_REQUEST_THRESHOLDS,
} from '../config/thresholds';

/**
 * Rule-based health scoring. Starts every service at 100 and applies
 * explainable penalties for each abnormal signal observed. Deliberately
 * simple (no ML) so scores are reproducible and easy to justify in a
 * demo or to downstream consumers (Members 2/3/4).
 */
export class HealthCalculator {
  static calculate(service: Service, baseline: ServiceBaseline, timestamp: string): ServiceHealth {
    let score = HEALTH_SCORE.initial;
    const factors: string[] = [];

    // Latency
    if (service.latency >= LATENCY_THRESHOLDS.criticalMs) {
      score -= HEALTH_SCORE.penalties.criticalLatency;
      factors.push('Critical latency detected');
    } else if (service.latency >= LATENCY_THRESHOLDS.warningMs) {
      score -= HEALTH_SCORE.penalties.warningLatency;
      factors.push('Elevated latency detected');
    }

    // Error rate
    if (service.errorRate >= ERROR_RATE_THRESHOLDS.critical) {
      score -= HEALTH_SCORE.penalties.highErrorRate;
      factors.push('High error rate');
    } else if (service.errorRate >= ERROR_RATE_THRESHOLDS.warning) {
      score -= HEALTH_SCORE.penalties.warningErrorRate;
      factors.push('Elevated error rate');
    }

    // Timeouts
    if (service.timeoutCount >= TIMEOUT_THRESHOLDS.critical) {
      score -= HEALTH_SCORE.penalties.timeoutSpike;
      factors.push('Timeout spike');
    } else if (service.timeoutCount >= TIMEOUT_THRESHOLDS.warning) {
      score -= HEALTH_SCORE.penalties.warningTimeouts;
      factors.push('Elevated timeouts');
    }

    // Retries
    if (service.retryCount >= RETRY_THRESHOLDS.critical) {
      score -= HEALTH_SCORE.penalties.retryStorm;
      factors.push('Retry storm detected');
    } else if (service.retryCount >= RETRY_THRESHOLDS.warning) {
      score -= HEALTH_SCORE.penalties.warningRetries;
      factors.push('Elevated retries');
    }

    // Failed requests
    if (service.failedRequestCount >= FAILED_REQUEST_THRESHOLDS.warning) {
      score -= HEALTH_SCORE.penalties.failedRequests;
      factors.push('Increased failed requests');
    }

    score = Math.max(0, Math.min(100, Math.round(score)));

    const status = HealthCalculator.scoreToStatus(score);

    if (factors.length === 0) {
      factors.push('All signals within normal baseline');
    }

    return {
      serviceId: service.id,
      score,
      status,
      factors,
      timestamp,
    };
  }

  static scoreToStatus(score: number): ServiceStatus {
    if (score >= HEALTH_SCORE.statusBands.healthyMin) return 'healthy';
    if (score >= HEALTH_SCORE.statusBands.degradedMin) return 'degraded';
    return 'critical';
  }
}
