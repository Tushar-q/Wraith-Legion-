import { Anomaly, ServiceDependency } from '../types';

export interface IncidentCandidate {
  affectedServices: string[];
  anomalyIds: string[];
  triggeringRules: string[];
}

/**
 * Groups related anomalies into a candidate incident using simple,
 * explainable rules. This module ONLY decides "is this collection of
 * anomalies significant enough to be an incident, and which services
 * does it touch" - it does NOT determine root cause or causal chain
 * (that is Member 2's responsibility).
 */
export class IncidentDetector {
  constructor(private dependencies: ServiceDependency[]) {}

  /**
   * Evaluate the current set of active anomalies and decide whether
   * they should be grouped into an incident.
   *
   * Rules:
   *  1. A single critical anomaly is a strong signal on its own.
   *  2. Two or more high-or-above anomalies on the same service indicate an incident.
   *  3. Anomalies across multiple *dependency-connected* services indicate a broader incident.
   *  4. User impact (passed in by the caller) escalates any existing candidate.
   */
  evaluate(activeAnomalies: Anomaly[], userImpactDetected: boolean): IncidentCandidate | null {
    if (activeAnomalies.length === 0) {
      return null;
    }

    const triggeringRules: string[] = [];
    const criticalAnomalies = activeAnomalies.filter((a) => a.severity === 'critical');
    const highOrAbove = activeAnomalies.filter((a) => a.severity === 'high' || a.severity === 'critical');

    const affectedServiceIds = new Set(activeAnomalies.map((a) => a.serviceId));

    let triggered = false;

    if (criticalAnomalies.length >= 1) {
      triggered = true;
      triggeringRules.push('RULE_1_CRITICAL_ANOMALY');
    }

    const byService = groupBy(highOrAbove, (a) => a.serviceId);
    for (const [, anomalies] of byService) {
      if (anomalies.length >= 2) {
        triggered = true;
        triggeringRules.push('RULE_2_MULTIPLE_HIGH_SEVERITY_SAME_SERVICE');
        break;
      }
    }

    const connectedServiceGroups = this.groupByDependencyConnectivity([...affectedServiceIds]);
    const largestGroup = connectedServiceGroups.reduce(
      (max, group) => (group.length > max.length ? group : max),
      [] as string[]
    );
    if (largestGroup.length >= 2 && highOrAbove.length >= 2) {
      triggered = true;
      triggeringRules.push('RULE_3_MULTI_SERVICE_DEPENDENCY_SPREAD');
    }

    if (!triggered) {
      return null;
    }

    if (userImpactDetected) {
      triggeringRules.push('RULE_4_USER_IMPACT');
    }

    if (affectedServiceIds.size >= 2) {
      triggeringRules.push('RULE_5_BROAD_INCIDENT_MULTIPLE_SERVICES');
    }

    return {
      affectedServices: largestGroup.length >= 2 ? largestGroup : [...affectedServiceIds],
      anomalyIds: activeAnomalies.map((a) => a.id),
      triggeringRules,
    };
  }

  /**
   * Groups the given service ids into connected components using the
   * (undirected) dependency graph, so anomalies on services that call
   * each other are recognized as part of the same spreading incident.
   */
  private groupByDependencyConnectivity(serviceIds: string[]): string[][] {
    const adjacency = new Map<string, Set<string>>();
    for (const id of serviceIds) adjacency.set(id, new Set());

    for (const dep of this.dependencies) {
      if (adjacency.has(dep.source) && adjacency.has(dep.target)) {
        adjacency.get(dep.source)!.add(dep.target);
        adjacency.get(dep.target)!.add(dep.source);
      }
    }

    const visited = new Set<string>();
    const groups: string[][] = [];

    for (const id of serviceIds) {
      if (visited.has(id)) continue;
      const group: string[] = [];
      const stack = [id];
      while (stack.length) {
        const current = stack.pop()!;
        if (visited.has(current)) continue;
        visited.add(current);
        group.push(current);
        for (const neighbor of adjacency.get(current) ?? []) {
          if (!visited.has(neighbor)) stack.push(neighbor);
        }
      }
      groups.push(group);
    }

    return groups;
  }
}

function groupBy<T, K>(items: T[], keyFn: (item: T) => K): Map<K, T[]> {
  const map = new Map<K, T[]>();
  for (const item of items) {
    const key = keyFn(item);
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(item);
  }
  return map;
}
