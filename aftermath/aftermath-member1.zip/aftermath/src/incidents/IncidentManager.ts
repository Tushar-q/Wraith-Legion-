import { Anomaly, Incident, ServiceDependency } from '../types';
import { IncidentDetector } from './IncidentDetector';
import { SeverityCalculator } from './SeverityCalculator';
import { eventBus } from '../events/EventBus';
import { EVENT_TYPES } from '../events/EventTypes';

/**
 * Owns the lifecycle of Incident records: evaluating whether the
 * current anomaly set warrants (creating or updating) an incident,
 * and storing incidents in memory.
 *
 * Deliberately does NOT determine root cause - only detects that
 * *something* is wrong, which services are affected, and how severe
 * it looks based on explainable rules.
 */
export class IncidentManager {
  private incidents: Map<string, Incident> = new Map();
  private detector: IncidentDetector;

  constructor(dependencies: ServiceDependency[]) {
    this.detector = new IncidentDetector(dependencies);
  }

  /**
   * Re-evaluate incident state given the current active anomalies.
   * If a forcedId/forcedTitle is supplied (used by the deterministic
   * demo scenario) it will be used when creating a brand-new incident;
   * otherwise an id is generated.
   */
  evaluate(
    activeAnomalies: Anomaly[],
    userImpactDetected: boolean,
    timestamp: string,
    options?: { forcedId?: string; forcedTitle?: string; forcedDescription?: string }
  ): Incident | null {
    const candidate = this.detector.evaluate(activeAnomalies, userImpactDetected);
    if (!candidate) {
      return null;
    }

    const anomaliesInCandidate = activeAnomalies.filter((a) => candidate.anomalyIds.includes(a.id));
    const severityResult = SeverityCalculator.calculate(
      anomaliesInCandidate,
      candidate.affectedServices.length,
      userImpactDetected
    );

    const existing = options?.forcedId ? this.incidents.get(options.forcedId) : this.findOpenIncidentFor(candidate.affectedServices);

    if (existing) {
      existing.severity = severityResult.severity;
      existing.affectedServices = Array.from(
        new Set([...existing.affectedServices, ...candidate.affectedServices])
      );
      existing.anomalyIds = Array.from(new Set([...existing.anomalyIds, ...candidate.anomalyIds]));
      eventBus.publish(EVENT_TYPES.INCIDENT_UPDATED, { incident: existing });
      return existing;
    }

    const id = options?.forcedId ?? `INC-${String(this.incidents.size + 1).padStart(3, '0')}`;
    const title = options?.forcedTitle ?? 'Multi-Service Anomaly Incident';
    const description =
      options?.forcedDescription ??
      `Multiple services are experiencing related failures. ${severityResult.reasons.join('; ')}.`;

    const incident: Incident = {
      id,
      title,
      severity: severityResult.severity,
      status: 'detected',
      detectedAt: timestamp,
      startTime: timestamp,
      affectedServices: candidate.affectedServices,
      anomalyIds: candidate.anomalyIds,
      description,
    };

    this.incidents.set(id, incident);
    eventBus.publish(EVENT_TYPES.INCIDENT_CREATED, { incident });
    return incident;
  }

  private findOpenIncidentFor(affectedServices: string[]): Incident | undefined {
    for (const incident of this.incidents.values()) {
      if (incident.status !== 'resolved' && incident.affectedServices.some((s) => affectedServices.includes(s))) {
        return incident;
      }
    }
    return undefined;
  }

  getAll(): Incident[] {
    return [...this.incidents.values()];
  }

  getActive(): Incident[] {
    return this.getAll().filter((i) => i.status !== 'resolved');
  }

  getById(id: string): Incident | undefined {
    return this.incidents.get(id);
  }

  reset(): void {
    this.incidents.clear();
  }
}
