import { Anomaly, IncidentSeverity, SeverityResult } from '../types';
import { SEVERITY_SCORING } from '../config/thresholds';

/**
 * Explainable, rule-based incident severity scoring. Every point
 * awarded is accompanied by a human-readable reason so the score can
 * be justified to a user or to Member 3's AI reasoning layer.
 */
export class SeverityCalculator {
  static calculate(
    anomalies: Anomaly[],
    affectedServiceCount: number,
    userImpactDetected: boolean
  ): SeverityResult {
    let score = 0;
    const reasons: string[] = [];

    const counts: Record<Anomaly['severity'], number> = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
    };
    for (const anomaly of anomalies) {
      counts[anomaly.severity] += 1;
    }

    if (counts.critical > 0) {
      score += counts.critical * SEVERITY_SCORING.anomalyPoints.critical;
      reasons.push(
        `${counts.critical} critical anomal${counts.critical === 1 ? 'y' : 'ies'} detected`
      );
    }
    if (counts.high > 0) {
      score += counts.high * SEVERITY_SCORING.anomalyPoints.high;
      reasons.push(`${counts.high} high severity anomal${counts.high === 1 ? 'y' : 'ies'} detected`);
    }
    if (counts.medium > 0) {
      score += counts.medium * SEVERITY_SCORING.anomalyPoints.medium;
      reasons.push(`${counts.medium} medium severity anomalies detected`);
    }
    if (counts.low > 0) {
      score += counts.low * SEVERITY_SCORING.anomalyPoints.low;
      reasons.push(`${counts.low} low severity anomalies detected`);
    }

    if (affectedServiceCount > 1) {
      score += SEVERITY_SCORING.multipleServicesBonus;
      reasons.push(`${affectedServiceCount} services affected`);
    }

    if (userImpactDetected) {
      score += SEVERITY_SCORING.userImpactBonus;
      reasons.push('User impact detected');
    }

    const severity = SeverityCalculator.scoreToSeverity(score);

    return { severity, score, reasons };
  }

  static scoreToSeverity(score: number): IncidentSeverity {
    const { lowMax, mediumMax, highMax } = SEVERITY_SCORING.bands;
    if (score <= lowMax) return 'low';
    if (score <= mediumMax) return 'medium';
    if (score <= highMax) return 'high';
    return 'critical';
  }
}
