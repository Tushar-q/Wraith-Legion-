import { createApp } from './app';
import { engine } from './services/context';

const PORT = process.env.PORT ? Number(process.env.PORT) : 4000;

const app = createApp(engine);

app.listen(PORT, () => {
  console.log(`AFTERMATH Member 1 module listening on http://localhost:${PORT}`);
  console.log(`Health check:      GET  http://localhost:${PORT}/health`);
  console.log(`API root:          GET  http://localhost:${PORT}/api/system`);
  console.log(`Start simulation:  POST http://localhost:${PORT}/api/demo/start`);
});
