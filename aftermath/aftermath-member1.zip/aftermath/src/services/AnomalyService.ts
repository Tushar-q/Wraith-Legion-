import { Anomaly } from '../types';
import { IncidentSimulator } from '../simulator/IncidentSimulator';

/**
 * Facade over anomalies detected by the simulator, for
 * GET /api/anomalies and GET /api/anomalies/:id.
 */
export class AnomalyService {
  constructor(private simulator: IncidentSimulator) {}

  list(filters?: { serviceId?: string; severity?: Anomaly['severity'] }): Anomaly[] {
    let anomalies = this.simulator.getAnomalies();
    if (filters?.serviceId) {
      anomalies = anomalies.filter((a) => a.serviceId === filters.serviceId);
    }
    if (filters?.severity) {
      anomalies = anomalies.filter((a) => a.severity === filters.severity);
    }
    return anomalies;
  }

  getById(id: string): Anomaly | undefined {
    return this.simulator.getAnomalies().find((a) => a.id === id);
  }
}
