import { DemoState } from '../types';
import { IncidentSimulator } from '../simulator/IncidentSimulator';

/**
 * Thin facade over IncidentSimulator's control surface, used by the
 * demo control API routes (start/pause/resume/next/reset/state).
 * Keeping this separate from the simulator itself means the HTTP
 * layer never touches simulator internals directly.
 */
export class DemoService {
  constructor(private simulator: IncidentSimulator) {}

  start(): DemoState {
    return this.simulator.start();
  }

  pause(): DemoState {
    return this.simulator.pause();
  }

  resume(): DemoState {
    return this.simulator.resume();
  }

  next(): DemoState {
    return this.simulator.nextStep();
  }

  previous(): DemoState {
    return this.simulator.previousStep();
  }

  reset(): DemoState {
    return this.simulator.reset();
  }

  getState(): DemoState {
    return this.simulator.getState();
  }
}
