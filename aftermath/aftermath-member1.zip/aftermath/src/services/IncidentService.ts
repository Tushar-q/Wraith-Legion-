import {
  Anomaly,
  Incident,
  Log,
  Service,
  ServiceDependency,
  ServiceHealthEvent,
  SystemEvent,
  TelemetryEvent,
  Trace,
} from '../types';
import { IncidentSimulator } from '../simulator/IncidentSimulator';
import { TelemetryStore } from '../telemetry/TelemetryStore';

/**
 * ============================================================
 * CRITICAL INTEGRATION CONTRACT - Member 2 (causal analysis)
 * ============================================================
 * getIncidentContext() bundles everything Member 2 needs to
 * investigate an incident without manually collecting data from
 * multiple places: the incident record, its anomalies, the affected
 * services (with current health), all related telemetry, traces,
 * system events, health history, and the dependency graph.
 *
 * ============================================================
 * DATA CONTRACT - Member 3 (AI reasoning)
 * ============================================================
 * getIncidentSummary() / getServiceSummary() / getImportantEvents() /
 * getAnomalySummary() return compact, evidence-oriented summaries
 * (not raw firehoses) suitable for passing into an LLM prompt. None
 * of these functions state a definitive root cause - they present
 * evidence only.
 */
export interface IncidentContext {
  incident: Incident;
  anomalies: Anomaly[];
  affectedServices: Service[];
  telemetry: TelemetryEvent[];
  traces: Trace[];
  events: SystemEvent[];
  healthHistory: ServiceHealthEvent[];
  dependencies: ServiceDependency[];
}

export interface IncidentSummary {
  id: string;
  title: string;
  severity: string;
  status: string;
  detectedAt: string;
  startTime: string;
  affectedServices: string[];
  anomalyCount: number;
  criticalAnomalyCount: number;
  configurationChanges: { description: string; timestamp: string }[];
  narrative: string;
}

export interface ServiceSummary {
  serviceId: string;
  name: string;
  status: string;
  healthScore: number;
  healthFactors: string[];
  currentLatency: number;
  currentErrorRate: number;
  currentRetryCount: number;
  currentTimeoutCount: number;
  dependsOn: string[];
  dependedOnBy: string[];
  recentAnomalyCount: number;
}

export interface AnomalySummary {
  totalAnomalies: number;
  bySeverity: Record<Anomaly['severity'], number>;
  byService: Record<string, number>;
  mostSevere: Anomaly[];
}

export class IncidentService {
  constructor(private simulator: IncidentSimulator, private store: TelemetryStore) {}

  list(): Incident[] {
    return this.simulator.getIncidents();
  }

  listActive(): Incident[] {
    return this.simulator.getActiveIncidents();
  }

  getById(id: string): Incident | undefined {
    return this.simulator.getIncidentById(id);
  }

  /** Member 2's primary entry point. */
  getIncidentContext(incidentId: string): IncidentContext | null {
    const incident = this.simulator.getIncidentById(incidentId);
    if (!incident) return null;

    const anomalies = this.simulator
      .getAnomalies()
      .filter((a) => incident.anomalyIds.includes(a.id));

    const affectedServices = incident.affectedServices
      .map((id) => this.simulator.getService(id))
      .filter((s): s is Service => Boolean(s));

    const telemetry = this.store.getRelatedTelemetry(
      incident.affectedServices,
      undefined,
      undefined
    );

    const traces = this.store
      .getTraces()
      .filter((t) => t.spans.some((s) => incident.affectedServices.includes(s.serviceId)));

    const events = this.store
      .getSystemEvents()
      .filter((e) => !e.serviceId || incident.affectedServices.includes(e.serviceId));

    const healthHistory = this.store
      .getHealthHistory()
      .filter((h) => incident.affectedServices.includes(h.serviceId));

    const dependencies = this.simulator
      .getDependencies()
      .filter(
        (d) => incident.affectedServices.includes(d.source) || incident.affectedServices.includes(d.target)
      );

    return {
      incident,
      anomalies,
      affectedServices,
      telemetry,
      traces,
      events,
      healthHistory,
      dependencies,
    };
  }

  /** Member 3's evidence-oriented incident summary. No root-cause claims. */
  getIncidentSummary(incidentId: string): IncidentSummary | null {
    const context = this.getIncidentContext(incidentId);
    if (!context) return null;
    const { incident, anomalies } = context;

    const configurationChanges = context.events
      .filter((e) => e.type === 'configuration_changed')
      .map((e) => ({ description: e.description, timestamp: e.timestamp }));

    const criticalAnomalyCount = anomalies.filter((a) => a.severity === 'critical').length;

    const narrative =
      `Incident ${incident.id} (${incident.title}) was detected at ${incident.detectedAt} ` +
      `affecting ${incident.affectedServices.join(', ')}. ${anomalies.length} anomalies were recorded ` +
      `(${criticalAnomalyCount} critical). ${configurationChanges.length} configuration change(s) were preserved as evidence. ` +
      `This summary presents detected evidence only; root cause has not been determined.`;

    return {
      id: incident.id,
      title: incident.title,
      severity: incident.severity,
      status: incident.status,
      detectedAt: incident.detectedAt,
      startTime: incident.startTime,
      affectedServices: incident.affectedServices,
      anomalyCount: anomalies.length,
      criticalAnomalyCount,
      configurationChanges,
      narrative,
    };
  }

  getServiceSummary(serviceId: string): ServiceSummary | null {
    const service = this.simulator.getService(serviceId);
    if (!service) return null;
    const health = this.simulator.getServiceHealth(serviceId);
    const dependencies = this.simulator.getDependencies();

    return {
      serviceId: service.id,
      name: service.name,
      status: service.status,
      healthScore: service.healthScore,
      healthFactors: health?.factors ?? [],
      currentLatency: service.latency,
      currentErrorRate: service.errorRate,
      currentRetryCount: service.retryCount,
      currentTimeoutCount: service.timeoutCount,
      dependsOn: dependencies.filter((d) => d.source === serviceId).map((d) => d.target),
      dependedOnBy: dependencies.filter((d) => d.target === serviceId).map((d) => d.source),
      recentAnomalyCount: this.simulator.getAnomalies().filter((a) => a.serviceId === serviceId).length,
    };
  }

  /** Important, evidence-worthy events for an incident: config changes, degradation, user impact. */
  getImportantEvents(incidentId: string): SystemEvent[] {
    const context = this.getIncidentContext(incidentId);
    if (!context) return [];
    const importantTypes = new Set([
      'configuration_changed',
      'service_degraded',
      'timeout_detected',
      'user_impact_detected',
      'circuit_breaker_opened',
    ]);
    return context.events.filter((e) => importantTypes.has(e.type));
  }

  getAnomalySummary(incidentId: string): AnomalySummary | null {
    const context = this.getIncidentContext(incidentId);
    if (!context) return null;

    const bySeverity: Record<Anomaly['severity'], number> = { low: 0, medium: 0, high: 0, critical: 0 };
    const byService: Record<string, number> = {};

    for (const anomaly of context.anomalies) {
      bySeverity[anomaly.severity] += 1;
      byService[anomaly.serviceId] = (byService[anomaly.serviceId] ?? 0) + 1;
    }

    const mostSevere = [...context.anomalies]
      .sort((a, b) => severityRank(b.severity) - severityRank(a.severity))
      .slice(0, 5);

    return {
      totalAnomalies: context.anomalies.length,
      bySeverity,
      byService,
      mostSevere,
    };
  }

  /** Convenience: recent important logs for an incident (errors/critical only), for Member 3. */
  getImportantLogs(incidentId: string): Log[] {
    const context = this.getIncidentContext(incidentId);
    if (!context) return [];
    return context.telemetry
      .filter((t) => t.category === 'log' && (t.severity === 'error' || t.severity === 'critical'))
      .map((t) => t.data as unknown as Log);
  }
}

function severityRank(severity: Anomaly['severity']): number {
  switch (severity) {
    case 'critical':
      return 4;
    case 'high':
      return 3;
    case 'medium':
      return 2;
    default:
      return 1;
  }
}
