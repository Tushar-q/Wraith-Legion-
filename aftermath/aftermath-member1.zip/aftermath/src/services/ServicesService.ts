import { Anomaly, Metric, Service, ServiceDependency, ServiceHealth } from '../types';
import { IncidentSimulator } from '../simulator/IncidentSimulator';
import { TelemetryStore } from '../telemetry/TelemetryStore';

export interface ServiceListItem extends Service {
  health: ServiceHealth | undefined;
}

export interface ServiceDetail {
  service: Service;
  health: ServiceHealth | undefined;
  dependencies: {
    dependsOn: string[];
    dependedOnBy: string[];
  };
  recentAnomalies: Anomaly[];
  recentMetrics: Metric[];
}

/**
 * Facade over the simulator's service state + dependency graph for
 * GET /api/services and GET /api/services/:serviceId.
 */
export class ServicesService {
  constructor(private simulator: IncidentSimulator, private store: TelemetryStore) {}

  listServices(): ServiceListItem[] {
    return this.simulator.getServices().map((service) => ({
      ...service,
      health: this.simulator.getServiceHealth(service.id),
    }));
  }

  getServiceDetail(serviceId: string): ServiceDetail | null {
    const service = this.simulator.getService(serviceId);
    if (!service) return null;

    const dependencies = this.simulator.getDependencies();
    const dependsOn = dependencies.filter((d) => d.source === serviceId).map((d) => d.target);
    const dependedOnBy = dependencies.filter((d) => d.target === serviceId).map((d) => d.source);

    const recentAnomalies = this.simulator
      .getAnomalies()
      .filter((a) => a.serviceId === serviceId)
      .slice(-10);

    const recentMetrics = this.store.getMetrics(serviceId).slice(-20);

    return {
      service,
      health: this.simulator.getServiceHealth(serviceId),
      dependencies: { dependsOn, dependedOnBy },
      recentAnomalies,
      recentMetrics,
    };
  }

  getDependencyGraph(): ServiceDependency[] {
    return this.simulator.getDependencies();
  }
}
