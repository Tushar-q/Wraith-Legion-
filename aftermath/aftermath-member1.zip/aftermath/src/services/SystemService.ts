import { IncidentSimulator } from '../simulator/IncidentSimulator';
import { TelemetryStore } from '../telemetry/TelemetryStore';

export interface SystemSummary {
  overallStatus: 'healthy' | 'degraded' | 'critical';
  serviceCount: number;
  healthyServiceCount: number;
  degradedServiceCount: number;
  criticalServiceCount: number;
  activeIncidentCount: number;
  totalAnomalyCount: number;
  totalTelemetryCount: number;
  simulation: {
    status: string;
    currentStep: number;
    totalSteps: number;
    currentStepName: string;
  };
}

/**
 * Provides a single, frontend-friendly snapshot of overall system
 * state (GET /api/system).
 */
export class SystemService {
  constructor(private simulator: IncidentSimulator, private store: TelemetryStore) {}

  getSummary(): SystemSummary {
    const services = this.simulator.getServices();
    const healthy = services.filter((s) => s.status === 'healthy').length;
    const degraded = services.filter((s) => s.status === 'degraded').length;
    const critical = services.filter((s) => s.status === 'critical').length;

    const overallStatus: SystemSummary['overallStatus'] =
      critical > 0 ? 'critical' : degraded > 0 ? 'degraded' : 'healthy';

    const state = this.simulator.getState();

    return {
      overallStatus,
      serviceCount: services.length,
      healthyServiceCount: healthy,
      degradedServiceCount: degraded,
      criticalServiceCount: critical,
      activeIncidentCount: this.simulator.getActiveIncidents().length,
      totalAnomalyCount: this.simulator.getAnomalies().length,
      totalTelemetryCount: this.store.getTelemetry().length,
      simulation: {
        status: state.status,
        currentStep: state.currentStep,
        totalSteps: state.totalSteps,
        currentStepName: state.currentStepName,
      },
    };
  }
}
