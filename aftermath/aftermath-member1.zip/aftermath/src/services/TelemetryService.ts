import { TelemetryCategory, TelemetryEvent } from '../types';
import { TelemetryStore } from '../telemetry/TelemetryStore';

export interface TelemetryQuery {
  serviceId?: string;
  category?: TelemetryCategory;
  startTime?: string;
  endTime?: string;
  traceId?: string;
  limit?: number;
}

/**
 * Query facade over TelemetryStore for GET /api/telemetry. Combines
 * filters (service/category/time-range/trace) the way the API needs,
 * while keeping the store itself simple and general-purpose.
 */
export class TelemetryService {
  constructor(private store: TelemetryStore) {}

  query(query: TelemetryQuery): TelemetryEvent[] {
    let results = this.store.getTelemetry();

    if (query.traceId) {
      results = results.filter((t) => t.traceId === query.traceId);
    }
    if (query.serviceId) {
      results = results.filter((t) => t.serviceId === query.serviceId);
    }
    if (query.category) {
      results = results.filter((t) => t.category === query.category);
    }
    if (query.startTime && query.endTime) {
      const start = new Date(query.startTime).getTime();
      const end = new Date(query.endTime).getTime();
      results = results.filter((t) => {
        const ts = new Date(t.timestamp).getTime();
        return ts >= start && ts <= end;
      });
    }

    if (query.limit && query.limit > 0) {
      results = results.slice(-query.limit);
    }

    return results;
  }

  getLogs(serviceId?: string) {
    return this.store.getLogs(serviceId);
  }

  getMetrics(serviceId?: string) {
    return this.store.getMetrics(serviceId);
  }

  getSystemEvents(serviceId?: string) {
    return this.store.getSystemEvents(serviceId);
  }

  getTraces(serviceId?: string) {
    return this.store.getTraces(serviceId);
  }

  getTraceById(traceId: string) {
    return this.store.getTraceById(traceId);
  }

  getHealthHistory(serviceId?: string) {
    return this.store.getHealthHistory(serviceId);
  }
}
