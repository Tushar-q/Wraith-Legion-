import { TelemetryStore } from '../telemetry/TelemetryStore';
import { IncidentSimulator } from '../simulator/IncidentSimulator';

/**
 * Shared singleton wiring for the whole module. The store and
 * simulator are created once here and injected into every Service
 * facade, so the API layer, tests, and (eventually) other members'
 * modules all observe the same state.
 *
 * Keeping this in one small file makes it trivial to swap in a
 * different storage backend or multiple isolated simulator instances
 * later (e.g. per-session demos) without touching business logic.
 */
export class AftermathEngine {
  readonly store: TelemetryStore;
  readonly simulator: IncidentSimulator;

  constructor() {
    this.store = new TelemetryStore();
    this.simulator = new IncidentSimulator(this.store);
  }
}

export const engine = new AftermathEngine();
