/**
 * Deterministic definition of the primary demo scenario:
 * "PAYMENT FAILURE PROPAGATION" (incident INC-042).
 *
 * This file only describes *what* happens at each step (target metric
 * values, which logs/events to emit). The actual telemetry objects are
 * built by TelemetryGenerator and applied to services/store by
 * IncidentSimulator. Keeping the scenario data-only makes it easy to
 * reason about, and easy to add a second scenario later without
 * touching the simulator engine.
 */

export interface ScenarioStep {
  index: number;
  name: string;
  description: string;
}

export const SCENARIO_ID = 'payment-failure-propagation';
export const SCENARIO_INCIDENT_ID = 'INC-042';
export const SCENARIO_INCIDENT_TITLE = 'Payment Failure Propagation';

export const SCENARIO_STEPS: ScenarioStep[] = [
  { index: 0, name: 'HEALTHY_SYSTEM', description: 'All services healthy. No active incident.' },
  {
    index: 1,
    name: 'CONFIGURATION_CHANGE',
    description: 'Payment Service timeout configuration changes from 5000ms to 500ms.',
  },
  {
    index: 2,
    name: 'PAYMENT_LATENCY_SPIKE',
    description: 'Payment Service latency climbs from baseline toward 4500ms.',
  },
  {
    index: 3,
    name: 'PAYMENT_TIMEOUTS',
    description: 'Payment requests begin timing out; failed traces recorded.',
  },
  {
    index: 4,
    name: 'ORDER_RETRY_STORM',
    description: 'Order Service retries Payment Service aggressively (up to 150 retries).',
  },
  {
    index: 5,
    name: 'ORDER_SERVICE_DEGRADATION',
    description: 'Order Service degrades due to load from repeated retries.',
  },
  {
    index: 6,
    name: 'API_GATEWAY_ERRORS',
    description: 'API Gateway begins returning 5xx errors and higher latency.',
  },
  {
    index: 7,
    name: 'USER_IMPACT',
    description: 'User-visible checkout/order failures are detected.',
  },
  {
    index: 8,
    name: 'INCIDENT_CREATED',
    description: 'INC-042 "Payment Failure Propagation" is created (critical, detected).',
  },
];

export const TOTAL_STEPS = SCENARIO_STEPS.length;

/**
 * Deterministic progression of Payment Service latency (ms) across
 * step 2, in the order they should be emitted.
 */
export const PAYMENT_LATENCY_PROGRESSION = [500, 1500, 3000, 4500];

/** Deterministic progression of Order Service retry counts across step 4. */
export const ORDER_RETRY_PROGRESSION = [20, 50, 100, 150];

export const CONFIG_CHANGE = {
  service: 'payment-service',
  key: 'payment.timeout_ms',
  previousValue: 5000,
  newValue: 500,
};
