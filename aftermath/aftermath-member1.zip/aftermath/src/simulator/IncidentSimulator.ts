import {
  Anomaly,
  DemoState,
  DetectionInput,
  Incident,
  Service,
  ServiceHealth,
  ServiceHealthEvent,
  SimulationStatus,
} from '../types';
import { TelemetryStore } from '../telemetry/TelemetryStore';
import { TelemetryGenerator } from '../telemetry/TelemetryGenerator';
import { AnomalyDetectionEngine } from '../detectors';
import { HealthCalculator } from '../health/HealthCalculator';
import { IncidentManager } from '../incidents/IncidentManager';
import { getBaseline } from '../config/baselines';
import { createInitialServices, SERVICE_DEPENDENCIES, getServiceIds } from '../config/services';
import { eventBus } from '../events/EventBus';
import { EVENT_TYPES } from '../events/EventTypes';
import {
  CONFIG_CHANGE,
  ORDER_RETRY_PROGRESSION,
  PAYMENT_LATENCY_PROGRESSION,
  SCENARIO_INCIDENT_ID,
  SCENARIO_INCIDENT_TITLE,
  SCENARIO_STEPS,
  TOTAL_STEPS,
} from './IncidentScenario';

const SIMULATION_BASE_TIME = '2026-08-29T09:00:00.000Z';

/**
 * Deterministic, replayable simulator for the "Payment Failure
 * Propagation" (INC-042) scenario. Owns simulated service state,
 * drives telemetry generation, runs anomaly detection, recomputes
 * service health, and evaluates incident creation - all in a fixed,
 * reproducible order with no reliance on real wall-clock time or
 * Math.random().
 *
 * IMPORTANT: this class is independent from the HTTP/API layer. It is
 * a plain, testable engine; routes only call its public methods.
 */
export class IncidentSimulator {
  private services: Map<string, Service> = new Map();
  private health: Map<string, ServiceHealth> = new Map();
  private anomalies: Anomaly[] = [];
  private status: SimulationStatus = 'idle';
  private currentStep = -1; // -1 = never started
  private cursorSeconds = 0;
  private userImpactDetected = false;
  private incidentManager: IncidentManager;
  private detectionEngine = new AnomalyDetectionEngine();

  constructor(private store: TelemetryStore) {
    this.incidentManager = new IncidentManager(SERVICE_DEPENDENCIES);
    this.initializeServices();
  }

  // ---------------------------------------------------------------
  // Public control surface
  // ---------------------------------------------------------------

  /** (Re)initializes simulated services to a healthy baseline state. Does not touch telemetry. */
  private initializeServices(): void {
    this.services = new Map(
      createInitialServices((serviceId) => getBaseline(serviceId), () => this.currentTimestamp()).map((s) => [
        s.id,
        s,
      ])
    );
    this.health = new Map(
      getServiceIds().map((id) => [
        id,
        { serviceId: id, score: 100, status: 'healthy' as const, factors: ['All signals within normal baseline'], timestamp: this.currentTimestamp() },
      ])
    );
  }

  /** Fully resets simulator + telemetry store + incidents to the initial idle state. */
  reset(): DemoState {
    this.status = 'idle';
    this.currentStep = -1;
    this.cursorSeconds = 0;
    this.anomalies = [];
    this.userImpactDetected = false;
    this.store.clearTelemetry();
    this.incidentManager.reset();
    this.initializeServices();
    eventBus.publish(EVENT_TYPES.DEMO_RESET, {});
    return this.getState();
  }

  /** Starts the simulation from idle. Executes step 0 (healthy baseline) immediately. */
  start(): DemoState {
    if (this.status === 'idle') {
      this.status = 'running';
      this.executeStep(0);
      eventBus.publish(EVENT_TYPES.DEMO_STARTED, { step: this.currentStep });
    } else if (this.status === 'paused') {
      this.status = 'running';
      eventBus.publish(EVENT_TYPES.DEMO_RESUMED, { step: this.currentStep });
    }
    return this.getState();
  }

  pause(): DemoState {
    if (this.status === 'running') {
      this.status = 'paused';
      eventBus.publish(EVENT_TYPES.DEMO_PAUSED, { step: this.currentStep });
    }
    return this.getState();
  }

  resume(): DemoState {
    if (this.status === 'paused') {
      this.status = 'running';
      eventBus.publish(EVENT_TYPES.DEMO_RESUMED, { step: this.currentStep });
    }
    return this.getState();
  }

  /** Advances the simulation by exactly one step, if currently running and not finished. */
  nextStep(): DemoState {
    if (this.status !== 'running') {
      return this.getState();
    }
    const target = this.currentStep + 1;
    if (target >= TOTAL_STEPS) {
      this.status = 'completed';
      return this.getState();
    }
    this.executeStep(target);
    if (target === TOTAL_STEPS - 1) {
      this.status = 'completed';
    }
    eventBus.publish(EVENT_TYPES.DEMO_STEP_COMPLETED, {
      step: target,
      name: SCENARIO_STEPS[target].name,
    });
    return this.getState();
  }

  /**
   * Rewinds to the previous step by deterministically replaying the
   * scenario from the beginning up to (target - 1). This keeps the
   * simulator's "must always produce the same logical scenario"
   * guarantee without needing bespoke inverse-step logic.
   */
  previousStep(): DemoState {
    if (this.currentStep <= 0) {
      return this.reset();
    }
    const target = this.currentStep - 1;
    this.status = 'running';
    this.currentStep = -1;
    this.cursorSeconds = 0;
    this.anomalies = [];
    this.userImpactDetected = false;
    this.store.clearTelemetry();
    this.incidentManager.reset();
    this.initializeServices();
    for (let i = 0; i <= target; i++) {
      this.executeStep(i);
    }
    this.status = target === TOTAL_STEPS - 1 ? 'completed' : 'running';
    return this.getState();
  }

  getState(): DemoState {
    const stepInfo = this.currentStep >= 0 ? SCENARIO_STEPS[this.currentStep] : SCENARIO_STEPS[0];
    return {
      status: this.status,
      currentStep: Math.max(this.currentStep, 0),
      totalSteps: TOTAL_STEPS,
      currentStepName: this.currentStep >= 0 ? stepInfo.name : 'NOT_STARTED',
      simulatedTimestamp: this.currentTimestamp(),
      anomalies: [...this.anomalies],
      serviceHealth: [...this.health.values()],
      activeIncident: this.incidentManager.getById(SCENARIO_INCIDENT_ID) ?? null,
    };
  }

  getServices(): Service[] {
    return [...this.services.values()];
  }

  getService(serviceId: string): Service | undefined {
    return this.services.get(serviceId);
  }

  getServiceHealth(serviceId: string): ServiceHealth | undefined {
    return this.health.get(serviceId);
  }

  getAllServiceHealth(): ServiceHealth[] {
    return [...this.health.values()];
  }

  getAnomalies(): Anomaly[] {
    return [...this.anomalies];
  }

  getIncidents(): Incident[] {
    return this.incidentManager.getAll();
  }

  getActiveIncidents(): Incident[] {
    return this.incidentManager.getActive();
  }

  getIncidentById(id: string): Incident | undefined {
    return this.incidentManager.getById(id);
  }

  getDependencies() {
    return SERVICE_DEPENDENCIES;
  }

  // ---------------------------------------------------------------
  // Step execution (the actual scenario)
  // ---------------------------------------------------------------

  private executeStep(stepIndex: number): void {
    this.currentStep = stepIndex;
    switch (stepIndex) {
      case 0:
        this.stepHealthySystem();
        break;
      case 1:
        this.stepConfigurationChange();
        break;
      case 2:
        this.stepPaymentLatencySpike();
        break;
      case 3:
        this.stepPaymentTimeouts();
        break;
      case 4:
        this.stepOrderRetryStorm();
        break;
      case 5:
        this.stepOrderServiceDegradation();
        break;
      case 6:
        this.stepApiGatewayErrors();
        break;
      case 7:
        this.stepUserImpact();
        break;
      case 8:
        this.stepIncidentCreated();
        break;
      default:
        break;
    }
  }

  private stepHealthySystem(): void {
    for (const serviceId of getServiceIds()) {
      const baseline = getBaseline(serviceId);
      const service = this.services.get(serviceId)!;
      const ts = this.nextTimestamp();

      const latency = TelemetryGenerator.jitter(baseline.latency, Math.max(5, baseline.latency * 0.1), `${serviceId}-latency-0`);
      service.latency = latency;
      service.errorRate = baseline.errorRate;
      service.requestCount = baseline.requestCount;
      service.retryCount = baseline.retryCount;
      service.timeoutCount = 0;
      service.failedRequestCount = 0;
      service.lastUpdated = ts;

      const metric = TelemetryGenerator.metric(serviceId, 'latency', latency, ts, 'ms');
      this.store.addMetric(metric);
      const errMetric = TelemetryGenerator.metric(
        serviceId,
        'error_rate',
        Math.round(baseline.errorRate * 1000) / 1000,
        ts
      );
      this.store.addMetric(errMetric);

      this.recomputeHealth(serviceId, ts);
    }

    const ts = this.nextTimestamp();
    this.store.addLog(
      TelemetryGenerator.log('api-gateway', 'INFO', 'System healthy. All services operating within normal baselines.', ts)
    );

    // Baseline healthy trace: user -> api-gateway -> order-service -> payment-service -> external gateway
    this.store.addTrace(this.buildTrace(ts, false));
  }

  private stepConfigurationChange(): void {
    const ts = this.nextTimestamp();
    const event = TelemetryGenerator.systemEvent(
      'configuration_changed',
      `Payment timeout changed from ${CONFIG_CHANGE.previousValue}ms to ${CONFIG_CHANGE.newValue}ms`,
      ts,
      CONFIG_CHANGE.service,
      {
        key: CONFIG_CHANGE.key,
        previousValue: CONFIG_CHANGE.previousValue,
        newValue: CONFIG_CHANGE.newValue,
      }
    );
    // Preserved as evidence for later investigation (Members 2 & 3).
    this.store.addSystemEvent(event);

    this.store.addLog(
      TelemetryGenerator.log(
        CONFIG_CHANGE.service,
        'WARN',
        `Configuration change applied: payment.timeout_ms ${CONFIG_CHANGE.previousValue} -> ${CONFIG_CHANGE.newValue}`,
        ts,
        undefined,
        { previousValue: CONFIG_CHANGE.previousValue, newValue: CONFIG_CHANGE.newValue }
      )
    );

    // No anomaly, no health change yet - this is only preserved evidence.
  }

  private stepPaymentLatencySpike(): void {
    const serviceId = 'payment-service';
    const service = this.services.get(serviceId)!;
    const relatedTelemetryIds: string[] = [];
    let ts = this.currentTimestamp();

    for (const latency of PAYMENT_LATENCY_PROGRESSION) {
      ts = this.nextTimestamp();
      const metric = TelemetryGenerator.metric(serviceId, 'latency', latency, ts, 'ms');
      const telemetry = this.store.addMetric(metric);
      relatedTelemetryIds.push(telemetry.id);

      const level = latency >= 2000 ? 'ERROR' : 'WARN';
      this.store.addLog(
        TelemetryGenerator.log(
          serviceId,
          level,
          `Payment latency exceeded threshold: ${latency}ms (baseline ~120ms).`,
          ts
        )
      );

      service.latency = latency;
      service.lastUpdated = ts;
    }

    this.runDetectionAndHealth(serviceId, ts, relatedTelemetryIds);
  }

  private stepPaymentTimeouts(): void {
    const serviceId = 'payment-service';
    const service = this.services.get(serviceId)!;
    const relatedTelemetryIds: string[] = [];
    let ts = this.nextTimestamp();

    service.timeoutCount = 25;
    service.failedRequestCount = 30;
    service.errorRate = 0.65;

    relatedTelemetryIds.push(
      this.store.addMetric(TelemetryGenerator.metric(serviceId, 'timeout_count', service.timeoutCount, ts)).id
    );
    relatedTelemetryIds.push(
      this.store.addMetric(TelemetryGenerator.metric(serviceId, 'failed_request_count', service.failedRequestCount, ts))
        .id
    );
    relatedTelemetryIds.push(
      this.store.addMetric(TelemetryGenerator.metric(serviceId, 'error_rate', service.errorRate, ts)).id
    );

    this.store.addLog(TelemetryGenerator.log(serviceId, 'ERROR', 'Payment provider request timed out', ts));
    this.store.addLog(
      TelemetryGenerator.log(serviceId, 'ERROR', 'Payment provider request timed out', this.nextTimestamp())
    );

    this.store.addSystemEvent(
      TelemetryGenerator.systemEvent(
        'timeout_detected',
        'Payment Service requests are timing out against the external payment gateway.',
        ts,
        serviceId
      )
    );

    // Failed trace: Order -> Payment -> External Gateway, Payment span fails on timeout
    ts = this.nextTimestamp();
    this.store.addTrace(this.buildTrace(ts, true));

    service.lastUpdated = ts;
    this.runDetectionAndHealth(serviceId, ts, relatedTelemetryIds);
  }

  private stepOrderRetryStorm(): void {
    const serviceId = 'order-service';
    const service = this.services.get(serviceId)!;
    const relatedTelemetryIds: string[] = [];
    let ts = this.currentTimestamp();

    for (const retries of ORDER_RETRY_PROGRESSION) {
      ts = this.nextTimestamp();
      const telemetry = this.store.addMetric(TelemetryGenerator.metric(serviceId, 'retry_count', retries, ts));
      relatedTelemetryIds.push(telemetry.id);
      this.store.addLog(
        TelemetryGenerator.log(
          serviceId,
          retries >= 50 ? 'ERROR' : 'WARN',
          `Retry attempt initiated against payment-service (retry count: ${retries}).`,
          ts
        )
      );
      service.retryCount = retries;
      service.latency = TelemetryGenerator.jitter(300, 40, `order-retry-${retries}`);
      service.lastUpdated = ts;
    }

    relatedTelemetryIds.push(
      this.store.addMetric(TelemetryGenerator.metric(serviceId, 'latency', service.latency, ts, 'ms')).id
    );

    this.runDetectionAndHealth(serviceId, ts, relatedTelemetryIds);
  }

  private stepOrderServiceDegradation(): void {
    const serviceId = 'order-service';
    const service = this.services.get(serviceId)!;
    const relatedTelemetryIds: string[] = [];
    const ts = this.nextTimestamp();

    service.latency = 1200;
    service.errorRate = 0.18;
    service.failedRequestCount = 22;

    relatedTelemetryIds.push(this.store.addMetric(TelemetryGenerator.metric(serviceId, 'latency', service.latency, ts, 'ms')).id);
    relatedTelemetryIds.push(this.store.addMetric(TelemetryGenerator.metric(serviceId, 'error_rate', service.errorRate, ts)).id);
    relatedTelemetryIds.push(
      this.store.addMetric(TelemetryGenerator.metric(serviceId, 'failed_request_count', service.failedRequestCount, ts)).id
    );

    this.store.addLog(
      TelemetryGenerator.log(
        serviceId,
        'CRITICAL',
        'Order Service is degraded: elevated latency and error rate driven by repeated payment retries.',
        ts
      )
    );

    this.store.addSystemEvent(
      TelemetryGenerator.systemEvent(
        'service_degraded',
        'Order Service health degraded due to sustained retry load against Payment Service.',
        ts,
        serviceId
      )
    );

    service.lastUpdated = ts;
    this.runDetectionAndHealth(serviceId, ts, relatedTelemetryIds);
  }

  private stepApiGatewayErrors(): void {
    const serviceId = 'api-gateway';
    const service = this.services.get(serviceId)!;
    const relatedTelemetryIds: string[] = [];
    const ts = this.nextTimestamp();

    service.latency = 850;
    service.errorRate = 0.32;
    service.failedRequestCount = 40;

    relatedTelemetryIds.push(this.store.addMetric(TelemetryGenerator.metric(serviceId, 'latency', service.latency, ts, 'ms')).id);
    relatedTelemetryIds.push(this.store.addMetric(TelemetryGenerator.metric(serviceId, 'error_rate', service.errorRate, ts)).id);
    relatedTelemetryIds.push(
      this.store.addMetric(TelemetryGenerator.metric(serviceId, 'failed_request_count', service.failedRequestCount, ts)).id
    );

    this.store.addLog(
      TelemetryGenerator.log(
        serviceId,
        'ERROR',
        'API Gateway returning increased 5xx errors for order and checkout requests.',
        ts
      )
    );

    service.lastUpdated = ts;
    this.runDetectionAndHealth(serviceId, ts, relatedTelemetryIds);
  }

  private stepUserImpact(): void {
    const ts = this.nextTimestamp();
    this.userImpactDetected = true;

    this.store.addSystemEvent(
      TelemetryGenerator.systemEvent(
        'user_impact_detected',
        'Users are experiencing failed checkouts and failed payments.',
        ts,
        'api-gateway',
        { failedOrderCount: 87, failedCheckoutCount: 64 }
      )
    );

    this.store.addLog(
      TelemetryGenerator.log(
        'api-gateway',
        'CRITICAL',
        'User impact confirmed: checkout success rate has dropped sharply.',
        ts
      )
    );
  }

  private stepIncidentCreated(): void {
    const ts = this.nextTimestamp();
    const incident = this.incidentManager.evaluate(this.anomalies, this.userImpactDetected, ts, {
      forcedId: SCENARIO_INCIDENT_ID,
      forcedTitle: SCENARIO_INCIDENT_TITLE,
      forcedDescription:
        'Multiple services are experiencing related failures affecting the payment and order workflow. Evidence includes a recent payment-service configuration change, a payment latency spike, payment timeouts, an order-service retry storm, and API Gateway errors. Root cause investigation is handled by downstream analysis.',
    });

    // Guarantee the required affected services are present even if the
    // connectivity grouping (for any reason) came back narrower.
    if (incident) {
      const required = ['payment-service', 'order-service', 'api-gateway'];
      incident.affectedServices = Array.from(new Set([...incident.affectedServices, ...required]));
    }
  }

  // ---------------------------------------------------------------
  // Shared helpers
  // ---------------------------------------------------------------

  private runDetectionAndHealth(serviceId: string, timestamp: string, relatedTelemetryIds: string[]): void {
    const service = this.services.get(serviceId)!;
    const baseline = getBaseline(serviceId);

    const input: DetectionInput = {
      serviceId,
      timestamp,
      baseline: {
        latency: baseline.latency,
        errorRate: baseline.errorRate,
        retryCount: baseline.retryCount,
        timeoutCount: baseline.timeoutCount,
        failedRequestCount: baseline.failedRequestCount,
      },
      current: {
        latency: service.latency,
        errorRate: service.errorRate,
        retryCount: service.retryCount,
        timeoutCount: service.timeoutCount,
        failedRequestCount: service.failedRequestCount,
      },
      relatedTelemetryIds,
    };

    const newAnomalies = this.detectionEngine.run(input);
    for (const anomaly of newAnomalies) {
      this.anomalies.push(anomaly);
      eventBus.publish(EVENT_TYPES.ANOMALY_DETECTED, { anomaly });
    }

    this.recomputeHealth(serviceId, timestamp);
  }

  private recomputeHealth(serviceId: string, timestamp: string): void {
    const service = this.services.get(serviceId)!;
    const baseline = getBaseline(serviceId);
    const previous = this.health.get(serviceId);
    const newHealth = HealthCalculator.calculate(service, baseline, timestamp);

    service.healthScore = newHealth.score;
    service.status = newHealth.status;
    this.health.set(serviceId, newHealth);

    if (previous && previous.status !== newHealth.status) {
      const healthEvent: ServiceHealthEvent = {
        id: `health-${serviceId}-${this.cursorSeconds}`,
        serviceId,
        previousStatus: previous.status,
        currentStatus: newHealth.status,
        previousScore: previous.score,
        currentScore: newHealth.score,
        timestamp,
        factors: newHealth.factors,
      };
      this.store.addHealthEvent(healthEvent);
      eventBus.publish(EVENT_TYPES.SERVICE_HEALTH_CHANGED, { healthEvent });
    }
  }

  private buildTrace(timestamp: string, failed: boolean) {
    const gatewaySpan = TelemetryGenerator.span('api-gateway', 'POST /orders', timestamp, 20, 'success');
    const orderSpan = TelemetryGenerator.span('order-service', 'createOrder', timestamp, 40, 'success');
    const paymentSpan = TelemetryGenerator.span(
      'payment-service',
      'chargePayment',
      timestamp,
      failed ? 5000 : 90,
      failed ? 'failed' : 'success',
      failed ? 'timeout waiting for external payment gateway' : undefined
    );
    const spans = [gatewaySpan, orderSpan, paymentSpan];
    if (!failed) {
      spans.push(
        TelemetryGenerator.span('external-payment-gateway', 'authorize', timestamp, 60, 'success')
      );
    }
    return TelemetryGenerator.trace(spans, timestamp);
  }

  private currentTimestamp(): string {
    return new Date(new Date(SIMULATION_BASE_TIME).getTime() + this.cursorSeconds * 1000).toISOString();
  }

  private nextTimestamp(): string {
    this.cursorSeconds += 15;
    return this.currentTimestamp();
  }
}
