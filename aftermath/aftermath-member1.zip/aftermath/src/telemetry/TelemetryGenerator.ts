import { v4 as uuidv4 } from 'uuid';
import { Log, LogLevel, Metric, MetricName, SystemEvent, SystemEventType, Trace, TraceSpan } from '../types';

/**
 * Pure factory functions that build structured, well-formed telemetry
 * records (Metric / Log / SystemEvent / Trace). Contains no business
 * logic about *when* to generate telemetry (that's the simulator's
 * job) or how to interpret it (that's the detectors' job) - it only
 * knows how to shape realistic records.
 */
export class TelemetryGenerator {
  static metric(
    serviceId: string,
    name: MetricName,
    value: number,
    timestamp: string,
    unit?: string,
    metadata?: Record<string, unknown>
  ): Metric {
    return {
      id: `metric-${serviceId}-${name}-${uuidv4()}`,
      timestamp,
      serviceId,
      name,
      value,
      unit,
      metadata,
    };
  }

  static log(
    serviceId: string,
    level: LogLevel,
    message: string,
    timestamp: string,
    traceId?: string,
    metadata?: Record<string, unknown>
  ): Log {
    return {
      id: `log-${serviceId}-${uuidv4()}`,
      timestamp,
      serviceId,
      level,
      message,
      traceId,
      metadata,
    };
  }

  static systemEvent(
    type: SystemEventType,
    description: string,
    timestamp: string,
    serviceId?: string,
    metadata?: Record<string, unknown>
  ): SystemEvent {
    return {
      id: `event-${type}-${uuidv4()}`,
      timestamp,
      serviceId,
      type,
      description,
      metadata,
    };
  }

  static trace(spans: TraceSpan[], timestamp: string): Trace {
    const status: Trace['status'] = spans.some((s) => s.status === 'failed') ? 'failed' : 'success';
    const duration = spans.reduce((sum, s) => sum + s.duration, 0);
    return {
      traceId: `trace-${uuidv4()}`,
      timestamp,
      status,
      duration,
      spans,
    };
  }

  static span(
    serviceId: string,
    operation: string,
    startTime: string,
    duration: number,
    status: TraceSpan['status'],
    errorMessage?: string
  ): TraceSpan {
    return { serviceId, operation, startTime, duration, status, errorMessage };
  }

  /**
   * Small deterministic pseudo-jitter so repeated demo runs still look
   * organic without introducing real randomness that could break a
   * live presentation. Uses a fixed seed derived from the inputs, not
   * Math.random().
   */
  static jitter(base: number, amplitude: number, seedKey: string): number {
    let hash = 0;
    for (let i = 0; i < seedKey.length; i++) {
      hash = (hash * 31 + seedKey.charCodeAt(i)) % 1000;
    }
    const normalized = (hash / 1000) * 2 - 1; // range [-1, 1]
    return Math.round(base + normalized * amplitude);
  }
}
