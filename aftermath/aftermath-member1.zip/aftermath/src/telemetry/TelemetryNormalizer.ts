import { v4 as uuidv4 } from 'uuid';
import {
  Log,
  LogLevel,
  Metric,
  ServiceHealthEvent,
  SystemEvent,
  TelemetryEvent,
  TelemetrySeverity,
  Trace,
} from '../types';

/**
 * Converts raw, category-specific telemetry (Metric, Log, SystemEvent,
 * Trace, ServiceHealthEvent) into the unified TelemetryEvent envelope
 * used for storage, correlation, and cross-cutting queries.
 *
 * The original structured payload is always preserved (never
 * destroyed) inside `data`.
 */
export class TelemetryNormalizer {
  static fromMetric(metric: Metric): TelemetryEvent {
    return {
      id: `tel-${metric.id}`,
      timestamp: metric.timestamp,
      serviceId: metric.serviceId,
      category: 'metric',
      type: metric.name,
      severity: 'info',
      data: { ...metric },
    };
  }

  static fromLog(log: Log): TelemetryEvent {
    return {
      id: `tel-${log.id}`,
      timestamp: log.timestamp,
      serviceId: log.serviceId,
      category: 'log',
      type: log.level,
      severity: TelemetryNormalizer.logLevelToSeverity(log.level),
      data: { ...log },
      traceId: log.traceId,
    };
  }

  static fromSystemEvent(event: SystemEvent): TelemetryEvent {
    return {
      id: `tel-${event.id}`,
      timestamp: event.timestamp,
      serviceId: event.serviceId,
      category: 'event',
      type: event.type,
      severity: TelemetryNormalizer.eventTypeToSeverity(event.type),
      data: { ...event },
    };
  }

  static fromTrace(trace: Trace): TelemetryEvent {
    return {
      id: `tel-trace-${trace.traceId}`,
      timestamp: trace.timestamp,
      category: 'trace',
      type: 'trace',
      severity: trace.status === 'failed' ? 'error' : 'info',
      data: { ...trace },
      traceId: trace.traceId,
    };
  }

  static fromHealthEvent(health: ServiceHealthEvent): TelemetryEvent {
    return {
      id: `tel-${health.id}`,
      timestamp: health.timestamp,
      serviceId: health.serviceId,
      category: 'health',
      type: 'health_change',
      severity: TelemetryNormalizer.statusToSeverity(health.currentStatus),
      data: { ...health },
    };
  }

  private static logLevelToSeverity(level: LogLevel): TelemetrySeverity {
    switch (level) {
      case 'INFO':
        return 'info';
      case 'WARN':
        return 'warning';
      case 'ERROR':
        return 'error';
      case 'CRITICAL':
        return 'critical';
      default:
        return 'info';
    }
  }

  private static eventTypeToSeverity(type: SystemEvent['type']): TelemetrySeverity {
    switch (type) {
      case 'user_impact_detected':
      case 'circuit_breaker_opened':
        return 'critical';
      case 'service_degraded':
      case 'timeout_detected':
        return 'error';
      case 'configuration_changed':
        return 'warning';
      default:
        return 'info';
    }
  }

  private static statusToSeverity(status: string): TelemetrySeverity {
    switch (status) {
      case 'critical':
        return 'critical';
      case 'degraded':
        return 'warning';
      default:
        return 'info';
    }
  }

  /** Utility for callers that need a fresh telemetry id outside the normalize* helpers. */
  static newId(prefix: string): string {
    return `${prefix}-${uuidv4()}`;
  }
}
