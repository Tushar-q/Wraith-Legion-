import {
  Log,
  Metric,
  ServiceHealthEvent,
  SystemEvent,
  TelemetryCategory,
  TelemetryEvent,
  Trace,
} from '../types';
import { TelemetryNormalizer } from './TelemetryNormalizer';

/**
 * In-memory telemetry storage abstraction.
 *
 * Keeps both the raw, category-specific records (metrics, logs,
 * events, traces, health history) AND the unified TelemetryEvent
 * stream (for cross-cutting/correlated queries). Callers should
 * generally prefer the raw getters when they know exactly what they
 * want, and the unified getTelemetry* methods when correlating across
 * categories (e.g. building incident context).
 *
 * This class is intentionally storage-engine agnostic in its public
 * surface so it can be swapped for a persistent backend later without
 * touching callers.
 */
export class TelemetryStore {
  private metrics: Metric[] = [];
  private logs: Log[] = [];
  private events: SystemEvent[] = [];
  private traces: Trace[] = [];
  private healthHistory: ServiceHealthEvent[] = [];
  private unified: TelemetryEvent[] = [];

  // ---- Writes -------------------------------------------------------

  addMetric(metric: Metric): TelemetryEvent {
    this.metrics.push(metric);
    const normalized = TelemetryNormalizer.fromMetric(metric);
    this.unified.push(normalized);
    return normalized;
  }

  addLog(log: Log): TelemetryEvent {
    this.logs.push(log);
    const normalized = TelemetryNormalizer.fromLog(log);
    this.unified.push(normalized);
    return normalized;
  }

  addSystemEvent(event: SystemEvent): TelemetryEvent {
    this.events.push(event);
    const normalized = TelemetryNormalizer.fromSystemEvent(event);
    this.unified.push(normalized);
    return normalized;
  }

  addTrace(trace: Trace): TelemetryEvent {
    this.traces.push(trace);
    const normalized = TelemetryNormalizer.fromTrace(trace);
    this.unified.push(normalized);
    return normalized;
  }

  addHealthEvent(health: ServiceHealthEvent): TelemetryEvent {
    this.healthHistory.push(health);
    const normalized = TelemetryNormalizer.fromHealthEvent(health);
    this.unified.push(normalized);
    return normalized;
  }

  /** Generic entry point used by the normalizer/generator when the category is already known. */
  addTelemetry(event: TelemetryEvent): TelemetryEvent {
    this.unified.push(event);
    return event;
  }

  // ---- Unified reads --------------------------------------------------

  getTelemetry(): TelemetryEvent[] {
    return [...this.unified].sort(byTimestampAsc);
  }

  getTelemetryByService(serviceId: string): TelemetryEvent[] {
    return this.unified.filter((t) => t.serviceId === serviceId).sort(byTimestampAsc);
  }

  getTelemetryByTimeRange(startTime: string, endTime: string): TelemetryEvent[] {
    const start = new Date(startTime).getTime();
    const end = new Date(endTime).getTime();
    return this.unified
      .filter((t) => {
        const ts = new Date(t.timestamp).getTime();
        return ts >= start && ts <= end;
      })
      .sort(byTimestampAsc);
  }

  getTelemetryByCategory(category: TelemetryCategory): TelemetryEvent[] {
    return this.unified.filter((t) => t.category === category).sort(byTimestampAsc);
  }

  getTelemetryByTraceId(traceId: string): TelemetryEvent[] {
    return this.unified.filter((t) => t.traceId === traceId).sort(byTimestampAsc);
  }

  getTelemetryByIds(ids: string[]): TelemetryEvent[] {
    const idSet = new Set(ids);
    return this.unified.filter((t) => idSet.has(t.id));
  }

  /**
   * Return telemetry "related" to a given service: telemetry for the
   * service itself plus telemetry for services it depends on/is
   * depended on by. `relatedServiceIds` should be pre-computed by the
   * caller (e.g. from the dependency graph) since the store itself has
   * no knowledge of dependency relationships.
   */
  getRelatedTelemetry(relatedServiceIds: string[], startTime?: string, endTime?: string): TelemetryEvent[] {
    const idSet = new Set(relatedServiceIds);
    let results = this.unified.filter((t) => t.serviceId && idSet.has(t.serviceId));
    if (startTime && endTime) {
      const start = new Date(startTime).getTime();
      const end = new Date(endTime).getTime();
      results = results.filter((t) => {
        const ts = new Date(t.timestamp).getTime();
        return ts >= start && ts <= end;
      });
    }
    return results.sort(byTimestampAsc);
  }

  // ---- Raw category reads --------------------------------------------

  getMetrics(serviceId?: string): Metric[] {
    const rows = serviceId ? this.metrics.filter((m) => m.serviceId === serviceId) : this.metrics;
    return [...rows].sort(byTimestampAsc);
  }

  getLogs(serviceId?: string): Log[] {
    const rows = serviceId ? this.logs.filter((l) => l.serviceId === serviceId) : this.logs;
    return [...rows].sort(byTimestampAsc);
  }

  getSystemEvents(serviceId?: string): SystemEvent[] {
    const rows = serviceId ? this.events.filter((e) => e.serviceId === serviceId) : this.events;
    return [...rows].sort(byTimestampAsc);
  }

  getTraces(serviceId?: string): Trace[] {
    const rows = serviceId
      ? this.traces.filter((t) => t.spans.some((s) => s.serviceId === serviceId))
      : this.traces;
    return [...rows].sort(byTimestampAsc);
  }

  getTraceById(traceId: string): Trace | undefined {
    return this.traces.find((t) => t.traceId === traceId);
  }

  getTracesByStatus(status: Trace['status']): Trace[] {
    return this.traces.filter((t) => t.status === status).sort(byTimestampAsc);
  }

  getHealthHistory(serviceId?: string): ServiceHealthEvent[] {
    const rows = serviceId
      ? this.healthHistory.filter((h) => h.serviceId === serviceId)
      : this.healthHistory;
    return [...rows].sort(byTimestampAsc);
  }

  // ---- Lifecycle -------------------------------------------------------

  clearTelemetry(): void {
    this.metrics = [];
    this.logs = [];
    this.events = [];
    this.traces = [];
    this.healthHistory = [];
    this.unified = [];
  }
}

function byTimestampAsc(a: { timestamp: string }, b: { timestamp: string }): number {
  return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
}
