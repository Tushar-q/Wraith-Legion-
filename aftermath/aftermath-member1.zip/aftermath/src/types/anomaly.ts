export type AnomalySeverity = 'low' | 'medium' | 'high' | 'critical';

export type AnomalyMetric =
  | 'latency'
  | 'error_rate'
  | 'retry_count'
  | 'timeout_count'
  | 'failed_request_count';

export interface Anomaly {
  id: string;
  timestamp: string;
  serviceId: string;
  metric: AnomalyMetric;
  expectedValue?: number;
  actualValue: number;
  deviation?: number; // percentage deviation from expected
  severity: AnomalySeverity;
  description: string;
  relatedTelemetryIds: string[];
}

/** Common input shared by all anomaly detectors. */
export interface DetectionInput {
  serviceId: string;
  timestamp: string;
  /** Baseline / expected values for this service. */
  baseline: {
    latency: number;
    errorRate: number;
    retryCount: number;
    timeoutCount: number;
    failedRequestCount: number;
  };
  /** Currently observed values for this service. */
  current: {
    latency: number;
    errorRate: number;
    retryCount: number;
    timeoutCount: number;
    failedRequestCount: number;
  };
  /** ids of the raw telemetry (metrics) that produced these current values */
  relatedTelemetryIds: string[];
}

export interface AnomalyDetector {
  name: string;
  detect(input: DetectionInput): Anomaly[];
}
