import { Anomaly } from './anomaly';
import { Incident } from './incident';
import { ServiceHealth } from './service';

export type SimulationStatus = 'idle' | 'running' | 'paused' | 'completed';

export interface DemoState {
  status: SimulationStatus;
  currentStep: number;
  totalSteps: number;
  currentStepName: string;
  simulatedTimestamp: string;
  anomalies: Anomaly[];
  serviceHealth: ServiceHealth[];
  activeIncident: Incident | null;
}

/** Internal event bus message envelope. */
export interface EventMessage<T = unknown> {
  eventType: string;
  timestamp: string;
  data: T;
}
