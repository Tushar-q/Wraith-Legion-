export type IncidentSeverity = 'low' | 'medium' | 'high' | 'critical';
export type IncidentStatus = 'detected' | 'investigating' | 'resolved';

export interface Incident {
  id: string;
  title: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
  detectedAt: string;
  startTime: string;
  affectedServices: string[];
  anomalyIds: string[];
  description: string;
}

export interface SeverityResult {
  severity: IncidentSeverity;
  score: number;
  reasons: string[];
}
