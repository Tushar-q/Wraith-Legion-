/**
 * Core service model for the simulated distributed application.
 */

export type ServiceType =
  | 'gateway'
  | 'application'
  | 'database'
  | 'external';

export type ServiceStatus = 'healthy' | 'degraded' | 'critical' | 'unknown';

export interface Service {
  id: string;
  name: string;
  type: ServiceType;
  dependencies: string[]; // serviceIds this service depends on
  status: ServiceStatus;
  healthScore: number; // 0-100
  latency: number; // ms, current observed
  errorRate: number; // 0-1 (fraction)
  requestCount: number;
  retryCount: number;
  timeoutCount: number;
  failedRequestCount: number;
  cpuUsage: number; // 0-1 (fraction)
  memoryUsage: number; // 0-1 (fraction)
  lastUpdated: string; // ISO timestamp
}

/**
 * Directed edge in the service dependency graph.
 * source depends on / calls target.
 */
export interface ServiceDependency {
  source: string;
  target: string;
  relationship?: string;
}

export interface ServiceHealth {
  serviceId: string;
  score: number; // 0-100
  status: ServiceStatus;
  factors: string[]; // human-readable explanations for the score
  timestamp: string;
}

/**
 * A recorded transition in a service's health status/score over time.
 */
export interface ServiceHealthEvent {
  id: string;
  serviceId: string;
  previousStatus: ServiceStatus;
  currentStatus: ServiceStatus;
  previousScore: number;
  currentScore: number;
  timestamp: string;
  factors: string[];
}
