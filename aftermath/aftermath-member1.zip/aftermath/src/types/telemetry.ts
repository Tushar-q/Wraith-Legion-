/**
 * Raw telemetry models: Metrics, Logs, System Events, Traces.
 * Also the unified TelemetryEvent format used for cross-cutting queries.
 */

export type MetricName =
  | 'latency'
  | 'error_rate'
  | 'request_count'
  | 'retry_count'
  | 'timeout_count'
  | 'cpu_usage'
  | 'memory_usage'
  | 'failed_request_count';

export interface Metric {
  id: string;
  timestamp: string;
  serviceId: string;
  name: MetricName;
  value: number;
  unit?: string;
  metadata?: Record<string, unknown>;
}

export type LogLevel = 'INFO' | 'WARN' | 'ERROR' | 'CRITICAL';

export interface Log {
  id: string;
  timestamp: string;
  serviceId: string;
  level: LogLevel;
  message: string;
  traceId?: string;
  metadata?: Record<string, unknown>;
}

export type SystemEventType =
  | 'configuration_changed'
  | 'deployment_started'
  | 'deployment_completed'
  | 'service_restarted'
  | 'timeout_detected'
  | 'circuit_breaker_opened'
  | 'service_degraded'
  | 'user_impact_detected';

export interface SystemEvent {
  id: string;
  timestamp: string;
  serviceId?: string;
  type: SystemEventType;
  description: string;
  metadata?: Record<string, unknown>;
}

export type TraceSpanStatus = 'success' | 'failed';

export interface TraceSpan {
  serviceId: string;
  operation: string;
  startTime: string;
  duration: number; // ms
  status: TraceSpanStatus;
  errorMessage?: string;
}

export interface Trace {
  traceId: string;
  timestamp: string;
  status: TraceSpanStatus;
  duration: number; // ms, total
  spans: TraceSpan[];
}

/**
 * Unified telemetry envelope. Every raw telemetry item (metric, log,
 * system event, trace, health change) is normalized into one of these
 * so that storage/query/correlation code does not need to special-case
 * every telemetry category.
 */
export type TelemetryCategory = 'metric' | 'log' | 'event' | 'trace' | 'health';
export type TelemetrySeverity = 'info' | 'warning' | 'error' | 'critical';

export interface TelemetryEvent {
  id: string;
  timestamp: string;
  serviceId?: string;
  category: TelemetryCategory;
  type: string; // e.g. metric name, log level, event type, 'trace', 'health_change'
  severity: TelemetrySeverity;
  data: Record<string, unknown>; // original structured payload preserved here
  traceId?: string;
}
