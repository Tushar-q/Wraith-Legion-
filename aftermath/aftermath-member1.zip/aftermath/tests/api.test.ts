import request from 'supertest';
import { createApp } from '../src/app';
import { AftermathEngine } from '../src/services/context';

describe('API integration', () => {
  let app: ReturnType<typeof createApp>;
  let engine: AftermathEngine;

  beforeEach(() => {
    engine = new AftermathEngine();
    app = createApp(engine);
  });

  it('GET /health returns ok', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });

  it('GET /api/system returns a healthy summary before the demo starts', async () => {
    const res = await request(app).get('/api/system');
    expect(res.status).toBe(200);
    expect(res.body.data.overallStatus).toBe('healthy');
    expect(res.body.data.serviceCount).toBe(8);
  });

  it('GET /api/services returns all 8 services with health', async () => {
    const res = await request(app).get('/api/services');
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(8);
    expect(res.body.data[0]).toHaveProperty('health');
  });

  it('GET /api/services/:serviceId returns detail, 404 for unknown', async () => {
    const ok = await request(app).get('/api/services/payment-service');
    expect(ok.status).toBe(200);
    expect(ok.body.data.service.id).toBe('payment-service');

    const missing = await request(app).get('/api/services/does-not-exist');
    expect(missing.status).toBe(404);
  });

  it('GET /api/services/dependencies returns the dependency graph', async () => {
    const res = await request(app).get('/api/services/dependencies');
    expect(res.status).toBe(200);
    expect(res.body.data.length).toBeGreaterThan(0);
    expect(res.body.data[0]).toHaveProperty('source');
    expect(res.body.data[0]).toHaveProperty('target');
  });

  it('runs the full demo lifecycle through the API and produces INC-042', async () => {
    await request(app).post('/api/demo/reset');
    let res = await request(app).post('/api/demo/start');
    expect(res.body.data.status).toBe('running');

    for (let i = 0; i < 7; i++) {
      res = await request(app).post('/api/demo/next');
    }
    res = await request(app).post('/api/demo/next'); // step 8: incident created
    expect(res.body.data.status).toBe('completed');
    expect(res.body.data.activeIncident.id).toBe('INC-042');

    const incidentRes = await request(app).get('/api/incidents/INC-042');
    expect(incidentRes.status).toBe(200);
    expect(incidentRes.body.data.severity).toBe('critical');

    const contextRes = await request(app).get('/api/incidents/INC-042/context');
    expect(contextRes.status).toBe(200);
    expect(contextRes.body.data.incident.id).toBe('INC-042');
    expect(contextRes.body.data.anomalies.length).toBeGreaterThan(0);
    expect(contextRes.body.data.affectedServices.length).toBeGreaterThan(0);
    expect(contextRes.body.data.dependencies.length).toBeGreaterThan(0);

    const summaryRes = await request(app).get('/api/incidents/INC-042/summary');
    expect(summaryRes.status).toBe(200);
    expect(summaryRes.body.data.narrative).toContain('INC-042');
    expect(summaryRes.body.data.configurationChanges.length).toBeGreaterThan(0);

    const anomalySummaryRes = await request(app).get('/api/incidents/INC-042/anomaly-summary');
    expect(anomalySummaryRes.status).toBe(200);
    expect(anomalySummaryRes.body.data.totalAnomalies).toBeGreaterThan(0);

    const anomaliesRes = await request(app).get('/api/anomalies');
    expect(anomaliesRes.status).toBe(200);
    expect(anomaliesRes.body.count).toBeGreaterThan(0);

    const telemetryRes = await request(app).get('/api/telemetry?category=metric');
    expect(telemetryRes.status).toBe(200);
    expect(telemetryRes.body.data.every((t: { category: string }) => t.category === 'metric')).toBe(true);

    const stateRes = await request(app).get('/api/demo/state');
    expect(stateRes.body.data.status).toBe('completed');

    const resetRes = await request(app).post('/api/demo/reset');
    expect(resetRes.body.data.status).toBe('idle');
    expect(resetRes.body.data.activeIncident).toBeNull();
  });

  it('rejects invalid telemetry category filter', async () => {
    const res = await request(app).get('/api/telemetry?category=bogus');
    expect(res.status).toBe(400);
  });

  it('returns 404 for unknown incident id', async () => {
    const res = await request(app).get('/api/incidents/INC-999');
    expect(res.status).toBe(404);
  });
});
