import { LatencyDetector } from '../src/detectors/LatencyDetector';
import { ErrorRateDetector } from '../src/detectors/ErrorRateDetector';
import { RetryDetector } from '../src/detectors/RetryDetector';
import { TimeoutDetector } from '../src/detectors/TimeoutDetector';
import { DetectionInput } from '../src/types';

function baseInput(overrides: Partial<DetectionInput['current']> = {}): DetectionInput {
  return {
    serviceId: 'payment-service',
    timestamp: '2026-08-29T09:00:00Z',
    baseline: { latency: 120, errorRate: 0.005, retryCount: 2, timeoutCount: 0, failedRequestCount: 0 },
    current: {
      latency: 120,
      errorRate: 0.005,
      retryCount: 2,
      timeoutCount: 0,
      failedRequestCount: 0,
      ...overrides,
    },
    relatedTelemetryIds: ['metric-1'],
  };
}

describe('LatencyDetector', () => {
  const detector = new LatencyDetector();

  it('does not flag latency within baseline', () => {
    expect(detector.detect(baseInput())).toHaveLength(0);
  });

  it('flags critical latency spikes', () => {
    const anomalies = detector.detect(baseInput({ latency: 4500 }));
    expect(anomalies).toHaveLength(1);
    expect(anomalies[0].severity).toBe('critical');
    expect(anomalies[0].expectedValue).toBe(120);
    expect(anomalies[0].actualValue).toBe(4500);
    expect(anomalies[0].metric).toBe('latency');
  });
});

describe('ErrorRateDetector', () => {
  const detector = new ErrorRateDetector();

  it('does not flag error rate within baseline', () => {
    expect(detector.detect(baseInput())).toHaveLength(0);
  });

  it('flags critical error rate', () => {
    const anomalies = detector.detect(baseInput({ errorRate: 0.65 }));
    expect(anomalies).toHaveLength(1);
    expect(anomalies[0].severity).toBe('critical');
  });
});

describe('RetryDetector', () => {
  const detector = new RetryDetector();

  it('does not flag normal retry counts', () => {
    expect(detector.detect(baseInput({ retryCount: 3 }))).toHaveLength(0);
  });

  it('flags a retry storm as critical', () => {
    const anomalies = detector.detect(baseInput({ retryCount: 150 }));
    expect(anomalies).toHaveLength(1);
    expect(anomalies[0].severity).toBe('critical');
    expect(anomalies[0].metric).toBe('retry_count');
  });
});

describe('TimeoutDetector', () => {
  const detector = new TimeoutDetector();

  it('does not flag zero timeouts', () => {
    expect(detector.detect(baseInput({ timeoutCount: 0 }))).toHaveLength(0);
  });

  it('flags a timeout spike as critical', () => {
    const anomalies = detector.detect(baseInput({ timeoutCount: 25 }));
    expect(anomalies).toHaveLength(1);
    expect(anomalies[0].severity).toBe('critical');
  });
});
