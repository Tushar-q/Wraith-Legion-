import { HealthCalculator } from '../src/health/HealthCalculator';
import { Service } from '../src/types';
import { getBaseline } from '../src/config/baselines';

function makeService(overrides: Partial<Service> = {}): Service {
  return {
    id: 'payment-service',
    name: 'Payment Service',
    type: 'application',
    dependencies: [],
    status: 'healthy',
    healthScore: 100,
    latency: 120,
    errorRate: 0.005,
    requestCount: 200,
    retryCount: 2,
    timeoutCount: 0,
    failedRequestCount: 0,
    cpuUsage: 0.2,
    memoryUsage: 0.3,
    lastUpdated: '2026-08-29T09:00:00Z',
    ...overrides,
  };
}

describe('HealthCalculator', () => {
  const baseline = getBaseline('payment-service');

  it('scores a healthy service at 100 / healthy', () => {
    const health = HealthCalculator.calculate(makeService(), baseline, '2026-08-29T09:00:00Z');
    expect(health.score).toBe(100);
    expect(health.status).toBe('healthy');
  });

  it('degrades score for critical latency + high error rate + timeouts', () => {
    const service = makeService({ latency: 4500, errorRate: 0.65, timeoutCount: 25, failedRequestCount: 30 });
    const health = HealthCalculator.calculate(service, baseline, '2026-08-29T09:00:00Z');
    expect(health.score).toBeLessThan(50);
    expect(health.status).toBe('critical');
    expect(health.factors).toContain('Critical latency detected');
    expect(health.factors).toContain('High error rate');
    expect(health.factors).toContain('Timeout spike');
  });

  it('never returns a score below 0', () => {
    const service = makeService({
      latency: 10000,
      errorRate: 0.99,
      timeoutCount: 999,
      retryCount: 999,
      failedRequestCount: 999,
    });
    const health = HealthCalculator.calculate(service, baseline, '2026-08-29T09:00:00Z');
    expect(health.score).toBeGreaterThanOrEqual(0);
  });
});
