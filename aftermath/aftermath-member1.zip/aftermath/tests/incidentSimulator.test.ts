import { TelemetryStore } from '../src/telemetry/TelemetryStore';
import { IncidentSimulator } from '../src/simulator/IncidentSimulator';

describe('IncidentSimulator - PAYMENT FAILURE PROPAGATION scenario', () => {
  let store: TelemetryStore;
  let simulator: IncidentSimulator;

  beforeEach(() => {
    store = new TelemetryStore();
    simulator = new IncidentSimulator(store);
  });

  // TEST 1 - INITIAL STATE
  it('starts idle with healthy services, no anomalies, no incident', () => {
    const state = simulator.reset();
    expect(state.status).toBe('idle');
    expect(state.anomalies).toHaveLength(0);
    expect(state.activeIncident).toBeNull();
    for (const service of simulator.getServices()) {
      expect(service.status).toBe('healthy');
      expect(service.healthScore).toBe(100);
    }
  });

  it('runs step 0 (healthy system) on start()', () => {
    const state = simulator.start();
    expect(state.status).toBe('running');
    expect(state.currentStepName).toBe('HEALTHY_SYSTEM');
    expect(state.activeIncident).toBeNull();
    expect(store.getMetrics().length).toBeGreaterThan(0);
  });

  // TEST 2 - CONFIGURATION CHANGE
  it('preserves the configuration change event without creating an incident', () => {
    simulator.start();
    const state = simulator.nextStep(); // step 1
    expect(state.currentStepName).toBe('CONFIGURATION_CHANGE');
    expect(state.activeIncident).toBeNull();

    const events = store.getSystemEvents('payment-service');
    const configEvent = events.find((e) => e.type === 'configuration_changed');
    expect(configEvent).toBeDefined();
    expect(configEvent?.metadata?.previousValue).toBe(5000);
    expect(configEvent?.metadata?.newValue).toBe(500);
  });

  // TEST 3 - LATENCY SPIKE
  it('detects a payment latency anomaly and degrades payment health', () => {
    simulator.start();
    simulator.nextStep(); // 1
    const state = simulator.nextStep(); // 2

    expect(state.currentStepName).toBe('PAYMENT_LATENCY_SPIKE');
    const latencyAnomaly = state.anomalies.find(
      (a) => a.serviceId === 'payment-service' && a.metric === 'latency'
    );
    expect(latencyAnomaly).toBeDefined();
    expect(latencyAnomaly?.expectedValue).toBeDefined();
    expect(latencyAnomaly?.actualValue).toBe(4500);
    expect(latencyAnomaly?.severity).toBe('critical');

    const paymentHealth = simulator.getServiceHealth('payment-service');
    expect(paymentHealth?.score).toBeLessThan(100);
  });

  // TEST 4 - TIMEOUTS
  it('detects payment timeouts and records a failed trace', () => {
    simulator.start();
    simulator.nextStep(); // 1
    simulator.nextStep(); // 2
    const state = simulator.nextStep(); // 3

    expect(state.currentStepName).toBe('PAYMENT_TIMEOUTS');
    const timeoutAnomaly = state.anomalies.find((a) => a.metric === 'timeout_count');
    expect(timeoutAnomaly).toBeDefined();

    const failedTraces = store.getTracesByStatus('failed');
    expect(failedTraces.length).toBeGreaterThan(0);

    const paymentService = simulator.getService('payment-service')!;
    expect(['degraded', 'critical']).toContain(paymentService.status);
  });

  // TEST 5 - RETRY STORM
  it('detects an order-service retry storm anomaly', () => {
    simulator.start();
    simulator.nextStep(); // 1
    simulator.nextStep(); // 2
    simulator.nextStep(); // 3
    const state = simulator.nextStep(); // 4

    expect(state.currentStepName).toBe('ORDER_RETRY_STORM');
    const retryAnomaly = state.anomalies.find(
      (a) => a.serviceId === 'order-service' && a.metric === 'retry_count'
    );
    expect(retryAnomaly).toBeDefined();
    expect(retryAnomaly?.actualValue).toBe(150);

    const orderService = simulator.getService('order-service')!;
    expect(orderService.retryCount).toBe(150);
  });

  // TEST 6 - FAILURE PROPAGATION
  it('propagates failure to order-service degradation and api-gateway errors', () => {
    simulator.start();
    for (let i = 0; i < 6; i++) simulator.nextStep(); // through step 6 (API_GATEWAY_ERRORS)

    const state = simulator.getState();
    expect(state.currentStepName).toBe('API_GATEWAY_ERRORS');

    const affectedServiceIds = new Set(state.anomalies.map((a) => a.serviceId));
    expect(affectedServiceIds.has('payment-service')).toBe(true);
    expect(affectedServiceIds.has('order-service')).toBe(true);
    expect(affectedServiceIds.has('api-gateway')).toBe(true);

    const apiGateway = simulator.getService('api-gateway')!;
    expect(['degraded', 'critical']).toContain(apiGateway.status);
  });

  // TEST 7 - USER IMPACT
  it('records a user impact event', () => {
    simulator.start();
    for (let i = 0; i < 7; i++) simulator.nextStep(); // through step 7 (USER_IMPACT)

    const state = simulator.getState();
    expect(state.currentStepName).toBe('USER_IMPACT');

    const events = store.getSystemEvents();
    const impactEvent = events.find((e) => e.type === 'user_impact_detected');
    expect(impactEvent).toBeDefined();
  });

  // TEST 8 - INCIDENT
  it('creates INC-042 "Payment Failure Propagation" as critical/detected with the right services', () => {
    simulator.start();
    for (let i = 0; i < 8; i++) simulator.nextStep(); // through step 8 (INCIDENT_CREATED)

    const state = simulator.getState();
    expect(state.status).toBe('completed');
    expect(state.currentStepName).toBe('INCIDENT_CREATED');

    const incident = state.activeIncident;
    expect(incident).not.toBeNull();
    expect(incident?.id).toBe('INC-042');
    expect(incident?.title).toBe('Payment Failure Propagation');
    expect(incident?.severity).toBe('critical');
    expect(incident?.status).toBe('detected');
    expect(incident?.affectedServices).toEqual(
      expect.arrayContaining(['payment-service', 'order-service', 'api-gateway'])
    );
    expect(incident?.anomalyIds.length).toBeGreaterThan(0);
  });

  // TEST 9 - RESET
  it('fully resets to a clean state after running the full scenario', () => {
    simulator.start();
    for (let i = 0; i < 8; i++) simulator.nextStep();

    const stateAfterReset = simulator.reset();
    expect(stateAfterReset.status).toBe('idle');
    expect(stateAfterReset.currentStep).toBe(0);
    expect(stateAfterReset.anomalies).toHaveLength(0);
    expect(stateAfterReset.activeIncident).toBeNull();
    expect(store.getTelemetry()).toHaveLength(0);

    for (const service of simulator.getServices()) {
      expect(service.status).toBe('healthy');
      expect(service.healthScore).toBe(100);
    }
    expect(simulator.getIncidents()).toHaveLength(0);
  });

  it('is deterministic: running the scenario twice produces the same incident and anomaly counts', () => {
    simulator.start();
    for (let i = 0; i < 8; i++) simulator.nextStep();
    const firstRun = simulator.getState();
    const firstAnomalyCount = firstRun.anomalies.length;
    const firstIncident = firstRun.activeIncident;

    simulator.reset();
    simulator.start();
    for (let i = 0; i < 8; i++) simulator.nextStep();
    const secondRun = simulator.getState();

    expect(secondRun.anomalies.length).toBe(firstAnomalyCount);
    expect(secondRun.activeIncident?.id).toBe(firstIncident?.id);
    expect(secondRun.activeIncident?.severity).toBe(firstIncident?.severity);
    expect(secondRun.activeIncident?.affectedServices.sort()).toEqual(
      firstIncident?.affectedServices.sort()
    );
  });

  it('supports pause/resume without advancing the step', () => {
    simulator.start();
    simulator.nextStep();
    const pausedState = simulator.pause();
    expect(pausedState.status).toBe('paused');

    const stillPaused = simulator.nextStep(); // should be a no-op while paused
    expect(stillPaused.currentStepName).toBe('CONFIGURATION_CHANGE');

    const resumedState = simulator.resume();
    expect(resumedState.status).toBe('running');

    const advanced = simulator.nextStep();
    expect(advanced.currentStepName).toBe('PAYMENT_LATENCY_SPIKE');
  });

  it('supports previousStep by deterministically replaying from the beginning', () => {
    simulator.start();
    simulator.nextStep(); // 1
    simulator.nextStep(); // 2
    simulator.nextStep(); // 3

    const rewound = simulator.previousStep(); // back to step 2
    expect(rewound.currentStepName).toBe('PAYMENT_LATENCY_SPIKE');

    const paymentAnomaly = rewound.anomalies.find((a) => a.metric === 'timeout_count');
    expect(paymentAnomaly).toBeUndefined(); // step 3's timeout anomaly should not exist yet
  });
});
