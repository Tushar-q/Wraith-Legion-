import { SeverityCalculator } from '../src/incidents/SeverityCalculator';
import { Anomaly } from '../src/types';

function anomaly(overrides: Partial<Anomaly> = {}): Anomaly {
  return {
    id: 'anomaly-1',
    timestamp: '2026-08-29T09:00:00Z',
    serviceId: 'payment-service',
    metric: 'latency',
    actualValue: 4500,
    severity: 'critical',
    description: 'test anomaly',
    relatedTelemetryIds: [],
    ...overrides,
  };
}

describe('SeverityCalculator', () => {
  it('returns low severity for no anomalies and no impact', () => {
    const result = SeverityCalculator.calculate([], 1, false);
    expect(result.severity).toBe('low');
    expect(result.score).toBe(0);
  });

  it('returns critical severity for multiple critical anomalies + multi-service + user impact', () => {
    const anomalies = [anomaly({ id: 'a1' }), anomaly({ id: 'a2', serviceId: 'order-service' })];
    const result = SeverityCalculator.calculate(anomalies, 3, true);
    expect(result.severity).toBe('critical');
    expect(result.reasons.length).toBeGreaterThan(0);
    expect(result.reasons.some((r) => r.includes('User impact'))).toBe(true);
  });

  it('escalates severity with the multiple-services bonus', () => {
    const singleService = SeverityCalculator.calculate([anomaly({ severity: 'medium' })], 1, false);
    const multiService = SeverityCalculator.calculate([anomaly({ severity: 'medium' })], 3, false);
    expect(multiService.score).toBeGreaterThan(singleService.score);
  });
});
