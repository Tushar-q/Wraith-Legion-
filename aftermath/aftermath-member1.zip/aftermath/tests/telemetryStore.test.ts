import { TelemetryStore } from '../src/telemetry/TelemetryStore';
import { TelemetryGenerator } from '../src/telemetry/TelemetryGenerator';

describe('TelemetryStore', () => {
  let store: TelemetryStore;

  beforeEach(() => {
    store = new TelemetryStore();
  });

  it('stores and retrieves metrics via the unified telemetry stream', () => {
    const metric = TelemetryGenerator.metric('payment-service', 'latency', 4500, '2026-08-29T09:00:00Z', 'ms');
    store.addMetric(metric);

    const telemetry = store.getTelemetry();
    expect(telemetry).toHaveLength(1);
    expect(telemetry[0].category).toBe('metric');
    expect(telemetry[0].serviceId).toBe('payment-service');
    expect(telemetry[0].data.value).toBe(4500);
  });

  it('filters telemetry by service', () => {
    store.addMetric(TelemetryGenerator.metric('payment-service', 'latency', 100, '2026-08-29T09:00:00Z'));
    store.addMetric(TelemetryGenerator.metric('order-service', 'latency', 80, '2026-08-29T09:00:01Z'));

    expect(store.getTelemetryByService('payment-service')).toHaveLength(1);
    expect(store.getTelemetryByService('order-service')).toHaveLength(1);
  });

  it('filters telemetry by category', () => {
    store.addMetric(TelemetryGenerator.metric('payment-service', 'latency', 100, '2026-08-29T09:00:00Z'));
    store.addLog(TelemetryGenerator.log('payment-service', 'INFO', 'started', '2026-08-29T09:00:01Z'));

    expect(store.getTelemetryByCategory('metric')).toHaveLength(1);
    expect(store.getTelemetryByCategory('log')).toHaveLength(1);
  });

  it('filters telemetry by time range', () => {
    store.addMetric(TelemetryGenerator.metric('payment-service', 'latency', 100, '2026-08-29T09:00:00Z'));
    store.addMetric(TelemetryGenerator.metric('payment-service', 'latency', 200, '2026-08-29T10:00:00Z'));

    const results = store.getTelemetryByTimeRange('2026-08-29T09:30:00Z', '2026-08-29T10:30:00Z');
    expect(results).toHaveLength(1);
    expect(results[0].data.value).toBe(200);
  });

  it('finds telemetry by traceId', () => {
    const trace = TelemetryGenerator.trace(
      [TelemetryGenerator.span('payment-service', 'chargePayment', '2026-08-29T09:00:00Z', 90, 'success')],
      '2026-08-29T09:00:00Z'
    );
    store.addTrace(trace);
    const log = TelemetryGenerator.log(
      'payment-service',
      'INFO',
      'charge started',
      '2026-08-29T09:00:00Z',
      trace.traceId
    );
    store.addLog(log);

    const related = store.getTelemetryByTraceId(trace.traceId);
    expect(related).toHaveLength(2);
  });

  it('clears all telemetry on clearTelemetry()', () => {
    store.addMetric(TelemetryGenerator.metric('payment-service', 'latency', 100, '2026-08-29T09:00:00Z'));
    store.clearTelemetry();
    expect(store.getTelemetry()).toHaveLength(0);
    expect(store.getMetrics()).toHaveLength(0);
  });
});
