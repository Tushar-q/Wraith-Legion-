---
name: Aftermath
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#3a393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1c1b1c'
  surface-container: '#201f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#313031'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#ffb783'
  on-tertiary: '#4f2500'
  tertiary-container: '#d97721'
  on-tertiary-container: '#452000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#ffdcc5'
  tertiary-fixed-dim: '#ffb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#703700'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.4'
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.4'
  mono-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.6'
  mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base-unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  gutter: 16px
  margin-page: 32px
---

## Brand & Style
The design system is engineered for high-stakes operational environments where clarity and rapid cognition are paramount. It follows a **Modern Corporate** aesthetic with a heavy leaning toward **Minimalism** and **Technical Sophistication**. 

The UI should evoke a sense of calm authority. By utilizing deep charcoal foundations and surgical hits of color, the design system directs focus toward critical data points without overwhelming the operator. The style is characterized by high-density information layouts, ultra-thin strokes, and a systematic approach to technical metadata. It avoids decorative elements in favor of functional precision, reminiscent of advanced developer tools and aerospace interfaces.

## Colors
The palette is rooted in a "Deep Dark" hierarchy. The primary background (`#0A0A0B`) provides the maximum contrast for active UI elements. 

- **Primary (Electric Indigo):** Used for primary actions, active states, and "AI Brain" indicators.
- **Secondary (Cyan):** Used for technical highlights, data visualization trends, and interactive nodes.
- **Surface Logic:** Layers move from the base (`#0A0A0B`) to primary surfaces (`#121214`) to elevated modals or floating panels (`#1F1F22`). 
- **Functional Semantics:** Status colors must be used sparingly. High-saturation shades are reserved for badges and critical alerts, while lower-opacity versions are used for background washes in forensic timelines.

## Typography
This design system utilizes **Geist** for its neutral, surgical clarity in UI elements and **JetBrains Mono** for all machine-generated content.

- **Geist (UI):** Used for navigation, card titles, and primary interface controls. It should feel balanced and unobtrusive.
- **JetBrains Mono (Technical):** Used for timestamps, log snippets, CIDRs, and Causal Graph metadata. The monospaced nature ensures that vertical alignment is maintained in dense data tables.
- **Hierarchy:** Use `label-caps` for section headers within sidebars to create a distinct structural break without increasing font size.

## Layout & Spacing
The layout uses a **Fluid Grid** approach for the main dashboard views, allowing forensic data to expand to the full width of the screen.

- **Information Density:** Vertical spacing is tight (`8px` or `12px`) between related data points to maximize the amount of visible evidence.
- **Sidebars:** Use a fixed-width left navigation (240px) and an optional right-side "Details Panel" (400px) that slides over the content.
- **Grids:** For data-heavy views, use a 12-column grid with a `16px` gutter. In the Causal Graph, use an organic, non-linear layout with `40px` safe zones around nodes.

## Elevation & Depth
Depth is communicated through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Borders:** All surfaces must have a `1px` solid border using `#27272A`. This defines the shape against the black background.
- **Glassmorphism:** Use a subtle backdrop blur (12px) and `0.05` opacity white fill for floating elements like dropdowns or command palettes to maintain context of the underlying data.
- **Muted Shadows:** If a shadow is required for a modal, use a large, soft blur (32px) with a `0.5` opacity black, ensuring it feels like an ambient occlusion rather than a light source effect.

## Shapes
The design system uses **Soft** roundedness to take the edge off the technical density. 

- **Standard Elements:** Buttons, inputs, and badges use `0.25rem` (4px).
- **Containers:** Large cards and service nodes use `0.5rem` (8px).
- **Service Nodes:** In the Causal Graph, nodes should be rounded-rectangles rather than circles to allow for more text real estate within the shape.

## Components

### Status/Severity Badges
- **Structure:** Small `text-transform: uppercase` label with a leading dot indicator.
- **Styling:** Low-opacity background (10%) of the status color with a high-saturation border (30%) and full-saturation text.
- **AI Investigation:** Use a gradient border (Electric Indigo to Cyan) to signify active machine reasoning.

### Forensic Timeline
- **Visuals:** A vertical `1px` dashed line connecting events. 
- **Items:** Each item features a timestamp in `mono-sm`. Critical events expand to show a "Snapshot" which is a `#121214` card with a `border-left` of the severity color.

### Service Health Nodes
- **Appearance:** A card with a header containing the service name and a small "sparkline" visualization.
- **Connectivity:** Nodes are connected by `1px` solid lines. If a connection is degraded, the line pulses in `#F59E0B`.

### AI Recommendation Cards
- **Focus:** These cards use a slightly higher elevation (`#1F1F22`) and a subtle glow effect (1px outer stroke of `#6366F1`).
- **Action:** Primary action buttons within these cards should use a solid `#6366F1` fill with white text.

### Forensic Evidence Items
- **Design:** Monospaced text blocks inside a subtly recessed container (`#0A0A0B` background with a `#27272A` border). 
- **Interactivity:** On hover, the border color shifts to `#6366F1` to indicate the item can be attached to a report.